export default { root: '/tmp', test: { environment: 'node', include: ['v21-c-reviewer-extra.test.ts'], cache: false } }
