import fs from 'node:fs'
import path from 'node:path'
import { build } from '/Users/kadensmith/Documents/Codex/2026-10-11/1-extinguishing-methods-1-extinguishing-medium/outputs/v21-agent-vibration/work/version21-realism/round-1/c-reviewer-20261012/node_modules/esbuild/lib/main.js'
const root='/Users/kadensmith/Documents/Codex/2026-10-11/1-extinguishing-methods-1-extinguishing-medium/outputs/v21-agent-vibration/work/version21-realism/round-1/c-reviewer-20261012'
const historical=['field.ts','field.worker.ts','session.ts','effects.tsx','field-scene.tsx','visuals.ts'].map(n=>'src/alternatives/vibratory-injection/'+n)
const graphs=[]
for(const entry of ['src/alternatives/vibratory-injection/workspace.tsx','src/alternatives/vibratory-injection/index.ts','src/App.tsx']){
 const compiled=await build({entryPoints:[entry],absWorkingDir:root,bundle:true,write:false,metafile:true,packages:'external',loader:{'.css':'empty'},platform:'browser',format:'esm',logLevel:'silent',plugins:[{name:'record-external-vite-worker-queries',setup(b){b.onResolve({filter:/\?worker$/},a=>({path:a.path,external:true}))}}]})
 const seen=Object.keys(compiled.metafile.inputs)
 const activeC=seen.filter(n=>n.startsWith('src/alternatives/vibratory-injection/')).sort()
 const forbidden=historical.filter(n=>seen.includes(n))
 const activeCWorkerConstructors=activeC.filter(n=>/new\s+Worker\s*\(/.test(fs.readFileSync(path.join(root,n),'utf8')))
 graphs.push({entry,visitedSourceFiles:seen.length,excludedViteWorkerQueries:Object.values(compiled.metafile.inputs).flatMap(x=>x.imports).filter(x=>x.external&&x.path.endsWith('?worker')).map(x=>x.path),activeC,forbiddenHistoricalReachable:forbidden,activeCWorkerConstructors})
 if(forbidden.length||activeCWorkerConstructors.length)throw new Error('Unexpected active historical module or C worker constructor')
}
const result={executor:'Independent reviewer /root/vibration_reviewer',commit:'3b2994ea3715bc5f58ff6d588cdbe6e1eaf9b5fb',method:'Installed esbuild bundle with write:false and metafile; actual source runtime imports including dynamic imports; packages external; Vite ?worker edges external and listed (no C worker edges); no browser, HTTP, GLSL, GPU or runtime app execution',graphs}
fs.writeFileSync('/tmp/v21-c-reviewer-import-graph.json',JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify(result,null,2))
