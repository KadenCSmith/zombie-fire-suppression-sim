import { describe, expect, it } from '/Users/kadensmith/Documents/Codex/2026-10-11/1-extinguishing-methods-1-extinguishing-medium/outputs/v21-agent-vibration/work/version21-realism/round-1/c-reviewer-20261012/node_modules/vitest/dist/index.js'
import * as THREE from '/Users/kadensmith/Documents/Codex/2026-10-11/1-extinguishing-methods-1-extinguishing-medium/outputs/v21-agent-vibration/work/version21-realism/round-1/c-reviewer-20261012/node_modules/three/build/three.module.js'
import { createCompactionPass } from '/Users/kadensmith/Documents/Codex/2026-10-11/1-extinguishing-methods-1-extinguishing-medium/outputs/v21-agent-vibration/work/version21-realism/round-1/c-reviewer-20261012/src/alternatives/vibratory-injection/compaction-pass'

function fixture(failure: 'none' | 'scene' = 'none') {
  const scene = new THREE.Scene(), camera = new THREE.PerspectiveCamera()
  const original = new THREE.WebGLRenderTarget(3, 4)
  const material = new THREE.MeshStandardMaterial({ color: '#d06020' })
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(), material); scene.add(mesh)
  const before = { compile: material.onBeforeCompile, cache: material.customProgramCacheKey, color: material.color.clone() }
  let target: THREE.WebGLRenderTarget | null = original, scissorTest = true
  const viewport = new THREE.Vector4(2, 3, 80, 60), scissor = new THREE.Vector4(7, 8, 50, 40)
  const expectedCamera = new THREE.Matrix4().makeTranslation(6, 7, 8)
  const expectedProjection = new THREE.Matrix4().makeScale(2, 3, 4)
  const mock = {
    autoClear: false,
    getDrawingBufferSize: (v: THREE.Vector2) => v.set(160, 120),
    getRenderTarget: () => target, setRenderTarget: (v: THREE.WebGLRenderTarget | null) => { target = v },
    getViewport: (v: THREE.Vector4) => v.copy(viewport), setViewport: (v: THREE.Vector4) => viewport.copy(v),
    getScissor: (v: THREE.Vector4) => v.copy(scissor), setScissor: (v: THREE.Vector4) => scissor.copy(v),
    getScissorTest: () => scissorTest, setScissorTest: (v: boolean) => { scissorTest = v },
    render: (v: THREE.Scene) => {
      if (v === scene) {
        camera.matrixWorld.copy(expectedCamera); camera.projectionMatrixInverse.copy(expectedProjection)
        if (failure === 'scene') throw new Error('primary scene render failed')
      }
    },
  }
  return { scene, camera, original, material, mesh, before, mock, expectedCamera, expectedProjection,
    state: () => ({ target, scissorTest, autoClear: mock.autoClear, viewport: viewport.toArray(), scissor: scissor.toArray() }) }
}

describe('independent output-pass frame and failure checks', () => {
  it('uses camera transforms belonging to the rendered depth frame, including a same-frame camera update', () => {
    const f = fixture(), pass = createCompactionPass()
    try {
      pass.render(f.mock as unknown as THREE.WebGLRenderer, f.scene, f.camera, .5)
      expect(pass.material.uniforms.cameraWorld.value.equals(f.expectedCamera)).toBe(true)
      expect(pass.material.uniforms.inverseProjection.value.equals(f.expectedProjection)).toBe(true)
      expect(f.material.onBeforeCompile).toBe(f.before.compile)
      expect(f.material.customProgramCacheKey).toBe(f.before.cache)
      expect(f.material.color.equals(f.before.color)).toBe(true)
    } finally { pass.dispose(); f.original.dispose(); f.mesh.geometry.dispose(); f.material.dispose() }
  })
  it('restores pre-existing renderer state when the primary scene render fails, without touching scene materials', () => {
    const f = fixture('scene'), pass = createCompactionPass(), before = f.state()
    try {
      expect(() => pass.render(f.mock as unknown as THREE.WebGLRenderer, f.scene, f.camera, .5)).toThrow('primary scene render failed')
      expect(f.state()).toEqual(before)
      expect(f.material.onBeforeCompile).toBe(f.before.compile)
      expect(f.material.customProgramCacheKey).toBe(f.before.cache)
      expect(f.material.color.equals(f.before.color)).toBe(true)
    } finally { pass.dispose(); f.original.dispose(); f.mesh.geometry.dispose(); f.material.dispose() }
  })
})
