export default { root: '/tmp', test: { environment: 'node', include: ['v21-c-reviewer-retry2-extra.test.ts'], cache: false } }
