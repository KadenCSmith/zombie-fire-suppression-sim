import { describe, expect, it } from '/Users/kadensmith/Documents/Codex/2026-10-11/1-extinguishing-methods-1-extinguishing-medium/outputs/v21-agent-vibration/work/version21-realism/round-1/c-reviewer-20261012/node_modules/vitest/dist/index.js'
import * as THREE from '/Users/kadensmith/Documents/Codex/2026-10-11/1-extinguishing-methods-1-extinguishing-medium/outputs/v21-agent-vibration/work/version21-realism/round-1/c-reviewer-20261012/node_modules/three/build/three.module.js'
import { COMPACTION_GROUPS, createCompactionPass } from '/Users/kadensmith/Documents/Codex/2026-10-11/1-extinguishing-methods-1-extinguishing-medium/outputs/v21-agent-vibration/work/version21-realism/round-1/c-reviewer-20261012/src/alternatives/vibratory-injection/compaction-pass'
import { vibrationPose, vibrationStage } from '/Users/kadensmith/Documents/Codex/2026-10-11/1-extinguishing-methods-1-extinguishing-medium/outputs/v21-agent-vibration/work/version21-realism/round-1/c-reviewer-20261012/src/alternatives/vibratory-injection/vibration'

type Failure = 'none' | 'primary' | 'reference' | 'output' | 'endpoint'
function fixture(failure: Failure = 'none', visibility = [false, true, false]) {
  const pass = createCompactionPass(), scene = new THREE.Scene(), camera = new THREE.PerspectiveCamera()
  const burning = new THREE.Group(), settled = new THREE.Group(), fire = new THREE.Group()
  burning.name=COMPACTION_GROUPS.burning;settled.name=COMPACTION_GROUPS.settled;fire.name=COMPACTION_GROUPS.fireOnly
  burning.visible=visibility[0];settled.visible=visibility[1];fire.visible=visibility[2];scene.add(burning,settled,fire)
  const material=new THREE.MeshStandardMaterial({color:'#e04818'}), mesh=new THREE.Mesh(new THREE.BoxGeometry(),material);scene.add(mesh)
  const original=new THREE.WebGLRenderTarget(7,9), viewport=new THREE.Vector4(2,3,80,60), scissor=new THREE.Vector4(7,8,50,40)
  let target: THREE.WebGLRenderTarget|null=original, scissorTest=true
  const cameraWorld=new THREE.Matrix4().makeTranslation(6,7,8), inverseProjection=new THREE.Matrix4().makeScale(2,3,4)
  const calls: {target:unknown, appearance:boolean[], scene:boolean}[]=[]
  const mock={autoClear:false,
    getDrawingBufferSize:(v:THREE.Vector2)=>v.set(160,120),getRenderTarget:()=>target,
    setRenderTarget:(v:THREE.WebGLRenderTarget|null)=>{target=v;viewport.set(0,0,v?.width??160,v?.height??120);scissor.set(0,0,1,1)},
    getViewport:(v:THREE.Vector4)=>v.copy(viewport),setViewport:(v:THREE.Vector4)=>viewport.copy(v),
    getScissor:(v:THREE.Vector4)=>v.copy(scissor),setScissor:(v:THREE.Vector4)=>scissor.copy(v),
    getScissorTest:()=>scissorTest,setScissorTest:(v:boolean)=>{scissorTest=v},
    render:(v:THREE.Scene)=>{
      calls.push({target,appearance:[burning.visible,settled.visible,fire.visible],scene:v===scene})
      if(v===scene){
        if(target===pass.target){camera.matrixWorld.copy(cameraWorld);camera.projectionMatrixInverse.copy(inverseProjection)}
        if(failure==='primary'&&target===pass.target)throw new Error('primary draw failure')
        if(failure==='reference'&&target===pass.reference)throw new Error('reference draw failure')
        if(failure==='endpoint'&&target===original&&settled.visible)throw new Error('endpoint draw failure')
      } else if(failure==='output')throw new Error('output draw failure')
    }}
  const state=()=>({target,autoClear:mock.autoClear,scissorTest,viewport:viewport.toArray(),scissor:scissor.toArray(),visibility:[burning.visible,settled.visible,fire.visible]})
  const materialState=()=>({compile:material.onBeforeCompile,cache:material.customProgramCacheKey,color:material.color.toArray()})
  const dispose=()=>{pass.dispose();original.dispose();material.dispose();mesh.geometry.dispose()}
  return {pass,scene,camera,mock,calls,state,materialState,cameraWorld,inverseProjection,original,dispose}
}

describe('independent retry2 reference-draw and endpoint checks',()=>{
  it('renders mutually exclusive same-camera appearances and restores noncanonical owner visibility and GL state',()=>{
    const f=fixture(),before=f.state(),material=f.materialState()
    try{
      f.pass.render(f.mock as unknown as THREE.WebGLRenderer,f.scene,f.camera,.65)
      expect(f.calls).toHaveLength(3)
      expect(f.calls[0]).toMatchObject({scene:true,appearance:[true,false,true],target:f.pass.target})
      expect(f.calls[1]).toMatchObject({scene:true,appearance:[false,true,false],target:f.pass.reference})
      expect(f.calls[2]).toMatchObject({scene:false,target:f.original})
      expect(f.pass.material.uniforms.cameraWorld.value.equals(f.cameraWorld)).toBe(true)
      expect(f.pass.material.uniforms.inverseProjection.value.equals(f.inverseProjection)).toBe(true)
      expect(f.state()).toEqual(before);expect(f.materialState()).toEqual(material)
    }finally{f.dispose()}
  })
  it('restores original visibility and renderer state for primary, reference, output and exact-endpoint failures',()=>{
    for(const failure of ['primary','reference','output','endpoint'] as const){
      const f=fixture(failure),before=f.state(),material=f.materialState()
      try{
        expect(()=>f.pass.render(f.mock as unknown as THREE.WebGLRenderer,f.scene,f.camera,failure==='endpoint'?1:.65)).toThrow(failure+' draw failure')
        expect(f.state()).toEqual(before);expect(f.materialState()).toEqual(material)
      }finally{f.dispose()}
    }
  })
  it('uses the exact off reference at and beyond1 and returns to unchanged on appearance after backward seeking',()=>{
    const f=fixture('none',[true,false,true]),before=f.state(),material=f.materialState()
    try{
      for(const progress of [0,.999999,1,1.000001,0]){
        f.calls.length=0;f.pass.render(f.mock as unknown as THREE.WebGLRenderer,f.scene,f.camera,progress)
        if(progress<=0){expect(f.calls).toHaveLength(1);expect(f.calls[0]).toMatchObject({scene:true,target:f.original,appearance:[true,false,true]})}
        else if(progress>=1){expect(f.calls).toHaveLength(1);expect(f.calls[0]).toMatchObject({scene:true,target:f.original,appearance:[false,true,false]})}
        else expect(f.calls).toHaveLength(3)
        expect(f.state()).toEqual(before);expect(f.materialState()).toEqual(material)
      }
    }finally{f.dispose()}
  })
  it('fails closed for missing appearance groups and disposed resources without touching the caller',()=>{
    const f=fixture(),before=f.state()
    try{
      expect(()=>f.pass.render(f.mock as unknown as THREE.WebGLRenderer,new THREE.Scene(),f.camera,.5)).toThrow('appearance groups are missing')
      expect(f.state()).toEqual(before);f.pass.dispose()
      expect(()=>f.pass.render(f.mock as unknown as THREE.WebGLRenderer,f.scene,f.camera,.5)).toThrow('disposed')
      expect(f.state()).toEqual(before)
    }finally{f.dispose()}
  })
  it('disabled late-stage captions and display pose cannot claim compression or fire-out',()=>{
    for(const t of [33,44,50,65,73.9,74,90]){
      expect(vibrationStage(t,false)).toBe('Original fire & inserted drill · vibration off')
      const p=vibrationPose(t,false);expect(p.compression).toBe(0);expect(p.emberFade).toBe(0);expect(p.groundScale).toEqual([1,1,1])
    }
    expect(vibrationStage(90,true)).toContain('Illustrated fire-out')
  })
})
