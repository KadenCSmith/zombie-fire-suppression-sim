// ../short-life-edge.mts
import fs from "node:fs";

// src/alternatives/contract.ts
var ALTERNATIVE_API_VERSION = "v21.2";
var PARTICLE_API_VERSION = "v21.3";

// src/alternatives/sublimation-injection/index.ts
var provenance = "User-supplied Version21 capstone concept; material references and model assumptions in method evidence. No experimental validation.";
var variants = [{
  id: "sublimation-injection",
  method: "4.2.1",
  number: "4.2.1",
  label: "Extinguishing Medium Sublimation and Injection",
  subtitle: "Truck-delivered water + dry ice \u2192 illustrative flow and quenching",
  engines: ["contact", "concept"],
  media: ["water", "co2-water", "unspecified"],
  defaultMedium: "water",
  defaultEngine: "contact",
  stages: ["Fire spread + access", "Drilling + truck delivery", "Water + dry-ice loading", "Illustrative flow + quenching"],
  limitation: "Truck delivery, dry-ice loading, faster water motion and visible quenching are illustrative. Finite contact heat and inventory are modeled separately in three isolated specimens; tank pressure, liquid pre-cooling, accelerated field injection, penetration, suppression, re-ignition and cost savings are unavailable predictions. The CO\u2082 option is direct solid contact, not predicted tank pre-cooling.",
  status: { illustrative: true, modeled: "Finite contact heat / inventory only \xB7 unvalidated", experimentallyValidated: false },
  provenance
}];
var PRESENTATION_TIMING = { surfaceS: 38, preparationS: 59, injectionS: 56, endS: 90 };
var THERMAL_LIMITS = {
  initialK: [300, 1e3],
  waterKg: [0, 5],
  flowKgS: [0, 0.2],
  inletK: [273.15, 350],
  contactStartS: [0, 50],
  conductanceWK: [0, 100],
  dryIceKg: [0, 1],
  endS: [10, 120]
};
function sublimationPresentation(timeS) {
  const time = Number.isFinite(timeS) ? Math.max(0, Math.min(PRESENTATION_TIMING.endS, timeS)) : 0;
  const injection = time >= PRESENTATION_TIMING.injectionS;
  return { contextTime: Math.min(time, 38), access: true, pulse: false, waves: false, injection, vibration: 0, contacts: injection ? 1 : 0 };
}
function validateSublimationConfig(config) {
  if (config.variantId !== "sublimation-injection") throw new Error("4.2.1 adapter requires sublimation-injection identity.");
  if (typeof config.id !== "string" || !config.id.trim()) throw new Error("4.2.1 requires an independent panel identity.");
  const descriptor = variants[0];
  if (!descriptor.engines.includes(config.engine)) throw new Error(`4.2.1 has no supported ${config.engine} adapter.`);
  if (!descriptor.media.includes(config.medium)) throw new Error("Unsupported 4.2.1 medium.");
  if (config.engine === "contact" && config.medium === "unspecified") throw new Error("Unspecified medium has no thermodynamic properties; select conceptual stages.");
  if (config.sourceStatus !== "unspecified" && config.sourceStatus !== "known-contact-properties") throw new Error("Unknown source-property status.");
  if (!config.thermal || typeof config.thermal.enabled !== "boolean" || !Number.isSafeInteger(config.thermal.seed)) throw new Error("4.2.1 requires a boolean intervention flag and integer seed.");
  for (const key of Object.keys(THERMAL_LIMITS)) {
    const value = config.thermal[key], [minimum, maximum] = THERMAL_LIMITS[key];
    if (!Number.isFinite(value) || value < minimum || value > maximum) throw new Error(`Unsupported ${key}; expected ${minimum}\u2013${maximum} in the documented SI unit.`);
  }
  if (config.engine === "contact" && config.thermal.initialK < config.thermal.inletK) throw new Error("The hot-contact proxy requires initial temperature at least the liquid inlet temperature.");
}
var methodModule = {
  apiVersion: ALTERNATIVE_API_VERSION,
  method: "4.2.1",
  variants,
  defaultSettings: () => ({ contactStartS: 8 }),
  createRun(config, hooks) {
    validateSublimationConfig(config);
    return hooks.supportedRun(structuredClone(config));
  },
  presentation: (_id, timeS) => sublimationPresentation(timeS)
};

// src/story/fireSequence.ts
var FIRE_SEQUENCE_DURATION = 90;
var FIRE_SEQUENCE_GEOMETRY = { sourceX: 0.4, sourceDepthM: 1.3, sourceInitialMassKg: 4, sourceDensityKgM3: 1560, boreRadiusM: 0.24, boreDepthM: 1.385, capRadiusM: 0.58, capFoldedRadiusM: 0.15, capRiseM: 0.16, capDepthM: 0.98, capInversionM: 0.32, capWedgeRadiusM: 0.69, capGapCenterRad: Math.PI / 4, capGapHalfAngleRad: 0.4, cavityRadiusM: 0.65, cavityCenterY: -0.95, cavityHalfHeightM: 0.28, pitDepthM: 1.3, pitBottomRadiusM: 0.66, pitTopRadiusM: 0.98, hoseRadiusM: 0.055, augerRadiusM: 0.2, domain: { widthM: 8, lengthM: 8, depthM: 3.2 } };
var FIRE_SEQUENCE_STAGES = [
  { id: "surface", start: 0, end: 10, title: "A small surface fire", short: "Ignition", description: "A localized ignition starts the story above organic ground.", evidence: "Flames are a visual cue. The field view shows the numerical temperature state." },
  { id: "underground", start: 10, end: 24, title: "The fire moves underground", short: "Subsurface spread", description: "The story illustrates a buried peat fire. A moving underground front is not resolved by this calculation.", evidence: "Underground spread is prescribed in the natural story. Accepted numerical fields show heating and oxidation without a resolved moving subsurface front." },
  { id: "drilling", start: 24, end: 37, title: "Drill a straight bore", short: "Straight bore", description: "At 70% illustrated peat involvement, the tracked excavator turns a fixed-width auger into the peat.", evidence: "Auger motion and the cylindrical bore are staged. Soil stability, root contact and excavation forces are not solved." },
  { id: "source", start: 37, end: 47, title: "Lower the dry-ice sphere", short: "Dry ice", description: "The dry-ice sphere settles at the bottom of the straight bore.", evidence: "Placement is authored. Natural-view source mass follows a separate finite contact-model inventory." },
  { id: "dome", start: 47, end: 55, title: "Lower the fixed-size metal cap", short: "Metal cap", description: "A small metal cap drops into the original bore. Its width and profile stay fixed.", evidence: "The cap is staged geometry. Fit, sealing and structural loading have not been validated." },
  { id: "treatment", start: 55, end: 69, title: "Rapid gas release and peat fractures", short: "Gas release", description: "In rapid mode, the sphere vanishes into a depicted CO\u2082 release. A brief soil jolt sends fine fractures across the peat and dims nearby embers. The metal cap and bore keep their original size.", evidence: "Gas conversion, oxygen displacement, fracture growth and visual quenching are authored. The contact ledger exports residual dry ice; pressure and field suppression are not calculated." },
  { id: "water", start: 69, end: 85, title: "Water follows the fractures", short: "Water stage", description: "A woven hose enters through the cap gap. Water follows the illustrated fracture network, darkening peat and extinguishing the remaining depicted embers.", evidence: "Wetting routes and visual ember extinction are authored. Local contact cooling has a separate finite budget; infiltration and field suppression are not predicted." },
  { id: "review", start: 85, end: 90, title: "Inspect the illustrated outcome", short: "Review", description: "Compare the darkened peat and remaining accepted numerical field evidence.", evidence: "Visual extinguishment is staged. It is not a validated treatment procedure or a prediction of extinguishment." }
];
var phase = (time, start, end) => Math.max(0, Math.min(1, (time - start) / (end - start)));
var eased = (time, start, end) => {
  const p = phase(time, start, end);
  return p * p * (3 - 2 * p);
};
var STORY_CRACK_PATHS = [
  [[0.4, -1.28, 0.035], [0.9, -1.4, 0.045], [1.25, -1.1, 0.04], [1.85, -1.32, 0.045], [2.48, -0.82, 0.04], [3.1, -0.68, 0.04]],
  [[0.4, -1.28, 0.04], [0.1, -1.64, 0.04], [-0.5, -1.78, 0.04], [-1.02, -2.1, 0.04], [-1.9, -2, 0.04], [-2.75, -2.5, 0.04]],
  [[0.4, -1.28, 0.04], [0.78, -1.9, 0.04], [1.4, -2.08, 0.04], [1.7, -2.55, 0.04], [2.6, -2.8, 0.04]],
  [[0.4, -1.28, 0.04], [-0.15, -0.84, 0.04], [-0.82, -0.63, 0.04], [-1.15, -0.24, 0.04], [-1.65, -0.04, 0.04]],
  [[0.4, -1.28, 0.04], [1.25, -1.1, 0.04], [1.42, -0.55, 0.04], [1.15, -0.18, 0.04]],
  [[0.4, -1.28, 0.04], [0.1, -1.64, 0.04], [-0.1, -2.16, 0.04], [-0.66, -2.62, 0.04]]
];
var STORY_HOSE_POINTS = [[-4.4, 0.15, -0.8], [-3.5, 0.16, -0.4], [-2.7, 0.16, -0.72], [-1.9, 0.16, -0.32], [-1.1, 0.16, -0.5], [-0.2, 0.19, -0.12], [0.34, 0.32, 0.1], [0.51, 0.15, 0.11], [0.49, -0.3, 0.09], [0.52, -0.85, 0.12], [0.515, -1.265, 0.115]];
var STORY_WATER_START = 72;
function storyWettingProgress(time, branch) {
  return 0.66 * Math.sqrt(Math.max(0, Math.min(1, (time - STORY_WATER_START - branch * 0.65) / 18)));
}
function pointAlongStoryPath(points, fraction) {
  const lengths = points.slice(1).map((p, i) => Math.hypot(...p.map((v, j) => v - points[i][j]))), total = lengths.reduce((a2, b2) => a2 + b2, 0);
  let distance = Math.max(0, Math.min(1, fraction)) * total;
  for (let i = 0; i < lengths.length; i++) {
    if (distance <= lengths[i] || i === lengths.length - 1) {
      const f = distance / lengths[i];
      return points[i].map((v, j) => v + (points[i + 1][j] - v) * f);
    }
    distance -= lengths[i];
  }
  return points[0];
}

// src/story/firePresentation.ts
var PRESENTATION_TIMING2 = {
  spreadStart: 12,
  spreadEnd: 40,
  excavatorEnter: 18,
  excavatorPark: 24,
  drillStart: 24,
  drillFullDepth: 31,
  drillRetract: 34,
  drillClear: 36.5,
  excavatorExit: 40,
  sourceContact: 44,
  capSeated: 51.5,
  gasRelease: 55,
  truckEnter: 57,
  truckPark: 65,
  hoseDeploy: 65,
  hoseAtBore: 69,
  hoseConnected: 72,
  waterStart: 72,
  review: 85
};
var PRESENTATION_SPEED = { early: 3.2, equipment: 1.2, placement: 2, release: 1, finish: 2 };
function presentationRate(time) {
  const s = PRESENTATION_SPEED, t = PRESENTATION_TIMING2;
  let rate = s.early + (s.equipment - s.early) * eased(time, t.excavatorEnter, t.excavatorPark);
  rate += (s.placement - s.equipment) * eased(time, t.drillClear, t.excavatorExit);
  rate += (s.release - s.placement) * eased(time, 53, t.gasRelease);
  rate += (s.finish - s.release) * eased(time, 56.5, 58.5);
  return rate;
}
var CLOCK_STEP = 0.02;
var clock = new Float64Array(Math.round(FIRE_SEQUENCE_DURATION / CLOCK_STEP) + 1);
for (let i = 1; i < clock.length; i++) {
  const a2 = (i - 1) * CLOCK_STEP, b2 = i * CLOCK_STEP;
  clock[i] = clock[i - 1] + CLOCK_STEP / 6 * (1 / presentationRate(a2) + 4 / presentationRate((a2 + b2) / 2) + 1 / presentationRate(b2));
}
var PRESENTATION_PLAYBACK_DURATION = clock[clock.length - 1];
var WATER_TRUCK = {
  parked: [2.35, 0, -1.15],
  outletLocal: [-1.27, 0.63, 0.61],
  wheelRadiusM: 0.29
};
var parkedOutlet = WATER_TRUCK.parked.map((v, i) => v + WATER_TRUCK.outletLocal[i]);
var CONNECTED_HOSE_ROUTE = [
  parkedOutlet,
  [0.96, 0.22, -0.52],
  [0.8, 0.13, -0.46],
  [0.63, 0.13, -0.36],
  [0.52, 0.14, -0.26],
  [0.42, 0.22, -0.13],
  ...STORY_HOSE_POINTS.slice(6)
];
var CURRENT_FIRE_STAGES = FIRE_SEQUENCE_STAGES.map((stage) => stage.id === "drilling" ? { ...stage, description: "The parked excavator turns its auger into the bore while the continuous illustrated peat front keeps advancing. Soil-colored cuttings mark drilling; no water is applied." } : stage.id === "treatment" ? { ...stage, description: "After the cap lands, rapid mode depicts a brief gas release. A water truck enters and parks, then its reel extends a connected hose toward the access point. Gradual mode retains finite contact cooling." } : stage.id === "water" ? { ...stage, description: "The supply end stays attached to the truck. The hose clears the retracted drill, enters the cap service opening, then supplies the established progressive wetting sequence after connection at 72 s." } : stage);

// src/alternatives/pressure-pulse-liquid-waves/animation.ts
var clamp = (n) => Math.max(0, Math.min(1, n));
var smooth = (time, start, end) => {
  const u = clamp((time - start) / (end - start));
  return u * u * (3 - 2 * u);
};
var HYDRAULIC_PULSES = [[76, 78], [82, 84], [87, 89]];
var LIQUID_SEQUENCE = { injectionStart: PRESENTATION_TIMING2.waterStart, end: 90 };
var DRILL_SECTION_STARTS = [68, 68 + 4 / 3, 68 + 8 / 3];
function liquidAnimationFrame(presentationS) {
  const time = Number.isFinite(presentationS) ? Math.max(0, Math.min(90, presentationS)) : 0;
  const injection = time >= PRESENTATION_TIMING2.waterStart;
  const pulseIndex = HYDRAULIC_PULSES.findIndex(([start, end]) => time >= start && time < end);
  const waves = pulseIndex >= 0;
  const age = waves ? time - HYDRAULIC_PULSES[pulseIndex][0] : 0;
  const progress = age / 2;
  const strength = waves ? clamp((1 - Math.exp(-age * 30)) * Math.exp(-age * 4) * 1.8) : 0;
  const tremor = waves ? Math.sin(age * 34) * Math.exp(-age * 4) * 0.035 : 0;
  const opening = HYDRAULIC_PULSES.reduce((sum, [start]) => sum + smooth(time, start, start + 0.55), 0) / HYDRAULIC_PULSES.length;
  const accelerated = HYDRAULIC_PULSES.reduce((sum, [start, end]) => sum + Math.max(0, Math.min(time, end) - start), 0);
  const flowClock = Math.max(0, time - PRESENTATION_TIMING2.waterStart) * 0.55 + accelerated * 0.65;
  const arrival = clamp(time - PRESENTATION_TIMING2.waterStart);
  return {
    time,
    waves,
    injection,
    pulseIndex,
    progress,
    strength,
    tremor,
    opening,
    stage: time < 44 ? "Original fire and drilled access" : time < 57 ? "Original dry-ice pressure release" : time < 65 ? "Pump truck reverses into position" : time < 68 ? "Drilling mast rises" : time < 72 ? "Rigid drill pipe advances into the bore" : waves ? "Illustrative ground pulse" : "Normal water pumping",
    contact: injection ? arrival : 0,
    flowClock,
    extinguishing: clamp((time - PRESENTATION_TIMING2.waterStart) / 17)
  };
}

// src/alternatives/pressure-pulse-liquid-waves/model.ts
function createLiquidWavesRun(config, hooks) {
  if (config.variantId !== "liquid-waves") throw new Error("4.2.3.1 adapter requires liquid-waves identity.");
  if (config.engine !== "contact" && config.engine !== "concept") throw new Error("4.2.3.1 has no coupled treatment engine.");
  if (config.medium !== "water" && config.medium !== "unspecified") throw new Error("4.2.3.1 supports ordinary water or an unspecified concept source only.");
  if (config.engine === "contact" && config.medium !== "water") throw new Error("Unspecified source has no thermodynamic properties.");
  const owned = structuredClone(config);
  owned.thermal.dryIceKg = 0;
  return hooks.supportedRun(owned);
}
function liquidWavesPresentation(id, timeS) {
  if (id !== "liquid-waves") throw new Error("4.2.3.1 presentation requires liquid-waves identity.");
  const time = Number.isFinite(timeS) ? Math.max(0, Math.min(90, timeS)) : 0;
  const frame = liquidAnimationFrame(time);
  return {
    contextTime: time,
    access: true,
    pulse: time >= 55 && time < 56.5,
    waves: frame.waves,
    injection: frame.injection,
    vibration: 0,
    contacts: frame.injection ? 1 : 0
  };
}

// src/alternatives/pressure-pulse-liquid-waves/index.ts
var variants2 = [{
  id: "liquid-waves",
  method: "4.2.3",
  number: "4.2.3.1",
  label: "Liquid-pressure waves then injection",
  subtitle: "Original 4.2.3 sequence \xB7 opposing trucks, rigid pipe and intermittent ground pulses",
  draft: true,
  engines: ["contact", "concept"],
  media: ["water", "unspecified"],
  defaultMedium: "water",
  defaultEngine: "contact",
  stages: ["Original fire and access sequence", "Original dry-ice release and truck deployment", "Normal pumping with hydraulic pulses"],
  limitation: "Pressure-wave propagation, infiltration and structural response are unavailable. The user-requested fracture and extinguishing sequence is an authored illustration, not a predicted outcome. Only the separate finite ordinary-water contact calorimeter is modeled; added visual pulses contribute no modeled source, cooling or permeability benefit. The editable 12 s contact arrival is a scenario assumption, separate from the presentation clock.",
  status: { illustrative: true, modeled: "Finite liquid-water contact calorimeter only", experimentallyValidated: false },
  provenance: "User capstone subsection; unchanged external contact reference with constant-property approximations. See method evidence for assumptions and official water-property references."
}];
var methodModule2 = {
  apiVersion: ALTERNATIVE_API_VERSION,
  method: "4.2.3",
  variants: variants2,
  defaultSettings: () => ({ contactStartS: 12 }),
  createRun: createLiquidWavesRun,
  presentation: liquidWavesPresentation
};

// src/alternatives/pressure-pulse-pressure-only/model.ts
function createPressureOnlyRun(config, hooks) {
  if (config.variantId !== "pressure-only") throw new Error("4.2.3.2 adapter requires pressure-only identity.");
  if (config.engine !== "concept") throw new Error("4.2.3.2 has no supported physical adapter; outcomes are N/A.");
  if (config.medium !== "none" && config.medium !== "unspecified") throw new Error("4.2.3.2 never injects liquid or solid treatment medium.");
  const owned = structuredClone(config);
  Object.assign(owned.thermal, { enabled: false, waterKg: 0, flowKgS: 0, dryIceKg: 0, conductanceWK: 0 });
  return hooks.supportedRun(owned);
}
function pressureOnlyPresentation(id, timeS) {
  if (id !== "pressure-only") throw new Error("4.2.3.2 presentation requires pressure-only identity.");
  const time = Number.isFinite(timeS) ? Math.max(0, Math.min(90, timeS)) : 0;
  return {
    contextTime: Math.min(time, 36),
    access: true,
    pulse: time >= 38 && time < 66,
    waves: false,
    injection: false,
    vibration: 0,
    contacts: 0
  };
}

// src/alternatives/pressure-pulse-pressure-only/index.ts
var variants3 = [{
  id: "pressure-only",
  method: "4.2.3",
  number: "4.2.3.2",
  label: "Rapid pressure change without liquid",
  subtitle: "Descriptive draft label \xB7 no liquid injection",
  draft: true,
  engines: ["concept"],
  media: ["none", "unspecified"],
  defaultMedium: "none",
  defaultEngine: "concept",
  stages: ["Excavator-drilled access", "Abstract rapid pressure change", "Observe an unresolved soil-response hypothesis"],
  limitation: "No liquid or thermal source is instantiated. Pressure propagation, soil rearrangement/collapse and suppression remain unavailable without a constitutive and transport model; all physical metrics are N/A.",
  status: { illustrative: true, modeled: "Unavailable \u2014 pressure/soil response not coupled", experimentallyValidated: false },
  provenance: "User capstone subsection; generic environmental input with unspecified source properties. No device, pressure law or measured outcome is inferred."
}];
var methodModule3 = {
  apiVersion: ALTERNATIVE_API_VERSION,
  method: "4.2.3",
  variants: variants3,
  defaultSettings: () => ({ contactStartS: 8 }),
  createRun: createPressureOnlyRun,
  presentation: pressureOnlyPresentation
};

// src/alternatives/vibratory-injection/vibration.ts
var VIBRATION_TIMELINE = { start: 27, rampEnd: 33, holdContext: 33, taperStart: 68, stop: 74, end: 90 };
function vibrationPose(time, enabled = true) {
  const t = Number.isFinite(time) ? Math.max(0, Math.min(VIBRATION_TIMELINE.end, time)) : 0;
  const amount = enabled ? eased(t, VIBRATION_TIMELINE.start, VIBRATION_TIMELINE.rampEnd) * (1 - eased(t, VIBRATION_TIMELINE.taperStart, VIBRATION_TIMELINE.stop)) : 0;
  const x = amount * (0.026 * Math.sin(t * 26) + 9e-3 * Math.sin(t * 39));
  const y = amount * 0.014 * Math.sin(t * 31);
  const fracture = enabled ? eased(t, 33, 46) : 0;
  const compression = enabled ? eased(t, 44, 68) : 0;
  const emberFade = enabled ? eased(t, 50, 74) : 0;
  const shrink = compression * 0.028;
  return {
    time: t,
    contextTime: Math.min(t, VIBRATION_TIMELINE.holdContext),
    amount,
    fracture,
    compression,
    emberFade,
    groundScale: [1, 1 - shrink, 1],
    surfacePosition: [x, y - 3.2 * shrink, 0],
    groundPosition: [x, y, 0],
    groundTilt: amount * 25e-4 * Math.sin(t * 23),
    toolPosition: [amount * 0.024 * Math.sin(t * 35), amount * 0.022 * Math.sin(t * 29), 0]
  };
}

// src/alternatives/vibratory-injection/model.ts
var PREDICTION_UNAVAILABLE = "Vibration-only prediction is unavailable: forcing, mechanical work, cyclic peat constitutive response and independent validation are missing.";
var defaultSettings = { enabled: false, waterKg: 0, flowKgS: 0, dryIceKg: 0, conductanceWK: 0, contactStartS: 0 };
function createVibratoryRun(config) {
  if (config.variantId !== "vibratory-injection") throw new Error("Vibratory adapter requires its own variant identity.");
  throw new Error(PREDICTION_UNAVAILABLE);
}
function vibratoryPresentation(id, timeS) {
  if (id !== "vibratory-injection") throw new Error("Vibratory presentation requires its own variant identity.");
  const pose = vibrationPose(timeS);
  return { contextTime: pose.contextTime, access: pose.time >= 24, pulse: false, waves: false, injection: false, vibration: pose.groundPosition[0], contacts: 0 };
}

// src/alternatives/vibratory-injection/index.ts
var status = (modeled) => ({ illustrative: true, modeled, experimentallyValidated: false });
var provenance2 = "User-supplied Version21 work pack; capstone concepts, not measured performance";
var variants4 = [
  { id: "vibratory-injection", method: "4.2.4", number: "4.2.4", label: "Earthquake Extinguisher", subtitle: "Vibratory drilling \xB7 vibration only", engines: [], media: ["none"], defaultMedium: "none", defaultEngine: "concept", stages: ["Original fire and drilling", "Illustrative vibration", "Illustrated soil rearrangement and fire-out"], limitation: PREDICTION_UNAVAILABLE, status: status("Unavailable \u2014 vibration mechanics unsupported"), provenance: provenance2 }
];
var methodModule4 = {
  apiVersion: ALTERNATIVE_API_VERSION,
  method: "4.2.4",
  variants: variants4,
  defaultSettings: () => ({ ...defaultSettings }),
  createRun: createVibratoryRun,
  presentation: vibratoryPresentation
};

// src/alternatives/fine-dry-ice-injection/physics.ts
var PROPERTIES = Object.freeze({ surfaceK: 195, latentJkg: 25200 / 0.0440095, waterCpJkgK: 4186, gasCpJkgK: 850 });
var { surfaceK: TS, latentJkg: L, waterCpJkgK: CW, gasCpJkgK: CG } = PROPERTIES;
var UNAVAILABLE = ["Aqueous film/ice-shell and blockage coupling", "Particle slip, filtration, deposition and peat penetration", "Pressure-driven liquid flow and spatial wetting", "Gas/O2 mixture and boundary exchange fields", "Tank pressure", "Reacting fire, extinction and re-ignition", "Ambient reheating and drainage"];
var empty = () => ({ water: 0, gas: 0, h: 0, cohorts: [] });
function solid(c2, p) {
  return c2.cohorts.reduce((a2, b2) => a2 + b2.count * 4 * Math.PI / 3 * p.solidDensityKgM3 * b2.radiusM ** 3, 0);
}
function temperature(c2) {
  const capacity = c2.water * CW + c2.gas * CG;
  return capacity > 0 ? TS + (c2.h - c2.gas * L) / capacity : null;
}
function checkLiquid(t, location, time) {
  if (t !== null && (t < 273.15 - 1e-8 || t > 350 + 1e-8)) throw new Error(`Out of liquid-carrier regime at ${location}, t=${time.toFixed(6)} s: ${t.toFixed(3)} K. Bulk freezing/overheating invalidates this model; local ice shells and blockage are unverified even above freezing.`);
}
function sphereRadiusSquared(r0, k, bathK, rho, latent, timeS) {
  return Math.max(0, r0 * r0 - 2 * k * Math.max(0, bathK - TS) * timeS / (rho * latent));
}
function twoCapacityHeatJ(hotK, coldK, a2, b2, ua, dt) {
  if (a2 <= 0 || b2 <= 0 || ua === 0 || dt === 0) return 0;
  const reciprocal = 1 / a2 + 1 / b2;
  return (hotK - coldK) * -Math.expm1(-ua * dt * reciprocal) / reciprocal;
}
function validateParticleConfig(config) {
  if (config.variantId !== "nanoparticles" || config.engine !== "particle" || !["water", "co2-water"].includes(config.medium)) throw new Error("4.2.2 requires its particle engine and water or CO2-water medium.");
  if (!config.id?.trim() || typeof config.thermal.enabled !== "boolean" || !Number.isSafeInteger(config.thermal.seed)) throw new Error("Independent panel ID, intervention flag and integer seed are required.");
  const p = config.particleInjection;
  if (!p) throw new Error("Explicit particle configuration including size, SI units and provenance is required.");
  const limits = { particleDiameterM: [1e-5, 5e-4], effectiveConductivityWmK: [6e-4, 0.6], solidDensityKgM3: [800, 1650], hoseResidenceS: [0, 20], probeResidenceS: [0, 10], dryPeatMassKg: [0.01, 10], initialMoistureDryBasis: [0, 1], dryPeatCpJkgK: [500, 3e3], stepS: [3125e-7, 0.02], parcelStepS: [0.0125, 0.5] };
  for (const key of Object.keys(limits)) {
    const [lo, hi] = limits[key];
    if (!Number.isFinite(p[key]) || p[key] < lo || p[key] > hi) throw new Error(`Unsupported ${key}; expected ${lo}\u2013${hi} in SI units.`);
  }
  for (const key of ["sizeProvenance", "heatTransferProvenance", "residenceProvenance", "soilProvenance"]) if (typeof p[key] !== "string" || !p[key].trim()) throw new Error(`Explicit ${key} required; assumptions are not measurements.`);
  if (!["solid", "pre-sublimated"].includes(p.initialPhase)) throw new Error("Unknown initial CO2 phase.");
  const limitsT = { initialK: [300, 350], inletK: [273.15, 350], waterKg: [0, 5], dryIceKg: [0, 1], flowKgS: [0, 0.2], contactStartS: [0, 50], conductanceWK: [0, 100], endS: [10, 120] };
  for (const key of Object.keys(limitsT)) {
    const [lo, hi] = limitsT[key], v = config.thermal[key];
    if (!Number.isFinite(v) || v < lo || v > hi) throw new Error(`Unsupported ${key}: this nonreacting warm-specimen/liquid diagnostic requires ${lo}\u2013${hi}. Fire/boiling coupling is unavailable.`);
  }
  if (config.thermal.waterKg === 0 && config.medium === "co2-water" && config.thermal.dryIceKg > 0) throw new Error("Solid/gas without liquid carrier is outside the particle-in-water model.");
  return structuredClone(p);
}
function simulateParticle(configInput, targetS) {
  const config = structuredClone(configInput), p = validateParticleConfig(config), t = config.thermal;
  if (!Number.isFinite(targetS) || targetS < 0 || targetS > t.endS + 1e-9) throw new Error("Invalid particle observation target.");
  const initialCO2 = config.medium === "co2-water" ? t.dryIceKg : 0;
  const source = empty(), soil = empty(), parcels = [], releases = [];
  source.water = t.waterKg;
  source.h = source.water * CW * (t.inletK - TS);
  if (initialCO2 > 0) source.cohorts = [{ count: initialCO2 / (4 * Math.PI / 3 * p.solidDensityKgM3 * (p.particleDiameterM / 2) ** 3), radiusM: p.particleDiameterM / 2 }];
  let upstream = 0, underground = 0, solidEntry = 0, co2Entry = 0, waterEntry = 0, heatPeat = 0, peatK = t.initialK;
  const peatCapacity = p.dryPeatMassKg * (p.dryPeatCpJkgK + p.initialMoistureDryBasis * CW);
  const initialH = source.h + peatCapacity * (peatK - TS);
  function record(location, fromS, toS, massKg) {
    if (massKg <= 0) return;
    const bin = Math.floor((fromS + toS) / 2 / 0.25);
    let item = releases.find((r) => r.location === location && Math.floor((r.fromS + r.toS) / 2 / 0.25) === bin);
    if (!item) {
      item = { location, fromS, toS, massKg: 0, latentJ: 0 };
      releases.push(item);
    }
    item.fromS = Math.min(item.fromS, fromS);
    item.toS = Math.max(item.toS, toS);
    item.massKg += massKg;
    item.latentJ += massKg * L;
  }
  if (t.enabled && p.initialPhase === "pre-sublimated" && initialCO2 > 0) {
    source.gas = initialCO2;
    source.cohorts = [];
    upstream = initialCO2;
    checkLiquid(temperature(source), "pre-sublimated source", 0);
    record("source", 0, 0, initialCO2);
  }
  function phase2(c2, location, fromS, toS) {
    const bath = temperature(c2), oldMass = solid(c2, p);
    if (bath === null || oldMass === 0 || toS <= fromS) return;
    const gap = L + CG * (bath - TS);
    const next = c2.cohorts.map((b2) => ({ ...b2, radiusM: Math.sqrt(sphereRadiusSquared(b2.radiusM, p.effectiveConductivityWmK, bath, p.solidDensityKgM3, gap, toS - fromS)) }));
    const trial = { ...c2, cohorts: next }, dm = Math.max(0, oldMass - solid(trial, p));
    trial.gas += dm;
    checkLiquid(temperature(trial), location, toS);
    c2.cohorts = next.filter((b2) => b2.radiusM > 0);
    c2.gas = trial.gas;
    if (location === "soil") underground += dm;
    else upstream += dm;
    record(location, fromS, toS, dm);
  }
  function merge(into, from) {
    into.water += from.water;
    into.gas += from.gas;
    into.h += from.h;
    into.cohorts.push(...from.cohorts);
    checkLiquid(temperature(into), "mixed soil carrier", clock2);
  }
  const duration = t.flowKgS > 0 ? t.waterKg / t.flowKgS : Infinity;
  let dispatchIndex = 1, clock2 = 0;
  function dispatchTime() {
    return t.contactStartS + Math.min(dispatchIndex * p.parcelStepS, duration);
  }
  function dispatch() {
    const water = Math.min(source.water, t.flowKgS * p.parcelStepS);
    if (water <= 1e-14 || source.water <= 0) return;
    const f = water / source.water, out2 = { water, gas: source.gas * f, h: source.h * f, cohorts: source.cohorts.map((b2) => ({ count: b2.count * f, radiusM: b2.radiusM })) };
    source.water -= water;
    source.gas *= 1 - f;
    source.h *= 1 - f;
    source.cohorts.forEach((b2) => b2.count *= 1 - f);
    if (source.water < 1e-13) {
      source.water = 0;
      source.gas = 0;
      source.h = 0;
      source.cohorts = [];
    }
    parcels.push({ carrier: out2, dispatchedS: clock2, hoseEndS: clock2 + p.hoseResidenceS, groundS: clock2 + p.hoseResidenceS + p.probeResidenceS });
    dispatchIndex++;
  }
  while (t.enabled && clock2 < targetS - 1e-11) {
    let next = Math.min(targetS, (Math.floor((clock2 + 1e-10) / p.stepS) + 1) * p.stepS);
    if (source.water > 1e-14 && t.flowKgS > 0 && dispatchTime() > clock2 + 1e-10) next = Math.min(next, dispatchTime());
    for (const parcel of parcels) for (const boundary of [parcel.hoseEndS, parcel.groundS]) if (boundary > clock2 + 1e-10) next = Math.min(next, boundary);
    const dt = next - clock2;
    phase2(source, "source", clock2, next);
    for (const parcel of parcels) phase2(parcel.carrier, clock2 < parcel.hoseEndS - 1e-9 ? "hose" : "probe", clock2, next);
    const carrierK = temperature(soil);
    if (carrierK !== null) {
      const q = twoCapacityHeatJ(peatK, carrierK, peatCapacity, soil.water * CW + soil.gas * CG, t.conductanceWK, dt);
      const trial = { ...soil, h: soil.h + q };
      checkLiquid(temperature(trial), "soil contact", next);
      soil.h += q;
      peatK -= q / peatCapacity;
      heatPeat += q;
      phase2(soil, "soil", clock2, next);
    }
    clock2 = next;
    if (source.water > 1e-14 && t.flowKgS > 0 && clock2 >= dispatchTime() - 1e-9) dispatch();
    for (let i = parcels.length - 1; i >= 0; i--) if (clock2 >= parcels[i].groundS - 1e-9) {
      const c2 = parcels[i].carrier;
      solidEntry += solid(c2, p);
      co2Entry += solid(c2, p) + c2.gas;
      waterEntry += c2.water;
      merge(soil, c2);
      parcels.splice(i, 1);
    }
  }
  function inventory(c2) {
    return { waterKg: c2.water, solidKg: solid(c2, p), gasKg: c2.gas, enthalpyJ: c2.h, temperatureK: temperature(c2) };
  }
  const hose = empty(), probe = empty();
  for (const parcel of parcels) {
    const c2 = clock2 < parcel.hoseEndS - 1e-9 ? hose : probe;
    c2.water += parcel.carrier.water;
    c2.gas += parcel.carrier.gas;
    c2.h += parcel.carrier.h;
    c2.cohorts.push(...parcel.carrier.cohorts);
  }
  const carriers = { source, hose, probe, soil }, locations = Object.fromEntries(Object.entries(carriers).map(([k, c2]) => [k, inventory(c2)]));
  const all = Object.values(locations);
  const mean = Object.fromEntries(Object.entries(carriers).map(([key, c2]) => {
    const m = solid(c2, p);
    return [key, m > 0 ? c2.cohorts.reduce((a2, b2) => a2 + b2.count * 4 * Math.PI / 3 * p.solidDensityKgM3 * b2.radiusM ** 3 * 2 * b2.radiusM, 0) / m : null];
  }));
  return {
    schema: "particle-delivery-d1",
    timeS: targetS,
    modelTier: "Unvalidated finite-inventory saturated-film thermal/entrainment sensitivity; nominated underground calorimeter only",
    locations,
    releases,
    solidEnteringGroundKg: solidEntry,
    co2EnteringGroundKg: co2Entry,
    waterEnteringGroundKg: waterEntry,
    upstreamSublimatedKg: upstream,
    undergroundSublimatedKg: underground,
    initialCO2Kg: initialCO2,
    upstreamFractionInitialCO2: initialCO2 > 0 ? upstream / initialCO2 : null,
    undergroundFractionInitialCO2: initialCO2 > 0 ? underground / initialCO2 : null,
    probeSurvivalFractionArrivedCO2: co2Entry > 0 ? solidEntry / co2Entry : null,
    peatTemperatureK: peatK,
    retainedMoistureDryBasis: p.initialMoistureDryBasis + soil.water / p.dryPeatMassKg,
    heatFromPeatJ: heatPeat,
    waterMassResidualKg: all.reduce((a2, c2) => a2 + c2.waterKg, 0) - t.waterKg,
    co2MassResidualKg: all.reduce((a2, c2) => a2 + c2.solidKg + c2.gasKg, 0) - initialCO2,
    energyResidualJ: all.reduce((a2, c2) => a2 + c2.enthalpyJ, 0) + peatCapacity * (peatK - TS) - initialH,
    initialEnthalpyJ: initialH,
    additionalColdResourceJ: initialCO2 * (L + CG * (t.inletK - TS)),
    meanSolidDiameterM: mean,
    pressurePa: null,
    oxygenMoleFraction: null,
    extinction: null,
    penetrationM: null,
    unavailable: [...UNAVAILABLE],
    assumptions: [p.sizeProvenance, p.heatTransferProvenance, p.residenceProvenance, p.soilProvenance, "Solid is initially saturated/isothermal at195K; cp-water4186 and cp-gas850J/(kgK) are constant approximations, not full property correlations.", "Adiabatic source/transport; water and CO2 gas enthalpy travel together, no vent/slip. Prescribed delivery into a nominated contact specimen; no predicted penetration.", "Local ice shells/blockage remain unresolved even when bulk water is273.15\u2013350K.", "Parcel withdrawal uses right-endpoint quadrature; phase uses finite-bath explicit r-squared updates and conservative enthalpy, finite-UA pair exchange."],
    review: "No verified realism pass; initial placeholder1.3/10. Signed candidate scores and frozen identity are in the D REALISM_LEDGER. Experimental validation:false.",
    metadata: { panelId: config.id, seed: t.seed, observationS: t.endS, particleSizeProvenance: p.sizeProvenance, units: "SI; kelvin; mass fractions use stated denominators", numericalStepS: p.stepS, parcelStepS: p.parcelStepS }
  };
}
function createParticleRun(configInput) {
  const config = structuredClone(configInput);
  validateParticleConfig(config);
  let state = simulateParticle(config, 0);
  function snapshot() {
    return { timeS: state.timeS, particleInjection: structuredClone(state), metrics: { maximumK: state.peatTemperatureK, waterUsedKg: state.waterEnteringGroundKg, dryIceUsedKg: state.upstreamSublimatedKg + state.undergroundSublimatedKg, energyJ: state.heatFromPeatJ, energyResidualJ: state.energyResidualJ, massResidualKg: Math.max(Math.abs(state.waterMassResidualKg), Math.abs(state.co2MassResidualKg)), oxygenKg: null, fuelKg: null, reactionW: null } };
  }
  return { endS: config.thermal.endS, snapshot, advanceTo(targetS) {
    if (!Number.isFinite(targetS) || targetS < state.timeS - 1e-9 || targetS > config.thermal.endS + 1e-9) throw new Error("Invalid physical target.");
    const next = simulateParticle(config, targetS);
    state = next;
    return snapshot();
  } };
}

// src/alternatives/fine-dry-ice-injection/index.ts
var variants5 = [{
  id: "nanoparticles",
  method: "4.2.2",
  number: "4.2.2",
  label: "Solid Inert Gas Nano Particles",
  subtitle: "Water + fine dry-ice particle injection",
  engines: ["particle"],
  media: ["water", "co2-water"],
  defaultEngine: "particle",
  defaultMedium: "co2-water",
  stages: ["Continuous source sublimation", "Hose + probe survival test", "Conditional underground sublimation", "Observe the thermal specimen"],
  limitation: "Unvalidated finite-inventory thermal/entrainment sensitivity. Fine particles may disappear before the probe. Residence and film resistance are assumptions; local freezing, blockage, filtration, peat penetration, gas/O2 fields, pressure, reacting-fire suppression and re-ignition are unavailable. Warm nonreacting specimen273.15\u2013350K only; no experimental validation.",
  status: { illustrative: true, modeled: "Shrinking particles + finite water/gas enthalpy + prescribed residence + nominated peat calorimeter; conditional/unvalidated", experimentallyValidated: false },
  provenance: "Human capstone description supplies mechanism only. Explicit analytical study sizes and all unmeasured transport/soil assumptions are exposed; no Nano size inference."
}];
var methodModule5 = {
  apiVersion: PARTICLE_API_VERSION,
  method: "4.2.2",
  variants: variants5,
  defaultSettings: () => ({ enabled: true, waterKg: 1, flowKgS: 0.1, dryIceKg: 0.01, initialK: 333.15, inletK: 293.15, contactStartS: 1, conductanceWK: 2, endS: 30 }),
  createRun: (config) => createParticleRun(config),
  presentation: (_id, time) => ({ contextTime: Math.min(Math.max(0, time), 38), access: true, pulse: false, waves: false, injection: false, vibration: 0, contacts: 0 })
};

// src/alternatives/modules.ts
var METHOD_MODULES = [methodModule, methodModule2, methodModule3, methodModule4, methodModule5];
function findMethodModule(id) {
  return METHOD_MODULES.find((m) => m.variants.some((v) => v.id === id));
}

// src/alternatives/fine-dry-ice-injection/config.ts
function defaultParticleInjectionSettings() {
  return {
    particleDiameterM: 1e-4,
    sizeProvenance: "Configured 100 micrometre monodisperse analytical study; unmeasured, not inferred from Nano.",
    effectiveConductivityWmK: 0.6,
    heatTransferProvenance: "Steady spherical conduction reference; effective film conductivity is an unmeasured sensitivity, not an aqueous-particle correlation.",
    solidDensityKgM3: 1560,
    hoseResidenceS: 1,
    probeResidenceS: 0.1,
    residenceProvenance: "Prescribed ideal entrained parcel residence; no pressure, slip, filtration or blockage model.",
    dryPeatMassKg: 0.5,
    initialMoistureDryBasis: 0.1,
    dryPeatCpJkgK: 1500,
    soilProvenance: "Assumed isolated warm peat specimen; finite UA sensitivity. No measured field constitutive law.",
    initialPhase: "solid",
    stepS: 5e-3,
    parcelStepS: 0.025
  };
}

// src/story/contactCooling.ts
var CONTACT_COOLING_CONFIG = {
  startTimeS: 44,
  rapidRemovalTimeS: 55,
  endTimeS: FIRE_SEQUENCE_DURATION,
  stepS: 0.05,
  initialTemperatureK: 823.15,
  waterInletK: 293.15,
  waterBoilingK: 373.15,
  peatHeatCapacityJkgK: 1840,
  waterHeatCapacityJkgK: 4186,
  waterLatentHeatJkg: 226e4,
  dryIceInitialKg: 4,
  dryIceTemperatureK: 194.67,
  dryIceLatentHeatJkg: 6030 * 4.184 / 0.0440095,
  waterInitialKg: 5,
  waterFlowKgS: 0.22,
  waterStartTimeS: STORY_WATER_START
};
var share = 1 / (1 + STORY_CRACK_PATHS.length * 2);
var CONTACT_COOLING_PATCHES = [
  {
    id: "bore-base",
    xM: 0.4,
    yM: -1.44,
    radiusM: 0.2,
    peatMassKg: 0.5,
    dryIceConductanceWK: 8,
    waterConductanceWK: 48,
    waterArrivalTimeS: STORY_WATER_START,
    waterShare: share
  },
  ...STORY_CRACK_PATHS.flatMap((points, branch) => [0.2, 0.45].map((fraction, index) => {
    const [xM, yM] = pointAlongStoryPath(points, fraction);
    let lo = STORY_WATER_START, hi = FIRE_SEQUENCE_DURATION;
    for (let i = 0; i < 45; i++) {
      const mid = (lo + hi) / 2;
      if (storyWettingProgress(mid, branch) < fraction) lo = mid;
      else hi = mid;
    }
    return {
      id: `branch-${branch}-${index}`,
      xM,
      yM,
      radiusM: index ? 0.17 : 0.14,
      peatMassKg: 0.5,
      dryIceConductanceWK: 0,
      waterConductanceWK: 48,
      waterArrivalTimeS: (lo + hi) / 2,
      waterShare: share
    };
  }))
];

// src/alternatives/originalPressurePulse.ts
var ORIGINAL_PRESSURE_PULSE = {
  id: "pressure-pulse",
  method: "4.2.3",
  number: "4.2.3",
  label: "Subsurface Pressure Pulse",
  subtitle: "Original rapid dry-ice release & connected water render",
  engines: [],
  media: ["none"],
  defaultMedium: "none",
  defaultEngine: "concept",
  stages: ["Original fire sequence", "Original rapid release", "Original connected water"],
  limitation: "Protected original render. Its existing accepted fields and separate contact readout remain available through the original workspace. An independent live-comparison adapter is unavailable; new comparison metrics are N/A. Open 4.2.3 in Simulation Version to use the original unchanged.",
  status: { illustrative: true, modeled: "Existing accepted numerical history and separate contact model; no new live comparison adapter", experimentallyValidated: false },
  provenance: "Verified V20 original: 161e7a4a1f8c35765e1878c132db79977be1f5ea; source/hash baseline in docs/review/version21/original-preservation.json"
};

// src/alternatives/registry.ts
var status2 = (modeled) => ({ illustrative: true, modeled, experimentallyValidated: false });
var SHARED_VARIANTS = [
  { id: "baseline", method: "baseline", number: "00", label: "No-treatment baseline", subtitle: "Untreated smoldering reference / isolated thermal reference", engines: ["peat-fem", "contact", "concept"], media: ["none"], defaultMedium: "none", defaultEngine: "contact", stages: ["Initial conditions", "No intervention", "Observe reference"], limitation: "Contact reference is an isolated hot specimen with no combustion. Select Peat Fire FEM for reacting smoldering physics.", status: status2("FEM combustion or isolated contact reference"), provenance: "Existing peat FEM and contact-cooling models" }
];
var VARIANTS = [SHARED_VARIANTS[0], ...METHOD_MODULES[0].variants, ...METHOD_MODULES[4].variants, ORIGINAL_PRESSURE_PULSE, ...METHOD_MODULES[1].variants, ...METHOD_MODULES[2].variants, ...METHOD_MODULES[3].variants];
function variant(id) {
  return VARIANTS.find((v) => v.id === id) ?? VARIANTS[0];
}
var PARAMETERS = [
  { key: "initialK", label: "Initial specimen temperature", unit: "K", min: 300, max: 1e3, step: 10, default: 823.15 },
  { key: "waterKg", label: "Finite liquid inventory", unit: "kg", min: 0, max: 5, step: 0.1, default: 0.5 },
  { key: "flowKgS", label: "Prescribed contact delivery", unit: "kg/s", min: 0, max: 0.2, step: 5e-3, default: 0.025 },
  { key: "inletK", label: "Assumed liquid inlet temperature", unit: "K", min: 273.15, max: 350, step: 1, default: 293.15 },
  { key: "contactStartS", label: "Prescribed liquid arrival", unit: "s", min: 0, max: 50, step: 1, default: 8 },
  { key: "conductanceWK", label: "Assumed thermal contact UA", unit: "W/K", min: 0, max: 100, step: 1, default: 24 },
  { key: "dryIceKg", label: "Finite CO\u2082 contact-proxy inventory", unit: "kg", min: 0, max: 1, step: 0.01, default: 0.05 },
  { key: "endS", label: "Observation window", unit: "s", min: 10, max: 120, step: 10, default: 60 }
];
function defaultThermal(id) {
  return { ...Object.fromEntries(PARAMETERS.map((p) => [p.key, p.default])), enabled: true, seed: 21, ...findMethodModule(id)?.defaultSettings(id) };
}

// src/peatfem/model.ts
var MATERIAL = Object.freeze({
  rho: 123,
  cp: 1840,
  phi: 1 - 123 / 1500,
  conductivity: 123 / 1500,
  diffusivity: 2e-5,
  gasReferenceDensity: 1.2,
  log10A: 16.8,
  activationJMol: 195e3,
  fuelOrder: 2.33,
  oxygenOrder: 0.24,
  oxygenPerFuel: 0.89,
  charYield: 0.61,
  heatJPerKg: 116e5
});
var DEFAULT_SETTINGS = {
  n: 4,
  lengthM: 0.1,
  ambientK: 300,
  oxygenKgM3: 0.233 * MATERIAL.gasReferenceDensity,
  ignitionW: 8,
  ignitionS: 180,
  ignitionWidthM: 0.025,
  heatTransfer: 10,
  massTransferMS: 2e-3,
  maxStepS: 2,
  endS: 600,
  chemistry: true
};
var SIGNS = Array.from({ length: 8 }, (_, a2) => [a2 & 1 ? 1 : -1, a2 & 2 ? 1 : -1, a2 & 4 ? 1 : -1]);
var EMPTY_INTERVENTIONS = Object.freeze([]);

// src/peatfem/chemistry.ts
var CONSTITUENTS = Object.freeze({
  density: [1e3, 1500, 1300, 1300, 2500],
  // intrinsic kg/m³, C4 Table 2
  cp: [4186, 1840, 1260, 1260, 880],
  // J/(kg K), C4 Table 2
  conductivity: [0.6, 1, 0.26, 0.26, 1.2],
  // W/(m K), C4 Table 2
  molecularKgMol: [0.031998, 0.028014, 0.01801528, 0.02897],
  gasCp: 1e3
  // common-gas-cp approximation: explicit illustrative value, not measured
});

// src/peatfem/coupled.ts
var DEFAULT_SETTINGS2 = {
  n: 4,
  lengthM: 0.1,
  ambientK: 300,
  oxygenMassFraction: 0.233,
  moistureRatio: 0.1,
  dryDensityKgM3: 123,
  ambientPressurePa: 101325,
  ignitionW: 8,
  ignitionS: 180,
  ignitionWidthM: 0.025,
  heatTransfer: 10,
  transferKgM2S: 0.01,
  permeabilityM2: 1e-12,
  poreRadiationM: 5e-4,
  gasDiffusivityM2S: 2e-5,
  gasViscosityPaS: 18e-6,
  emissivity: 0.95,
  gravityMS2: 0,
  maxStepS: 1,
  endS: 600,
  chemistry: true,
  closed: false
};

// src/alternatives/model.ts
function freshPanel(id, variantId) {
  const v = variant(variantId);
  return {
    id,
    variantId,
    engine: v.defaultEngine,
    medium: v.defaultMedium,
    sourceStatus: "unspecified",
    thermal: defaultThermal(variantId),
    fem: { ...DEFAULT_SETTINGS2 },
    ...variantId === "nanoparticles" ? { particleInjection: defaultParticleInjectionSettings() } : {}
  };
}

// ../short-life-edge.mts
var L2 = 25200 / 0.0440095;
var CW2 = 4186;
var CG2 = 850;
var TS2 = 195;
function reference(end, step = 1e-5) {
  const m0 = 0.01, mw = 1, r0 = 5e-6, rho = 1560, k = 0.6, H = mw * CW2 * (293.15 - TS2);
  let u = 1, I = 0, time = 0;
  const f = (v) => {
    if (v <= 0) return [0, 0];
    const g = m0 * (1 - Math.pow(Math.max(0, v), 1.5));
    const gap = (H - g * L2) / (mw * CW2 + g * CG2);
    return [-2 * k * gap / (rho * r0 * r0 * (L2 + CG2 * gap)), Math.pow(Math.max(0, v), 1.5)];
  };
  while (time < end - 1e-13) {
    const h = Math.min(step, end - time), a2 = f(u), b2 = f(u + h * a2[0] / 2), c2 = f(u + h * b2[0] / 2), d = f(u + h * c2[0]);
    u = Math.max(0, u + h * (a2[0] + 2 * b2[0] + 2 * c2[0] + d[0]) / 6);
    I += h * (a2[1] + 2 * b2[1] + 2 * c2[1] + d[1]) / 6;
    time += h;
  }
  const gas = m0 * (1 - Math.pow(u, 1.5));
  return { timeS: end, u, solidKg: m0 * Math.pow(u, 1.5), gasKg: gas, temperatureK: TS2 + (H - gas * L2) / (mw * CW2 + gas * CG2), integratedFractionS: I };
}
var c = freshPanel("D-short-life-edge", "nanoparticles");
c.thermal.contactStartS = 0;
Object.assign(c.particleInjection, { particleDiameterM: 1e-5, sizeProvenance: "Independent reviewer configured 10 micrometre analytical edge case; unmeasured.", effectiveConductivityWmK: 0.6, hoseResidenceS: 0, probeResidenceS: 0, stepS: 3125e-7, parcelStepS: 0.0125 });
var actual = simulateParticle(c, 1);
var a = reference(1e-3, 1e-8);
var b = reference(1e-3, 25e-10);
var independentEntryKg = 1e-3 * b.integratedFractionS;
var out = { runId: "D-retry1-independent-short-life-edge-2026-10-12", config: c, sourceAndTransit: "Same homogeneous adiabatic finite-bath surrogate; zero prescribed transit and immediate continuous withdrawal", independentContinuousEntryKg: independentEntryKg, referenceStepDifferenceKg: 1e-3 * Math.abs(a.integratedFractionS - b.integratedFractionS), modelEntryKg: actual.solidEnteringGroundKg, relativeEntryError: (actual.solidEnteringGroundKg - independentEntryKg) / independentEntryKg, modelUpstreamKg: actual.upstreamSublimatedKg, firstParcelDispatchS: 0.0125, fixedBathLatentLifetimeS: 1560 * L2 * 5e-6 ** 2 / (2 * 0.6 * (293.15 - 195)), observation: "Allowed short-life case is completely unresolved even at minimum parcel interval; right-endpoint dispatch delays initial withdrawal past extinction. No resolution warning/rejection currently provided." };
fs.writeFileSync(new URL("./short-life-edge-results.json", import.meta.url), JSON.stringify(out, null, 2));
console.log(JSON.stringify(out, null, 2));
