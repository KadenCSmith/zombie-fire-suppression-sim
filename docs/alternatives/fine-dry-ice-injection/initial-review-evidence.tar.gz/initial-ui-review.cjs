const {app,BrowserWindow}=require('electron');
const fs=require('node:fs'),path=require('node:path');
app.setPath('userData','/tmp/agent-d-independent-review/electron-initial-profile');
app.commandLine.appendSwitch('disable-background-timer-throttling');
const timeout=setTimeout(()=>{console.error('initial reviewer UI timeout');app.exit(1)},45000);
app.whenReady().then(async()=>{
 const win=new BrowserWindow({show:false,width:1440,height:1100,webPreferences:{contextIsolation:true,nodeIntegration:false,backgroundThrottling:false}});
 const errors=[];win.webContents.on('console-message',e=>{if(e.level==='error')errors.push(e.message)});
 const url='http://127.0.0.1:5181/?alternative=nanoparticles&workspace=alternatives';
 await win.loadURL(url);
 const read=await win.webContents.executeJavaScript(`(async()=>{for(let i=0;i<200;i++){if(document.querySelector('.alternative-definition'))break;await new Promise(r=>setTimeout(r,50))}const box=document.querySelector('.alternative-definition');if(!box)throw new Error('Definition missing');box.scrollIntoView({block:'center'});await new Promise(r=>setTimeout(r,250));return {url:location.href,title:document.title,definition:box.innerText,buttons:[...box.querySelectorAll('button')].map(b=>({text:b.innerText,disabled:b.disabled})),bodyText:document.body.innerText}})()`);
 fs.writeFileSync('/tmp/agent-d-independent-review/initial-ui-overview.png',(await win.webContents.capturePage()).toPNG());
 await win.loadURL('http://127.0.0.1:5181/?alternative=nanoparticles');
 const render=await win.webContents.executeJavaScript(`(async()=>{for(let i=0;i<300;i++){if(document.querySelector('[data-render-variant="nanoparticles"] canvas'))break;await new Promise(r=>setTimeout(r,50))}const box=document.querySelector('[data-render-variant="nanoparticles"]');if(!box)throw new Error('Render missing');window.scrollTo(0,0);await new Promise(r=>setTimeout(r,500));return {url:location.href,title:document.title,renderText:box.innerText,canvasCount:box.querySelectorAll('canvas').length,play:[...box.querySelectorAll('button')].filter(b=>(b.getAttribute('aria-label')||'').includes('method render')).map(b=>({text:b.getAttribute('aria-label'),disabled:b.disabled})),composition:[...box.querySelectorAll('[data-original-animation]')].map(e=>({...e.dataset}))}})()`);
 fs.writeFileSync('/tmp/agent-d-independent-review/initial-ui-render.png',(await win.webContents.capturePage()).toPNG());
 fs.writeFileSync('/tmp/agent-d-independent-review/initial-ui.json',JSON.stringify({runId:'D-initial-ui-85f49eb-2026-10-12',sourceCommit:'85f49eb7423f94c68b544e4d9450628d0ccade20',executor:'/root/d_realism_reviewer',electron:process.versions.electron,chrome:process.versions.chrome,read,render,consoleErrors:errors},null,2));
 if(!read.buttons.find(b=>b.text.startsWith('Execution disabled'))?.disabled||!render.play.find(b=>b.text==='Play method render')?.disabled)throw new Error('Expected placeholder predictive execution and Play disabled');
 clearTimeout(timeout);console.log('D_INITIAL_UI_INSPECTED');win.destroy();app.exit(0);
}).catch(e=>{console.error(e);app.exit(1)});
