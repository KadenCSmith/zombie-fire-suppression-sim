import { createRun, freshPanel, duplicatePanel, linkedCompatibility } from '/tmp/agent-d-independent-review/initial-85f49eb/src/alternatives/model.ts';
import { VARIANTS, compatible } from '/tmp/agent-d-independent-review/initial-85f49eb/src/alternatives/registry.ts';
import { findMethodModule } from '/tmp/agent-d-independent-review/initial-85f49eb/src/alternatives/modules.ts';
import fs from 'node:fs';
const p=freshPanel('reviewer-d','nanoparticles');
const calls=[];
for(const engine of ['concept','contact','peat-fem']) for (const medium of ['unspecified','none','water','co2-water']) {
 const c={...structuredClone(p),engine,medium}; let error=''; try { createRun(c as any); } catch(e) {error=String(e)};
 calls.push({engine,medium,compatibility:compatible('nanoparticles',engine as any,medium as any),blocked:!!error,error});
}
const duplicate=duplicatePanel(p,'reviewer-d-2');duplicate.thermal.waterKg=3;
const rho=1560,L=25200/.0440095,T=293.15,Ts=195;
const benchmarks=[10,100,500].flatMap(diameterUm=>[.6,.006].map(k=>({diameterUm,kWmK:k,disappearanceS:rho*L*(diameterUm*1e-6/2)**2/(2*k*(T-Ts))})));
const out={runId:'D-initial-85f49eb-independent-2026-10-12',scenario:'registered-placeholder-all-engine-medium-combinations',executor:'independent D realism reviewer /root/d_realism_reviewer',config:p,descriptor:VARIANTS.find(v=>v.id==='nanoparticles'),privateModulePresent:!!findMethodModule('nanoparticles'),calls,configurationCopyIsolated:p.thermal.waterKg!==duplicate.thermal.waterKg,linkedReason:linkedCompatibility([p,duplicate]),criticalPhysicsChecks:'Unavailable for D: no executable particle model or state inventories. Not passed by vacuous rejection.',independentBenchmarksForUnscoredAdvice:benchmarks,fullyPresublimatedReferenceK:Ts+(1*4186*(T-Ts)-.01*L)/(1*4186+.01*850),analyticalDerivation:'Steady spherical Laplace conduction Qdot=4πkrΔT and latent mass balance give d(r²)/dt=-2kΔT/(rhoL). Fixed infinite bath, latent-only denominator; no empirical apparatus claim.'};
fs.writeFileSync('/tmp/agent-d-independent-review/initial-independent-results.json',JSON.stringify(out,null,2));
if(calls.some(c=>!c.blocked))process.exit(1);
console.log(JSON.stringify({all12CombinationsBlocked:true,privateModulePresent:out.privateModulePresent,configurationCopyIsolated:out.configurationCopyIsolated,benchmarks}));
