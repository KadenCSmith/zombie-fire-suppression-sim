import fs from 'node:fs';
import {freshPanel} from './source/src/alternatives/model.ts';
import {simulateParticle} from './source/src/alternatives/fine-dry-ice-injection/physics.ts';
import {particleScenario} from './source/src/alternatives/fine-dry-ice-injection/scenarios.ts';
const L=25200/.0440095,CW=4186,CG=850,TS=195;
function reference(end:number,step=1e-5){const m0=.01,mw=1,r0=50e-6,rho=1560,k=.006,H=mw*CW*(293.15-TS);let u=1,I=0,time=0;
 const f=(v:number)=>{if(v<=0)return [0,0];const g=m0*(1-Math.pow(Math.max(0,v),1.5));const gap=(H-g*L)/(mw*CW+g*CG);return [-2*k*gap/(rho*r0*r0*(L+CG*gap)),Math.pow(Math.max(0,v),1.5)]};
 while(time<end-1e-13){const h=Math.min(step,end-time),a=f(u),b=f(u+h*a[0]/2),c=f(u+h*b[0]/2),d=f(u+h*c[0]);u=Math.max(0,u+h*(a[0]+2*b[0]+2*c[0]+d[0])/6);I+=h*(a[1]+2*b[1]+2*c[1]+d[1])/6;time+=h;}
 const gas=m0*(1-Math.pow(u,1.5));return {timeS:end,u,solidKg:m0*Math.pow(u,1.5),gasKg:gas,temperatureK:TS+(H-gas*L)/(mw*CW+gas*CG),integratedFractionS:I};}

const a=reference(.02,1e-5),b=reference(3,1e-5),aFine=reference(.02,2.5e-6),bFine=reference(3,2.5e-6);
const exact=.001*(b.integratedFractionS-a.integratedFractionS),exactFine=.001*(bFine.integratedFractionS-aFine.integratedFractionS);
const c=particleScenario(freshPanel('D-supplement','nanoparticles'),'film-sensitivity'),time=[],parcels=[];
for(const step of [.02,.01,.005,.0025,.00125,.000625,.0003125]){c.particleInjection!.stepS=step;c.particleInjection!.parcelStepS=.025;const s=simulateParticle(c,30);time.push({stepS:step,entryKg:s.solidEnteringGroundKg,peatK:s.peatTemperatureK});}
for(const parcel of [.025,.0125,.00625]){c.particleInjection!.stepS=.0003125;c.particleInjection!.parcelStepS=parcel;const s=simulateParticle(c,30);parcels.push({parcelStepS:parcel,entryKg:s.solidEnteringGroundKg,errorVsContinuousKg:s.solidEnteringGroundKg-exactFine,relativeErrorVsContinuous:(s.solidEnteringGroundKg-exactFine)/exactFine,peatK:s.peatTemperatureK});}
const timeChanges=time.slice(1).map((r,i)=>({fromStepS:time[i].stepS,toStepS:r.stepS,entryChangeKg:r.entryKg-time[i].entryKg,peatChangeK:r.peatK-time[i].peatK}));
const asymptotic=timeChanges.filter(r=>r.fromStepS<=.005);const asymptoticShrinking=asymptotic.every((r,i)=>i===0||Math.abs(r.entryChangeKg)<Math.abs(asymptotic[i-1].entryChangeKg)&&Math.abs(r.peatChangeK)<Math.abs(asymptotic[i-1].peatChangeK));
const defaultToFinest={entryRelative:Math.abs(time[2].entryKg-time.at(-1)!.entryKg)/Math.abs(time.at(-1)!.entryKg),peatRelative:Math.abs(time[2].peatK-time.at(-1)!.peatK)/Math.abs(time.at(-1)!.peatK)};
const out={runId:'D-retry2-independent-asymptotic-supplement-2026-10-12',executor:'/root/d_realism_reviewer',initialFreeze:'fd8e7a0c3b3596c2ee439d7aec52c2bc71f92440',finalFreeze:'fd8e7a0c3b3596c2ee439d7aec52c2bc71f92440',privatePhysicsIdentical:false,preservedInitialDiagnosticFailure:'Broad check demanding shrinking differences across every coarse time step failed; this result is preserved in independent-results.json. No production code/rubric/tolerance was changed.',independentReferenceEntryKg:exactFine,referenceRK4StepS:2.5e-6,referenceStepDifferenceKg:Math.abs(exact-exactFine),time,timeChanges,parcels,asymptoticShrinkingFromDefault005:asymptoticShrinking,defaultToFinest,timeAllOutputsMonotone:time.every((r,i)=>i===0||r.entryKg>time[i-1].entryKg&&r.peatK<time[i-1].peatK),defaultParcelVsContinuousRelative:Math.abs(parcels[0].relativeErrorVsContinuous),frozen2PercentMet:Math.abs(parcels[0].relativeErrorVsContinuous)<.02&&defaultToFinest.entryRelative<.02&&defaultToFinest.peatRelative<.02&&asymptoticShrinking};
fs.writeFileSync(new URL('./asymptotic-supplement-results.json',import.meta.url),JSON.stringify(out,null,2));console.log(JSON.stringify(out,null,2));
