// independent-checks.mts
import fs from "node:fs";

// source/src/alternatives/contract.ts
var ALTERNATIVE_API_VERSION = "v21.2";
var PARTICLE_API_VERSION = "v21.3";

// source/src/alternatives/sublimation-injection/index.ts
var provenance = "User-supplied Version21 capstone concept; material references and model assumptions in method evidence. No experimental validation.";
var variants = [{
  id: "sublimation-injection",
  method: "4.2.1",
  number: "4.2.1",
  label: "Extinguishing Medium Sublimation and Injection",
  subtitle: "Truck-delivered water + dry ice \u2192 illustrative flow and quenching",
  engines: ["contact", "concept"],
  media: ["water", "co2-water", "unspecified"],
  defaultMedium: "water",
  defaultEngine: "contact",
  stages: ["Fire spread + access", "Drilling + truck delivery", "Water + dry-ice loading", "Illustrative flow + quenching"],
  limitation: "Truck delivery, dry-ice loading, faster water motion and visible quenching are illustrative. Finite contact heat and inventory are modeled separately in three isolated specimens; tank pressure, liquid pre-cooling, accelerated field injection, penetration, suppression, re-ignition and cost savings are unavailable predictions. The CO\u2082 option is direct solid contact, not predicted tank pre-cooling.",
  status: { illustrative: true, modeled: "Finite contact heat / inventory only \xB7 unvalidated", experimentallyValidated: false },
  provenance
}];
var PRESENTATION_TIMING = { surfaceS: 38, preparationS: 59, injectionS: 56, endS: 90 };
var THERMAL_LIMITS = {
  initialK: [300, 1e3],
  waterKg: [0, 5],
  flowKgS: [0, 0.2],
  inletK: [273.15, 350],
  contactStartS: [0, 50],
  conductanceWK: [0, 100],
  dryIceKg: [0, 1],
  endS: [10, 120]
};
function sublimationPresentation(timeS) {
  const time = Number.isFinite(timeS) ? Math.max(0, Math.min(PRESENTATION_TIMING.endS, timeS)) : 0;
  const injection = time >= PRESENTATION_TIMING.injectionS;
  return { contextTime: Math.min(time, 38), access: true, pulse: false, waves: false, injection, vibration: 0, contacts: injection ? 1 : 0 };
}
function validateSublimationConfig(config) {
  if (config.variantId !== "sublimation-injection") throw new Error("4.2.1 adapter requires sublimation-injection identity.");
  if (typeof config.id !== "string" || !config.id.trim()) throw new Error("4.2.1 requires an independent panel identity.");
  const descriptor = variants[0];
  if (!descriptor.engines.includes(config.engine)) throw new Error(`4.2.1 has no supported ${config.engine} adapter.`);
  if (!descriptor.media.includes(config.medium)) throw new Error("Unsupported 4.2.1 medium.");
  if (config.engine === "contact" && config.medium === "unspecified") throw new Error("Unspecified medium has no thermodynamic properties; select conceptual stages.");
  if (config.sourceStatus !== "unspecified" && config.sourceStatus !== "known-contact-properties") throw new Error("Unknown source-property status.");
  if (!config.thermal || typeof config.thermal.enabled !== "boolean" || !Number.isSafeInteger(config.thermal.seed)) throw new Error("4.2.1 requires a boolean intervention flag and integer seed.");
  for (const key of Object.keys(THERMAL_LIMITS)) {
    const value = config.thermal[key], [minimum, maximum] = THERMAL_LIMITS[key];
    if (!Number.isFinite(value) || value < minimum || value > maximum) throw new Error(`Unsupported ${key}; expected ${minimum}\u2013${maximum} in the documented SI unit.`);
  }
  if (config.engine === "contact" && config.thermal.initialK < config.thermal.inletK) throw new Error("The hot-contact proxy requires initial temperature at least the liquid inlet temperature.");
}
var methodModule = {
  apiVersion: ALTERNATIVE_API_VERSION,
  method: "4.2.1",
  variants,
  defaultSettings: () => ({ contactStartS: 8 }),
  createRun(config, hooks) {
    validateSublimationConfig(config);
    return hooks.supportedRun(structuredClone(config));
  },
  presentation: (_id, timeS) => sublimationPresentation(timeS)
};

// source/src/story/fireSequence.ts
var FIRE_SEQUENCE_DURATION = 90;
var FIRE_SEQUENCE_GEOMETRY = { sourceX: 0.4, sourceDepthM: 1.3, sourceInitialMassKg: 4, sourceDensityKgM3: 1560, boreRadiusM: 0.24, boreDepthM: 1.385, capRadiusM: 0.58, capFoldedRadiusM: 0.15, capRiseM: 0.16, capDepthM: 0.98, capInversionM: 0.32, capWedgeRadiusM: 0.69, capGapCenterRad: Math.PI / 4, capGapHalfAngleRad: 0.4, cavityRadiusM: 0.65, cavityCenterY: -0.95, cavityHalfHeightM: 0.28, pitDepthM: 1.3, pitBottomRadiusM: 0.66, pitTopRadiusM: 0.98, hoseRadiusM: 0.055, augerRadiusM: 0.2, domain: { widthM: 8, lengthM: 8, depthM: 3.2 } };
var FIRE_SEQUENCE_STAGES = [
  { id: "surface", start: 0, end: 10, title: "A small surface fire", short: "Ignition", description: "A localized ignition starts the story above organic ground.", evidence: "Flames are a visual cue. The field view shows the numerical temperature state." },
  { id: "underground", start: 10, end: 24, title: "The fire moves underground", short: "Subsurface spread", description: "The story illustrates a buried peat fire. A moving underground front is not resolved by this calculation.", evidence: "Underground spread is prescribed in the natural story. Accepted numerical fields show heating and oxidation without a resolved moving subsurface front." },
  { id: "drilling", start: 24, end: 37, title: "Drill a straight bore", short: "Straight bore", description: "At 70% illustrated peat involvement, the tracked excavator turns a fixed-width auger into the peat.", evidence: "Auger motion and the cylindrical bore are staged. Soil stability, root contact and excavation forces are not solved." },
  { id: "source", start: 37, end: 47, title: "Lower the dry-ice sphere", short: "Dry ice", description: "The dry-ice sphere settles at the bottom of the straight bore.", evidence: "Placement is authored. Natural-view source mass follows a separate finite contact-model inventory." },
  { id: "dome", start: 47, end: 55, title: "Lower the fixed-size metal cap", short: "Metal cap", description: "A small metal cap drops into the original bore. Its width and profile stay fixed.", evidence: "The cap is staged geometry. Fit, sealing and structural loading have not been validated." },
  { id: "treatment", start: 55, end: 69, title: "Rapid gas release and peat fractures", short: "Gas release", description: "In rapid mode, the sphere vanishes into a depicted CO\u2082 release. A brief soil jolt sends fine fractures across the peat and dims nearby embers. The metal cap and bore keep their original size.", evidence: "Gas conversion, oxygen displacement, fracture growth and visual quenching are authored. The contact ledger exports residual dry ice; pressure and field suppression are not calculated." },
  { id: "water", start: 69, end: 85, title: "Water follows the fractures", short: "Water stage", description: "A woven hose enters through the cap gap. Water follows the illustrated fracture network, darkening peat and extinguishing the remaining depicted embers.", evidence: "Wetting routes and visual ember extinction are authored. Local contact cooling has a separate finite budget; infiltration and field suppression are not predicted." },
  { id: "review", start: 85, end: 90, title: "Inspect the illustrated outcome", short: "Review", description: "Compare the darkened peat and remaining accepted numerical field evidence.", evidence: "Visual extinguishment is staged. It is not a validated treatment procedure or a prediction of extinguishment." }
];
var phase = (time, start, end) => Math.max(0, Math.min(1, (time - start) / (end - start)));
var eased = (time, start, end) => {
  const p = phase(time, start, end);
  return p * p * (3 - 2 * p);
};
var STORY_CRACK_PATHS = [
  [[0.4, -1.28, 0.035], [0.9, -1.4, 0.045], [1.25, -1.1, 0.04], [1.85, -1.32, 0.045], [2.48, -0.82, 0.04], [3.1, -0.68, 0.04]],
  [[0.4, -1.28, 0.04], [0.1, -1.64, 0.04], [-0.5, -1.78, 0.04], [-1.02, -2.1, 0.04], [-1.9, -2, 0.04], [-2.75, -2.5, 0.04]],
  [[0.4, -1.28, 0.04], [0.78, -1.9, 0.04], [1.4, -2.08, 0.04], [1.7, -2.55, 0.04], [2.6, -2.8, 0.04]],
  [[0.4, -1.28, 0.04], [-0.15, -0.84, 0.04], [-0.82, -0.63, 0.04], [-1.15, -0.24, 0.04], [-1.65, -0.04, 0.04]],
  [[0.4, -1.28, 0.04], [1.25, -1.1, 0.04], [1.42, -0.55, 0.04], [1.15, -0.18, 0.04]],
  [[0.4, -1.28, 0.04], [0.1, -1.64, 0.04], [-0.1, -2.16, 0.04], [-0.66, -2.62, 0.04]]
];
var STORY_HOSE_POINTS = [[-4.4, 0.15, -0.8], [-3.5, 0.16, -0.4], [-2.7, 0.16, -0.72], [-1.9, 0.16, -0.32], [-1.1, 0.16, -0.5], [-0.2, 0.19, -0.12], [0.34, 0.32, 0.1], [0.51, 0.15, 0.11], [0.49, -0.3, 0.09], [0.52, -0.85, 0.12], [0.515, -1.265, 0.115]];
var STORY_WATER_START = 72;
function storyWettingProgress(time, branch) {
  return 0.66 * Math.sqrt(Math.max(0, Math.min(1, (time - STORY_WATER_START - branch * 0.65) / 18)));
}
function pointAlongStoryPath(points, fraction) {
  const lengths = points.slice(1).map((p, i) => Math.hypot(...p.map((v, j) => v - points[i][j]))), total = lengths.reduce((a, b) => a + b, 0);
  let distance = Math.max(0, Math.min(1, fraction)) * total;
  for (let i = 0; i < lengths.length; i++) {
    if (distance <= lengths[i] || i === lengths.length - 1) {
      const f = distance / lengths[i];
      return points[i].map((v, j) => v + (points[i + 1][j] - v) * f);
    }
    distance -= lengths[i];
  }
  return points[0];
}

// source/src/story/firePresentation.ts
var PRESENTATION_TIMING2 = {
  spreadStart: 12,
  spreadEnd: 40,
  excavatorEnter: 18,
  excavatorPark: 24,
  drillStart: 24,
  drillFullDepth: 31,
  drillRetract: 34,
  drillClear: 36.5,
  excavatorExit: 40,
  sourceContact: 44,
  capSeated: 51.5,
  gasRelease: 55,
  truckEnter: 57,
  truckPark: 65,
  hoseDeploy: 65,
  hoseAtBore: 69,
  hoseConnected: 72,
  waterStart: 72,
  review: 85
};
var PRESENTATION_SPEED = { early: 3.2, equipment: 1.2, placement: 2, release: 1, finish: 2 };
function presentationRate(time) {
  const s = PRESENTATION_SPEED, t = PRESENTATION_TIMING2;
  let rate = s.early + (s.equipment - s.early) * eased(time, t.excavatorEnter, t.excavatorPark);
  rate += (s.placement - s.equipment) * eased(time, t.drillClear, t.excavatorExit);
  rate += (s.release - s.placement) * eased(time, 53, t.gasRelease);
  rate += (s.finish - s.release) * eased(time, 56.5, 58.5);
  return rate;
}
var CLOCK_STEP = 0.02;
var clock = new Float64Array(Math.round(FIRE_SEQUENCE_DURATION / CLOCK_STEP) + 1);
for (let i = 1; i < clock.length; i++) {
  const a = (i - 1) * CLOCK_STEP, b = i * CLOCK_STEP;
  clock[i] = clock[i - 1] + CLOCK_STEP / 6 * (1 / presentationRate(a) + 4 / presentationRate((a + b) / 2) + 1 / presentationRate(b));
}
var PRESENTATION_PLAYBACK_DURATION = clock[clock.length - 1];
var WATER_TRUCK = {
  parked: [2.35, 0, -1.15],
  outletLocal: [-1.27, 0.63, 0.61],
  wheelRadiusM: 0.29
};
var parkedOutlet = WATER_TRUCK.parked.map((v, i) => v + WATER_TRUCK.outletLocal[i]);
var CONNECTED_HOSE_ROUTE = [
  parkedOutlet,
  [0.96, 0.22, -0.52],
  [0.8, 0.13, -0.46],
  [0.63, 0.13, -0.36],
  [0.52, 0.14, -0.26],
  [0.42, 0.22, -0.13],
  ...STORY_HOSE_POINTS.slice(6)
];
var CURRENT_FIRE_STAGES = FIRE_SEQUENCE_STAGES.map((stage) => stage.id === "drilling" ? { ...stage, description: "The parked excavator turns its auger into the bore while the continuous illustrated peat front keeps advancing. Soil-colored cuttings mark drilling; no water is applied." } : stage.id === "treatment" ? { ...stage, description: "After the cap lands, rapid mode depicts a brief gas release. A water truck enters and parks, then its reel extends a connected hose toward the access point. Gradual mode retains finite contact cooling." } : stage.id === "water" ? { ...stage, description: "The supply end stays attached to the truck. The hose clears the retracted drill, enters the cap service opening, then supplies the established progressive wetting sequence after connection at 72 s." } : stage);

// source/src/alternatives/pressure-pulse-liquid-waves/animation.ts
var clamp = (n) => Math.max(0, Math.min(1, n));
var smooth = (time, start, end) => {
  const u = clamp((time - start) / (end - start));
  return u * u * (3 - 2 * u);
};
var HYDRAULIC_PULSES = [[76, 78], [82, 84], [87, 89]];
var LIQUID_SEQUENCE = { injectionStart: PRESENTATION_TIMING2.waterStart, end: 90 };
var DRILL_SECTION_STARTS = [68, 68 + 4 / 3, 68 + 8 / 3];
function liquidAnimationFrame(presentationS) {
  const time = Number.isFinite(presentationS) ? Math.max(0, Math.min(90, presentationS)) : 0;
  const injection = time >= PRESENTATION_TIMING2.waterStart;
  const pulseIndex = HYDRAULIC_PULSES.findIndex(([start, end]) => time >= start && time < end);
  const waves = pulseIndex >= 0;
  const age = waves ? time - HYDRAULIC_PULSES[pulseIndex][0] : 0;
  const progress = age / 2;
  const strength = waves ? clamp((1 - Math.exp(-age * 30)) * Math.exp(-age * 4) * 1.8) : 0;
  const tremor = waves ? Math.sin(age * 34) * Math.exp(-age * 4) * 0.035 : 0;
  const opening = HYDRAULIC_PULSES.reduce((sum, [start]) => sum + smooth(time, start, start + 0.55), 0) / HYDRAULIC_PULSES.length;
  const accelerated = HYDRAULIC_PULSES.reduce((sum, [start, end]) => sum + Math.max(0, Math.min(time, end) - start), 0);
  const flowClock = Math.max(0, time - PRESENTATION_TIMING2.waterStart) * 0.55 + accelerated * 0.65;
  const arrival = clamp(time - PRESENTATION_TIMING2.waterStart);
  return {
    time,
    waves,
    injection,
    pulseIndex,
    progress,
    strength,
    tremor,
    opening,
    stage: time < 44 ? "Original fire and drilled access" : time < 57 ? "Original dry-ice pressure release" : time < 65 ? "Pump truck reverses into position" : time < 68 ? "Drilling mast rises" : time < 72 ? "Rigid drill pipe advances into the bore" : waves ? "Illustrative ground pulse" : "Normal water pumping",
    contact: injection ? arrival : 0,
    flowClock,
    extinguishing: clamp((time - PRESENTATION_TIMING2.waterStart) / 17)
  };
}

// source/src/alternatives/pressure-pulse-liquid-waves/model.ts
function createLiquidWavesRun(config, hooks) {
  if (config.variantId !== "liquid-waves") throw new Error("4.2.3.1 adapter requires liquid-waves identity.");
  if (config.engine !== "contact" && config.engine !== "concept") throw new Error("4.2.3.1 has no coupled treatment engine.");
  if (config.medium !== "water" && config.medium !== "unspecified") throw new Error("4.2.3.1 supports ordinary water or an unspecified concept source only.");
  if (config.engine === "contact" && config.medium !== "water") throw new Error("Unspecified source has no thermodynamic properties.");
  const owned = structuredClone(config);
  owned.thermal.dryIceKg = 0;
  return hooks.supportedRun(owned);
}
function liquidWavesPresentation(id, timeS) {
  if (id !== "liquid-waves") throw new Error("4.2.3.1 presentation requires liquid-waves identity.");
  const time = Number.isFinite(timeS) ? Math.max(0, Math.min(90, timeS)) : 0;
  const frame = liquidAnimationFrame(time);
  return {
    contextTime: time,
    access: true,
    pulse: time >= 55 && time < 56.5,
    waves: frame.waves,
    injection: frame.injection,
    vibration: 0,
    contacts: frame.injection ? 1 : 0
  };
}

// source/src/alternatives/pressure-pulse-liquid-waves/index.ts
var variants2 = [{
  id: "liquid-waves",
  method: "4.2.3",
  number: "4.2.3.1",
  label: "Liquid-pressure waves then injection",
  subtitle: "Original 4.2.3 sequence \xB7 opposing trucks, rigid pipe and intermittent ground pulses",
  draft: true,
  engines: ["contact", "concept"],
  media: ["water", "unspecified"],
  defaultMedium: "water",
  defaultEngine: "contact",
  stages: ["Original fire and access sequence", "Original dry-ice release and truck deployment", "Normal pumping with hydraulic pulses"],
  limitation: "Pressure-wave propagation, infiltration and structural response are unavailable. The user-requested fracture and extinguishing sequence is an authored illustration, not a predicted outcome. Only the separate finite ordinary-water contact calorimeter is modeled; added visual pulses contribute no modeled source, cooling or permeability benefit. The editable 12 s contact arrival is a scenario assumption, separate from the presentation clock.",
  status: { illustrative: true, modeled: "Finite liquid-water contact calorimeter only", experimentallyValidated: false },
  provenance: "User capstone subsection; unchanged external contact reference with constant-property approximations. See method evidence for assumptions and official water-property references."
}];
var methodModule2 = {
  apiVersion: ALTERNATIVE_API_VERSION,
  method: "4.2.3",
  variants: variants2,
  defaultSettings: () => ({ contactStartS: 12 }),
  createRun: createLiquidWavesRun,
  presentation: liquidWavesPresentation
};

// source/src/alternatives/pressure-pulse-pressure-only/model.ts
function createPressureOnlyRun(config, hooks) {
  if (config.variantId !== "pressure-only") throw new Error("4.2.3.2 adapter requires pressure-only identity.");
  if (config.engine !== "concept") throw new Error("4.2.3.2 has no supported physical adapter; outcomes are N/A.");
  if (config.medium !== "none" && config.medium !== "unspecified") throw new Error("4.2.3.2 never injects liquid or solid treatment medium.");
  const owned = structuredClone(config);
  Object.assign(owned.thermal, { enabled: false, waterKg: 0, flowKgS: 0, dryIceKg: 0, conductanceWK: 0 });
  return hooks.supportedRun(owned);
}
function pressureOnlyPresentation(id, timeS) {
  if (id !== "pressure-only") throw new Error("4.2.3.2 presentation requires pressure-only identity.");
  const time = Number.isFinite(timeS) ? Math.max(0, Math.min(90, timeS)) : 0;
  return {
    contextTime: Math.min(time, 57),
    access: true,
    pulse: time >= 55 && time < 58,
    waves: false,
    injection: false,
    vibration: 0,
    contacts: 0
  };
}

// source/src/alternatives/pressure-pulse-pressure-only/index.ts
var variants3 = [{
  id: "pressure-only",
  method: "4.2.3",
  number: "4.2.3.2",
  label: "Rapid pressure change without liquid",
  subtitle: "Descriptive draft label \xB7 no liquid injection",
  draft: true,
  engines: ["concept"],
  media: ["none", "unspecified"],
  defaultMedium: "none",
  defaultEngine: "concept",
  stages: ["Original drilled access and dry-ice reference sequence", "Illustrative ground jolt", "Soil fragments settle \xB7 no liquid injected"],
  limitation: "Earth motion is an authored soil-response hypothesis, not computed pressure, fracture or collapse. No liquid or thermal source is instantiated; physical metrics and suppression remain N/A.",
  status: { illustrative: true, modeled: "Unavailable \u2014 pressure/soil response not coupled", experimentallyValidated: false },
  provenance: "User capstone subsection; generic environmental input with unspecified source properties. No device, pressure law or measured outcome is inferred."
}];
var methodModule3 = {
  apiVersion: ALTERNATIVE_API_VERSION,
  method: "4.2.3",
  variants: variants3,
  defaultSettings: () => ({ contactStartS: 8 }),
  createRun: createPressureOnlyRun,
  presentation: pressureOnlyPresentation
};

// source/src/alternatives/vibratory-injection/vibration.ts
var VIBRATION_TIMELINE = { start: 27, rampEnd: 33, holdContext: 33, taperStart: 68, stop: 74, end: 90 };
function vibrationPose(time, enabled = true) {
  const t = Number.isFinite(time) ? Math.max(0, Math.min(VIBRATION_TIMELINE.end, time)) : 0;
  const amount = enabled ? eased(t, VIBRATION_TIMELINE.start, VIBRATION_TIMELINE.rampEnd) * (1 - eased(t, VIBRATION_TIMELINE.taperStart, VIBRATION_TIMELINE.stop)) : 0;
  const x = amount * (0.026 * Math.sin(t * 26) + 9e-3 * Math.sin(t * 39));
  const y = amount * 0.014 * Math.sin(t * 31);
  const fracture = enabled ? eased(t, 33, 46) : 0;
  const compression = enabled ? eased(t, 44, 68) : 0;
  const emberFade = enabled ? eased(t, 50, 74) : 0;
  const shrink = compression * 0.028;
  return {
    time: t,
    contextTime: Math.min(t, VIBRATION_TIMELINE.holdContext),
    amount,
    fracture,
    compression,
    emberFade,
    groundScale: [1, 1 - shrink, 1],
    surfacePosition: [x, y - 3.2 * shrink, 0],
    groundPosition: [x, y, 0],
    groundTilt: amount * 25e-4 * Math.sin(t * 23),
    toolPosition: [amount * 0.024 * Math.sin(t * 35), amount * 0.022 * Math.sin(t * 29), 0]
  };
}

// source/src/alternatives/vibratory-injection/model.ts
var PREDICTION_UNAVAILABLE = "Vibration-only prediction is unavailable: forcing, mechanical work, cyclic peat constitutive response and independent validation are missing.";
var defaultSettings = { enabled: false, waterKg: 0, flowKgS: 0, dryIceKg: 0, conductanceWK: 0, contactStartS: 0 };
function createVibratoryRun(config) {
  if (config.variantId !== "vibratory-injection") throw new Error("Vibratory adapter requires its own variant identity.");
  throw new Error(PREDICTION_UNAVAILABLE);
}
function vibratoryPresentation(id, timeS) {
  if (id !== "vibratory-injection") throw new Error("Vibratory presentation requires its own variant identity.");
  const pose = vibrationPose(timeS);
  return { contextTime: pose.contextTime, access: pose.time >= 24, pulse: false, waves: false, injection: false, vibration: pose.groundPosition[0], contacts: 0 };
}

// source/src/alternatives/vibratory-injection/index.ts
var status = (modeled) => ({ illustrative: true, modeled, experimentallyValidated: false });
var provenance2 = "User-supplied Version21 work pack; capstone concepts, not measured performance";
var variants4 = [
  { id: "vibratory-injection", method: "4.2.4", number: "4.2.4", label: "Earthquake Extinguisher", subtitle: "Vibratory drilling \xB7 vibration only", engines: [], media: ["none"], defaultMedium: "none", defaultEngine: "concept", stages: ["Original fire and drilling", "Illustrative vibration", "Illustrated soil rearrangement and fire-out"], limitation: PREDICTION_UNAVAILABLE, status: status("Unavailable \u2014 vibration mechanics unsupported"), provenance: provenance2 }
];
var methodModule4 = {
  apiVersion: ALTERNATIVE_API_VERSION,
  method: "4.2.4",
  variants: variants4,
  defaultSettings: () => ({ ...defaultSettings }),
  createRun: createVibratoryRun,
  presentation: vibratoryPresentation
};

// source/src/alternatives/fine-dry-ice-injection/physics.ts
var PROPERTIES = Object.freeze({ surfaceK: 195, latentJkg: 25200 / 0.0440095, waterCpJkgK: 4186, gasCpJkgK: 850 });
var { surfaceK: TS, latentJkg: L, waterCpJkgK: CW, gasCpJkgK: CG } = PROPERTIES;
var UNAVAILABLE = ["Aqueous film/ice-shell and blockage coupling", "Particle slip, filtration, deposition and peat penetration", "Pressure-driven liquid flow and spatial wetting", "Gas/O2 mixture and boundary exchange fields", "Tank pressure", "Reacting fire, extinction and re-ignition", "Ambient reheating and drainage"];
var empty = () => ({ water: 0, gas: 0, h: 0, cohorts: [] });
function solid(c, p) {
  return c.cohorts.reduce((a, b) => a + b.count * 4 * Math.PI / 3 * p.solidDensityKgM3 * b.radiusM ** 3, 0);
}
function temperature(c) {
  const capacity = c.water * CW + c.gas * CG;
  return capacity > 0 ? TS + (c.h - c.gas * L) / capacity : null;
}
function checkLiquid(t, location, time) {
  if (t !== null && (t < 273.15 - 1e-8 || t > 350 + 1e-8)) throw new Error(`Out of liquid-carrier regime at ${location}, t=${time.toFixed(6)} s: ${t.toFixed(3)} K. Bulk freezing/overheating invalidates this model; local ice shells and blockage are unverified even above freezing.`);
}
function sphereRadiusSquared(r0, k, bathK, rho, latent, timeS) {
  return Math.max(0, r0 * r0 - 2 * k * Math.max(0, bathK - TS) * timeS / (rho * latent));
}
function twoCapacityHeatJ(hotK, coldK, a, b, ua, dt) {
  if (a <= 0 || b <= 0 || ua === 0 || dt === 0) return 0;
  const reciprocal = 1 / a + 1 / b;
  return (hotK - coldK) * -Math.expm1(-ua * dt * reciprocal) / reciprocal;
}
function validateParticleConfig(config) {
  if (config.variantId !== "nanoparticles" || config.engine !== "particle" || !["water", "co2-water"].includes(config.medium)) throw new Error("4.2.2 requires its particle engine and water or CO2-water medium.");
  if (!config.id?.trim() || typeof config.thermal.enabled !== "boolean" || !Number.isSafeInteger(config.thermal.seed)) throw new Error("Independent panel ID, intervention flag and integer seed are required.");
  const p = config.particleInjection;
  if (!p) throw new Error("Explicit particle configuration including size, SI units and provenance is required.");
  const limits = { particleDiameterM: [1e-5, 5e-4], effectiveConductivityWmK: [6e-4, 0.6], solidDensityKgM3: [800, 1650], hoseResidenceS: [0, 20], probeResidenceS: [0, 10], dryPeatMassKg: [0.01, 10], initialMoistureDryBasis: [0, 1], dryPeatCpJkgK: [500, 3e3], stepS: [3125e-7, 0.02], parcelStepS: [625e-5, 0.5] };
  for (const key of Object.keys(limits)) {
    const [lo, hi] = limits[key];
    if (!Number.isFinite(p[key]) || p[key] < lo || p[key] > hi) throw new Error(`Unsupported ${key}; expected ${lo}\u2013${hi} in SI units.`);
  }
  for (const key of ["sizeProvenance", "heatTransferProvenance", "residenceProvenance", "soilProvenance"]) if (typeof p[key] !== "string" || !p[key].trim()) throw new Error(`Explicit ${key} required; assumptions are not measurements.`);
  if (!["solid", "pre-sublimated"].includes(p.initialPhase)) throw new Error("Unknown initial CO2 phase.");
  const limitsT = { initialK: [300, 350], inletK: [273.15, 350], waterKg: [0, 5], dryIceKg: [0, 1], flowKgS: [0, 0.2], contactStartS: [0, 50], conductanceWK: [0, 100], endS: [10, 120] };
  for (const key of Object.keys(limitsT)) {
    const [lo, hi] = limitsT[key], v = config.thermal[key];
    if (!Number.isFinite(v) || v < lo || v > hi) throw new Error(`Unsupported ${key}: this nonreacting warm-specimen/liquid diagnostic requires ${lo}\u2013${hi}. Fire/boiling coupling is unavailable.`);
  }
  if (config.thermal.waterKg === 0 && config.medium === "co2-water" && config.thermal.dryIceKg > 0) throw new Error("Solid/gas without liquid carrier is outside the particle-in-water model.");
  return structuredClone(p);
}
function simulateParticle(configInput, targetS) {
  const config = structuredClone(configInput), p = validateParticleConfig(config), t = config.thermal;
  if (!Number.isFinite(targetS) || targetS < 0 || targetS > t.endS + 1e-9) throw new Error("Invalid particle observation target.");
  const initialCO2 = config.medium === "co2-water" ? t.dryIceKg : 0;
  const source = empty(), soil = empty(), parcels = [], releases = [];
  source.water = t.waterKg;
  source.h = source.water * CW * (t.inletK - TS);
  if (initialCO2 > 0) source.cohorts = [{ count: initialCO2 / (4 * Math.PI / 3 * p.solidDensityKgM3 * (p.particleDiameterM / 2) ** 3), radiusM: p.particleDiameterM / 2 }];
  let upstream = 0, underground = 0, solidEntry = 0, co2Entry = 0, waterEntry = 0, heatPeat = 0, peatK = t.initialK;
  const peatCapacity = p.dryPeatMassKg * (p.dryPeatCpJkgK + p.initialMoistureDryBasis * CW);
  const initialH = source.h + peatCapacity * (peatK - TS);
  function record(location, fromS, toS, massKg) {
    if (massKg <= 0) return;
    const bin = Math.floor((fromS + toS) / 2 / 0.25);
    let item = releases.find((r) => r.location === location && Math.floor((r.fromS + r.toS) / 2 / 0.25) === bin);
    if (!item) {
      item = { location, fromS, toS, massKg: 0, latentJ: 0 };
      releases.push(item);
    }
    item.fromS = Math.min(item.fromS, fromS);
    item.toS = Math.max(item.toS, toS);
    item.massKg += massKg;
    item.latentJ += massKg * L;
  }
  if (t.enabled && p.initialPhase === "pre-sublimated" && initialCO2 > 0) {
    source.gas = initialCO2;
    source.cohorts = [];
    upstream = initialCO2;
    checkLiquid(temperature(source), "pre-sublimated source", 0);
    record("source", 0, 0, initialCO2);
  }
  function phase2(c, location, fromS, toS) {
    const bath = temperature(c), oldMass = solid(c, p);
    if (bath === null || oldMass === 0 || toS <= fromS) return;
    const gap = L + CG * (bath - TS);
    const next = c.cohorts.map((b) => ({ ...b, radiusM: Math.sqrt(sphereRadiusSquared(b.radiusM, p.effectiveConductivityWmK, bath, p.solidDensityKgM3, gap, toS - fromS)) }));
    const trial = { ...c, cohorts: next }, dm = Math.max(0, oldMass - solid(trial, p));
    trial.gas += dm;
    checkLiquid(temperature(trial), location, toS);
    c.cohorts = next.filter((b) => b.radiusM > 0);
    c.gas = trial.gas;
    if (location === "soil") underground += dm;
    else upstream += dm;
    record(location, fromS, toS, dm);
  }
  function merge(into, from) {
    into.water += from.water;
    into.gas += from.gas;
    into.h += from.h;
    into.cohorts.push(...from.cohorts);
    checkLiquid(temperature(into), "mixed soil carrier", clock2);
  }
  const duration = t.flowKgS > 0 ? t.waterKg / t.flowKgS : Infinity;
  let dispatchIndex = 1, clock2 = 0, withdrawalResolutionChecked = false;
  function dispatchTime() {
    return t.contactStartS + Math.min(dispatchIndex * p.parcelStepS, duration);
  }
  function dispatch() {
    const water = Math.min(source.water, t.flowKgS * p.parcelStepS);
    if (water <= 1e-14 || source.water <= 0) return;
    const f = water / source.water, out = { water, gas: source.gas * f, h: source.h * f, cohorts: source.cohorts.map((b) => ({ count: b.count * f, radiusM: b.radiusM })) };
    source.water -= water;
    source.gas *= 1 - f;
    source.h *= 1 - f;
    source.cohorts.forEach((b) => b.count *= 1 - f);
    if (source.water < 1e-13) {
      source.water = 0;
      source.gas = 0;
      source.h = 0;
      source.cohorts = [];
    }
    parcels.push({ carrier: out, dispatchedS: clock2, hoseEndS: clock2 + p.hoseResidenceS, groundS: clock2 + p.hoseResidenceS + p.probeResidenceS });
    dispatchIndex++;
  }
  while (t.enabled && clock2 < targetS - 1e-11) {
    if (!withdrawalResolutionChecked && clock2 >= t.contactStartS - 1e-10) {
      withdrawalResolutionChecked = true;
      const bath = temperature(source);
      if (t.flowKgS > 0 && source.water > 1e-14 && bath !== null && solid(source, p) > 0) {
        const gap = L + CG * (bath - TS);
        const life = Math.min(...source.cohorts.filter((b) => b.count > 0 && b.radiusM > 0).map((b) => p.solidDensityKgM3 * b.radiusM ** 2 * gap / (2 * p.effectiveConductivityWmK * (bath - TS))));
        if (Math.max(p.stepS, p.parcelStepS) > life / 64) throw new Error(`Underresolved solid delivery at withdrawal onset (${clock2.toFixed(6)} s): remaining radius-squared lifetime ${life.toExponential(4)} s requires phase and parcel intervals <= ${(life / 64).toExponential(4)} s for this resolution screen. Solid entry is unavailable; zero delivery cannot be inferred. Even screened inputs require scenario-specific refinement.`);
      }
    }
    let next = Math.min(targetS, (Math.floor((clock2 + 1e-10) / p.stepS) + 1) * p.stepS);
    if (t.contactStartS > clock2 + 1e-10) next = Math.min(next, t.contactStartS);
    if (source.water > 1e-14 && t.flowKgS > 0 && dispatchTime() > clock2 + 1e-10) next = Math.min(next, dispatchTime());
    for (const parcel of parcels) for (const boundary of [parcel.hoseEndS, parcel.groundS]) if (boundary > clock2 + 1e-10) next = Math.min(next, boundary);
    const dt = next - clock2;
    phase2(source, "source", clock2, next);
    for (const parcel of parcels) phase2(parcel.carrier, clock2 < parcel.hoseEndS - 1e-9 ? "hose" : "probe", clock2, next);
    const carrierK = temperature(soil);
    if (carrierK !== null) {
      const q = twoCapacityHeatJ(peatK, carrierK, peatCapacity, soil.water * CW + soil.gas * CG, t.conductanceWK, dt);
      const trial = { ...soil, h: soil.h + q };
      checkLiquid(temperature(trial), "soil contact", next);
      soil.h += q;
      peatK -= q / peatCapacity;
      heatPeat += q;
      phase2(soil, "soil", clock2, next);
    }
    clock2 = next;
    if (source.water > 1e-14 && t.flowKgS > 0 && clock2 >= dispatchTime() - 1e-9) dispatch();
    for (let i = parcels.length - 1; i >= 0; i--) if (clock2 >= parcels[i].groundS - 1e-9) {
      const c = parcels[i].carrier;
      solidEntry += solid(c, p);
      co2Entry += solid(c, p) + c.gas;
      waterEntry += c.water;
      merge(soil, c);
      parcels.splice(i, 1);
    }
  }
  function inventory(c) {
    return { waterKg: c.water, solidKg: solid(c, p), gasKg: c.gas, enthalpyJ: c.h, temperatureK: temperature(c) };
  }
  const hose = empty(), probe = empty();
  for (const parcel of parcels) {
    const c = clock2 < parcel.hoseEndS - 1e-9 ? hose : probe;
    c.water += parcel.carrier.water;
    c.gas += parcel.carrier.gas;
    c.h += parcel.carrier.h;
    c.cohorts.push(...parcel.carrier.cohorts);
  }
  const carriers = { source, hose, probe, soil }, locations = Object.fromEntries(Object.entries(carriers).map(([k, c]) => [k, inventory(c)]));
  const all = Object.values(locations);
  const mean = Object.fromEntries(Object.entries(carriers).map(([key, c]) => {
    const m = solid(c, p);
    return [key, m > 0 ? c.cohorts.reduce((a, b) => a + b.count * 4 * Math.PI / 3 * p.solidDensityKgM3 * b.radiusM ** 3 * 2 * b.radiusM, 0) / m : null];
  }));
  return {
    schema: "particle-delivery-d1",
    timeS: targetS,
    modelTier: "Unvalidated finite-inventory saturated-film thermal/entrainment sensitivity; nominated underground calorimeter only",
    locations,
    releases,
    solidEnteringGroundKg: solidEntry,
    co2EnteringGroundKg: co2Entry,
    waterEnteringGroundKg: waterEntry,
    upstreamSublimatedKg: upstream,
    undergroundSublimatedKg: underground,
    initialCO2Kg: initialCO2,
    upstreamFractionInitialCO2: initialCO2 > 0 ? upstream / initialCO2 : null,
    undergroundFractionInitialCO2: initialCO2 > 0 ? underground / initialCO2 : null,
    probeSurvivalFractionArrivedCO2: co2Entry > 0 ? solidEntry / co2Entry : null,
    peatTemperatureK: peatK,
    retainedMoistureDryBasis: p.initialMoistureDryBasis + soil.water / p.dryPeatMassKg,
    heatFromPeatJ: heatPeat,
    waterMassResidualKg: all.reduce((a, c) => a + c.waterKg, 0) - t.waterKg,
    co2MassResidualKg: all.reduce((a, c) => a + c.solidKg + c.gasKg, 0) - initialCO2,
    energyResidualJ: all.reduce((a, c) => a + c.enthalpyJ, 0) + peatCapacity * (peatK - TS) - initialH,
    initialEnthalpyJ: initialH,
    additionalColdResourceJ: initialCO2 * (L + CG * (t.inletK - TS)),
    meanSolidDiameterM: mean,
    pressurePa: null,
    oxygenMoleFraction: null,
    extinction: null,
    penetrationM: null,
    unavailable: [...UNAVAILABLE],
    assumptions: [p.sizeProvenance, p.heatTransferProvenance, p.residenceProvenance, p.soilProvenance, "Solid is initially saturated/isothermal at195K; cp-water4186 and cp-gas850J/(kgK) are constant approximations, not full property correlations.", "Adiabatic source/transport; water and CO2 gas enthalpy travel together, no vent/slip. Prescribed delivery into a nominated contact specimen; no predicted penetration.", "Local ice shells/blockage remain unresolved even when bulk water is273.15\u2013350K.", "Parcel withdrawal uses right-endpoint quadrature; phase uses finite-bath explicit r-squared updates and conservative enthalpy, finite-UA pair exchange.", "Active solid withdrawal requires phase and parcel intervals no larger than 1/64 of the actual aged-source radius-squared lifetime at withdrawal onset. This fail-closed screen is not an accuracy certificate; refinement evidence applies only to tested scenarios."],
    review: "No verified realism pass; initial placeholder1.3/10. Signed candidate scores and frozen identity are in the D REALISM_LEDGER. Experimental validation:false.",
    metadata: { panelId: config.id, seed: t.seed, observationS: t.endS, particleSizeProvenance: p.sizeProvenance, units: "SI; kelvin; mass fractions use stated denominators", numericalStepS: p.stepS, parcelStepS: p.parcelStepS }
  };
}
function createParticleRun(configInput) {
  const config = structuredClone(configInput);
  validateParticleConfig(config);
  let state = simulateParticle(config, 0);
  function snapshot() {
    return { timeS: state.timeS, particleInjection: structuredClone(state), metrics: { maximumK: state.peatTemperatureK, waterUsedKg: state.waterEnteringGroundKg, dryIceUsedKg: state.upstreamSublimatedKg + state.undergroundSublimatedKg, energyJ: state.heatFromPeatJ, energyResidualJ: state.energyResidualJ, massResidualKg: Math.max(Math.abs(state.waterMassResidualKg), Math.abs(state.co2MassResidualKg)), oxygenKg: null, fuelKg: null, reactionW: null } };
  }
  return { endS: config.thermal.endS, snapshot, advanceTo(targetS) {
    if (!Number.isFinite(targetS) || targetS < state.timeS - 1e-9 || targetS > config.thermal.endS + 1e-9) throw new Error("Invalid physical target.");
    const next = simulateParticle(config, targetS);
    state = next;
    return snapshot();
  } };
}

// source/src/alternatives/fine-dry-ice-injection/index.ts
var variants5 = [{
  id: "nanoparticles",
  method: "4.2.2",
  number: "4.2.2",
  label: "Solid Inert Gas Nano Particles",
  subtitle: "Water + fine dry-ice particle injection",
  engines: ["particle"],
  media: ["water", "co2-water"],
  defaultEngine: "particle",
  defaultMedium: "co2-water",
  stages: ["Continuous source sublimation", "Hose + probe survival test", "Conditional underground sublimation", "Observe the thermal specimen"],
  limitation: "Unvalidated finite-inventory thermal/entrainment sensitivity. Fine particles may disappear before the probe. Residence and film resistance are assumptions; local freezing, blockage, filtration, peat penetration, gas/O2 fields, pressure, reacting-fire suppression and re-ignition are unavailable. Warm nonreacting specimen273.15\u2013350K only; no experimental validation.",
  status: { illustrative: true, modeled: "Shrinking particles + finite water/gas enthalpy + prescribed residence + nominated peat calorimeter; conditional/unvalidated", experimentallyValidated: false },
  provenance: "Human capstone description supplies mechanism only. Explicit analytical study sizes and all unmeasured transport/soil assumptions are exposed; no Nano size inference."
}];
var methodModule5 = {
  apiVersion: PARTICLE_API_VERSION,
  method: "4.2.2",
  variants: variants5,
  defaultSettings: () => ({ enabled: true, waterKg: 1, flowKgS: 0.1, dryIceKg: 0.01, initialK: 333.15, inletK: 293.15, contactStartS: 1, conductanceWK: 2, endS: 30 }),
  createRun: (config) => createParticleRun(config),
  presentation: (_id, time) => ({ contextTime: Math.min(Math.max(0, time), 38), access: true, pulse: false, waves: false, injection: false, vibration: 0, contacts: 0 })
};

// source/src/alternatives/modules.ts
var METHOD_MODULES = [methodModule, methodModule2, methodModule3, methodModule4, methodModule5];
function findMethodModule(id) {
  return METHOD_MODULES.find((m) => m.variants.some((v) => v.id === id));
}

// source/src/alternatives/fine-dry-ice-injection/config.ts
function defaultParticleInjectionSettings() {
  return {
    particleDiameterM: 1e-4,
    sizeProvenance: "User-configured monodisperse diameter (particleDiameterM, SI metres); unmeasured analytical study, not inferred from Nano.",
    effectiveConductivityWmK: 0.6,
    heatTransferProvenance: "Steady spherical conduction reference; effective film conductivity is an unmeasured sensitivity, not an aqueous-particle correlation.",
    solidDensityKgM3: 1560,
    hoseResidenceS: 1,
    probeResidenceS: 0.1,
    residenceProvenance: "Prescribed ideal entrained parcel residence; no pressure, slip, filtration or blockage model.",
    dryPeatMassKg: 0.5,
    initialMoistureDryBasis: 0.1,
    dryPeatCpJkgK: 1500,
    soilProvenance: "Assumed isolated warm peat specimen; finite UA sensitivity. No measured field constitutive law.",
    initialPhase: "solid",
    stepS: 5e-3,
    parcelStepS: 0.025
  };
}
function restoreParticleInjectionSettings(raw) {
  const next = defaultParticleInjectionSettings();
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return next;
  for (const key of Object.keys(next)) {
    const v = raw[key];
    if (typeof v === typeof next[key] && (typeof v !== "number" || Number.isFinite(v))) Object.assign(next, { [key]: v });
  }
  return next;
}
function particleObservationWindowS(config) {
  return config.thermal.endS;
}
function particleLinkedCompatibility(configs) {
  const first = configs[0];
  if (configs.some((c) => c.variantId !== "nanoparticles" || c.engine !== "particle")) return "Link particle runs only with the same bounded particle system.";
  const shared = ["initialK", "waterKg", "flowKgS", "inletK", "contactStartS", "conductanceWK", "endS", "seed"];
  if (configs.some((c) => shared.some((k) => c.thermal[k] !== first.thermal[k]))) return "Match water quantity, schedule, initial/inlet temperatures, soil contact, seed and window.";
  const keys = ["hoseResidenceS", "probeResidenceS", "dryPeatMassKg", "initialMoistureDryBasis", "dryPeatCpJkgK", "stepS", "parcelStepS"];
  if (configs.some((c) => keys.some((k) => c.particleInjection?.[k] !== first.particleInjection?.[k]))) return "Match transport, specimen, moisture and numerical discretization.";
  return null;
}

// source/src/story/contactCooling.ts
var CONTACT_COOLING_CONFIG = {
  startTimeS: 44,
  rapidRemovalTimeS: 55,
  endTimeS: FIRE_SEQUENCE_DURATION,
  stepS: 0.05,
  initialTemperatureK: 823.15,
  waterInletK: 293.15,
  waterBoilingK: 373.15,
  peatHeatCapacityJkgK: 1840,
  waterHeatCapacityJkgK: 4186,
  waterLatentHeatJkg: 226e4,
  dryIceInitialKg: 4,
  dryIceTemperatureK: 194.67,
  dryIceLatentHeatJkg: 6030 * 4.184 / 0.0440095,
  waterInitialKg: 5,
  waterFlowKgS: 0.22,
  waterStartTimeS: STORY_WATER_START
};
var share = 1 / (1 + STORY_CRACK_PATHS.length * 2);
var CONTACT_COOLING_PATCHES = [
  {
    id: "bore-base",
    xM: 0.4,
    yM: -1.44,
    radiusM: 0.2,
    peatMassKg: 0.5,
    dryIceConductanceWK: 8,
    waterConductanceWK: 48,
    waterArrivalTimeS: STORY_WATER_START,
    waterShare: share
  },
  ...STORY_CRACK_PATHS.flatMap((points, branch) => [0.2, 0.45].map((fraction, index) => {
    const [xM, yM] = pointAlongStoryPath(points, fraction);
    let lo = STORY_WATER_START, hi = FIRE_SEQUENCE_DURATION;
    for (let i = 0; i < 45; i++) {
      const mid = (lo + hi) / 2;
      if (storyWettingProgress(mid, branch) < fraction) lo = mid;
      else hi = mid;
    }
    return {
      id: `branch-${branch}-${index}`,
      xM,
      yM,
      radiusM: index ? 0.17 : 0.14,
      peatMassKg: 0.5,
      dryIceConductanceWK: 0,
      waterConductanceWK: 48,
      waterArrivalTimeS: (lo + hi) / 2,
      waterShare: share
    };
  }))
];
function validate(config, patches) {
  for (const value of Object.values(config)) if (!Number.isFinite(value)) throw new Error("Contact parameters must be finite.");
  if (config.stepS <= 0 || config.stepS > 1 || config.startTimeS < 0 || config.endTimeS < config.startTimeS || config.rapidRemovalTimeS < config.startTimeS || config.waterStartTimeS < config.startTimeS || config.initialTemperatureK < config.waterInletK || config.waterInletK < 273.15 || config.waterBoilingK <= config.waterInletK || config.dryIceTemperatureK <= 0 || config.dryIceTemperatureK >= config.waterInletK || config.peatHeatCapacityJkgK <= 0 || config.waterHeatCapacityJkgK <= 0 || config.waterLatentHeatJkg <= 0 || config.dryIceLatentHeatJkg <= 0 || config.dryIceInitialKg < 0 || config.waterInitialKg < 0 || config.waterFlowKgS < 0) throw new Error("Unsupported contact-model parameters.");
  let shares = 0;
  for (const p of patches) {
    if (Object.entries(p).some(([key, value]) => key !== "id" && (typeof value !== "number" || !Number.isFinite(value))) || p.peatMassKg <= 0 || p.radiusM <= 0 || p.dryIceConductanceWK < 0 || p.waterConductanceWK < 0 || p.waterArrivalTimeS < config.waterStartTimeS || p.waterShare < 0) throw new Error("Unsupported contact patch.");
    shares += p.waterShare;
  }
  if (!patches.length || shares > 1 + 1e-12) throw new Error("Water shares must sum to at most one.");
}
function initialState(config, patches) {
  const energy2 = patches.reduce((sum, p) => sum + p.peatMassKg * config.peatHeatCapacityJkgK * (config.initialTemperatureK - config.waterInletK), 0);
  return {
    storyTimeS: config.startTimeS,
    modelTimeS: 0,
    initialTemperatureK: config.initialTemperatureK,
    patches: patches.map((p) => ({
      ...p,
      temperatureK: config.initialTemperatureK,
      heatRemovedJ: 0,
      heatToDryIceJ: 0,
      heatToWaterJ: 0,
      waterReceivedKg: 0,
      liquidWaterKg: 0,
      waterVaporKg: 0,
      liquidWaterSensibleJ: 0,
      vaporEnthalpyJ: 0,
      waterTemperatureK: config.waterInletK,
      wetness: 0,
      dryCoolingDomainLimitReached: false
    })),
    ledger: {
      initialPeatEnergyJ: energy2,
      peatEnergyJ: energy2,
      heatToDryIceJ: 0,
      heatToWaterJ: 0,
      waterStoredSensibleJ: 0,
      vaporEnthalpyJ: 0,
      energyResidualJ: 0,
      dryIceInitialKg: config.dryIceInitialKg,
      dryIceRemainingKg: config.dryIceInitialKg,
      dryIceSublimatedKg: 0,
      dryIceExportedKg: 0,
      dryIceMassResidualKg: 0,
      waterInitialKg: config.waterInitialKg,
      waterRemainingSupplyKg: config.waterInitialKg,
      waterSuppliedKg: 0,
      waterBypassKg: 0,
      waterLiquidKg: 0,
      waterVaporKg: 0,
      waterMassResidualKg: 0
    }
  };
}
function exchangeWater(p, dt, config) {
  if (p.liquidWaterKg <= 0 || p.waterConductanceWK === 0) return;
  const cp = p.peatMassKg * config.peatHeatCapacityJkgK, cw = p.liquidWaterKg * config.waterHeatCapacityJkgK;
  const tw = config.waterInletK + p.liquidWaterSensibleJ / cw;
  const qEquilibrium = (p.temperatureK - tw) / (1 / cp + 1 / cw);
  const rate = p.waterConductanceWK * (1 / cp + 1 / cw);
  const qRequested = qEquilibrium * -Math.expm1(-rate * dt);
  const qToBoil = Math.max(0, cw * (config.waterBoilingK - tw));
  const qs = Math.min(qRequested, qToBoil);
  p.temperatureK -= qs / cp;
  p.liquidWaterSensibleJ += qs;
  p.heatToWaterJ += qs;
  if (qRequested > qToBoil && qEquilibrium > 0) {
    const sensibleTime = qToBoil > 0 ? -Math.log1p(-qToBoil / qEquilibrium) / rate : 0;
    const latentTime = Math.max(0, dt - sensibleTime);
    const qLatent = Math.min(
      p.liquidWaterKg * config.waterLatentHeatJkg,
      Math.max(0, cp * (p.temperatureK - config.waterBoilingK) * -Math.expm1(-p.waterConductanceWK * latentTime / cp))
    );
    const evaporated = qLatent / config.waterLatentHeatJkg;
    const sensibleOut = evaporated * config.waterHeatCapacityJkgK * (config.waterBoilingK - config.waterInletK);
    p.temperatureK -= qLatent / cp;
    p.heatToWaterJ += qLatent;
    p.liquidWaterKg -= evaporated;
    p.waterVaporKg += evaporated;
    p.liquidWaterSensibleJ = Math.max(0, p.liquidWaterSensibleJ - sensibleOut);
    p.vaporEnthalpyJ += sensibleOut + qLatent;
  }
}
function finish(state, config, mode, time) {
  const l = state.ledger;
  if (mode === "rapid" && time >= config.rapidRemovalTimeS && l.dryIceRemainingKg > 0) {
    l.dryIceExportedKg += l.dryIceRemainingKg;
    l.dryIceRemainingKg = 0;
  }
  l.peatEnergyJ = 0;
  l.heatToDryIceJ = 0;
  l.heatToWaterJ = 0;
  l.waterStoredSensibleJ = 0;
  l.vaporEnthalpyJ = 0;
  l.waterLiquidKg = 0;
  l.waterVaporKg = 0;
  for (const p of state.patches) {
    p.heatRemovedJ = p.heatToDryIceJ + p.heatToWaterJ;
    p.waterTemperatureK = p.liquidWaterKg > 1e-15 ? config.waterInletK + p.liquidWaterSensibleJ / (p.liquidWaterKg * config.waterHeatCapacityJkgK) : config.waterInletK;
    p.wetness = Math.min(1, p.liquidWaterKg / 0.15);
    l.peatEnergyJ += p.peatMassKg * config.peatHeatCapacityJkgK * (p.temperatureK - config.waterInletK);
    l.heatToDryIceJ += p.heatToDryIceJ;
    l.heatToWaterJ += p.heatToWaterJ;
    l.waterStoredSensibleJ += p.liquidWaterSensibleJ;
    l.vaporEnthalpyJ += p.vaporEnthalpyJ;
    l.waterLiquidKg += p.liquidWaterKg;
    l.waterVaporKg += p.waterVaporKg;
  }
  l.energyResidualJ = l.initialPeatEnergyJ - l.peatEnergyJ - l.heatToDryIceJ - l.waterStoredSensibleJ - l.vaporEnthalpyJ;
  l.dryIceMassResidualKg = l.dryIceInitialKg - l.dryIceRemainingKg - l.dryIceSublimatedKg - l.dryIceExportedKg;
  l.waterMassResidualKg = l.waterInitialKg - l.waterRemainingSupplyKg - l.waterBypassKg - l.waterLiquidKg - l.waterVaporKg;
  state.storyTimeS = time;
  state.modelTimeS = Math.max(0, time - config.startTimeS);
  return state;
}
function advance(state, time, config, mode) {
  let t = Math.max(config.startTimeS, state.storyTimeS);
  const end = Math.min(config.endTimeS, Math.max(config.startTimeS, time));
  const boundaries = [config.rapidRemovalTimeS, config.waterStartTimeS, ...state.patches.map((p) => p.waterArrivalTimeS)];
  while (t < end - 1e-10) {
    const gridNext = config.startTimeS + (Math.floor((t - config.startTimeS + 1e-9) / config.stepS) + 1) * config.stepS;
    let next = Math.min(end, gridNext);
    for (const boundary of boundaries) if (boundary > t + 1e-10 && boundary < next) next = boundary;
    const dt = next - t, l = state.ledger;
    finish(state, config, mode, t);
    const requests = state.patches.map((p) => {
      const c = p.peatMassKg * config.peatHeatCapacityJkgK;
      const available = Math.max(0, c * (p.temperatureK - config.waterInletK));
      const request = Math.max(0, c * (p.temperatureK - config.dryIceTemperatureK) * -Math.expm1(-p.dryIceConductanceWK * dt / c));
      if (request > available && l.dryIceRemainingKg * config.dryIceLatentHeatJkg > available) p.dryCoolingDomainLimitReached = true;
      return Math.min(available, request);
    });
    const requested = requests.reduce((a, b) => a + b, 0);
    const scale = requested > 0 ? Math.min(1, l.dryIceRemainingKg * config.dryIceLatentHeatJkg / requested) : 0;
    let usedDryIceKg = 0;
    state.patches.forEach((p, i) => {
      const q = requests[i] * scale;
      p.temperatureK -= q / (p.peatMassKg * config.peatHeatCapacityJkgK);
      p.heatToDryIceJ += q;
      usedDryIceKg += q / config.dryIceLatentHeatJkg;
    });
    l.dryIceRemainingKg = Math.max(0, l.dryIceRemainingKg - usedDryIceKg);
    l.dryIceSublimatedKg += usedDryIceKg;
    const supply = t >= config.waterStartTimeS - 1e-10 ? Math.min(l.waterRemainingSupplyKg, config.waterFlowKgS * dt) : 0;
    l.waterRemainingSupplyKg -= supply;
    l.waterSuppliedKg += supply;
    let contacted = 0;
    for (const p of state.patches) {
      const water = t >= p.waterArrivalTimeS - 1e-10 ? supply * p.waterShare : 0;
      p.waterReceivedKg += water;
      p.liquidWaterKg += water;
      contacted += water;
      exchangeWater(p, dt, config);
    }
    l.waterBypassKg += Math.max(0, supply - contacted);
    t = next;
  }
  return finish(state, config, mode, Math.max(0, Math.min(config.endTimeS, time)));
}
function simulateContactCooling(storyTimeS, mode, overrides = {}, patches = CONTACT_COOLING_PATCHES) {
  if (!Number.isFinite(storyTimeS)) throw new Error("Contact time must be finite.");
  const config = { ...CONTACT_COOLING_CONFIG, ...overrides };
  validate(config, patches);
  return advance(initialState(config, patches), storyTimeS, config, mode);
}

// source/src/alternatives/contactAdapter.ts
var ALTERNATIVE_CONTACT_STEP_S = 625e-5;
function createContactCoolingSession(overrides, patches) {
  const ownedConfig = structuredClone(overrides), ownedPatches = structuredClone(patches);
  const endS = ownedConfig.endTimeS ?? 90;
  let timeS = ownedConfig.startTimeS ?? 44;
  let state = simulateContactCooling(timeS, "gradual", ownedConfig, ownedPatches);
  return {
    advanceTo(targetS) {
      if (!Number.isFinite(targetS) || targetS < timeS || targetS > endS) throw new Error("Contact time must advance monotonically inside the observation window.");
      state = simulateContactCooling(targetS, "gradual", ownedConfig, ownedPatches);
      timeS = targetS;
      return structuredClone(state);
    },
    snapshot: () => structuredClone(state)
  };
}

// source/src/alternatives/originalPressurePulse.ts
var ORIGINAL_PRESSURE_PULSE = {
  id: "pressure-pulse",
  method: "4.2.3",
  number: "4.2.3",
  label: "Subsurface Pressure Pulse",
  subtitle: "Original rapid dry-ice release & connected water render",
  engines: [],
  media: ["none"],
  defaultMedium: "none",
  defaultEngine: "concept",
  stages: ["Original fire sequence", "Original rapid release", "Original connected water"],
  limitation: "Protected original render. Its existing accepted fields and separate contact readout remain available through the original workspace. An independent live-comparison adapter is unavailable; new comparison metrics are N/A. Open 4.2.3 in Simulation Version to use the original unchanged.",
  status: { illustrative: true, modeled: "Existing accepted numerical history and separate contact model; no new live comparison adapter", experimentallyValidated: false },
  provenance: "Verified V20 original: 161e7a4a1f8c35765e1878c132db79977be1f5ea; source/hash baseline in docs/review/version21/original-preservation.json"
};

// source/src/alternatives/registry.ts
var MEDIA = [
  { id: "none", label: "No treatment medium", category: "None", provenance: "Untreated reference or pressure-only concept" },
  { id: "water", label: "Liquid water", category: "Fluids", provenance: "Constant cp 4186 J/(kg K), Lv 2.26 MJ/kg near atmospheric boiling; thermal approximation" },
  { id: "co2-water", label: "Solid CO\u2082 + liquid water \xB7 contact proxy", category: "Solids + Fluids", provenance: "NIST / Giauque & Egan, 1937: 25.2 kJ/mol near 195 K; constant latent heat approximation" },
  { id: "unspecified", label: "Unspecified source / medium", category: "Unspecified", provenance: "No material properties; thermodynamic predictions unavailable" }
];
var status2 = (modeled) => ({ illustrative: true, modeled, experimentallyValidated: false });
var SHARED_VARIANTS = [
  { id: "baseline", method: "baseline", number: "00", label: "No-treatment baseline", subtitle: "Untreated smoldering reference / isolated thermal reference", engines: ["peat-fem", "contact", "concept"], media: ["none"], defaultMedium: "none", defaultEngine: "contact", stages: ["Initial conditions", "No intervention", "Observe reference"], limitation: "Contact reference is an isolated hot specimen with no combustion. Select Peat Fire FEM for reacting smoldering physics.", status: status2("FEM combustion or isolated contact reference"), provenance: "Existing peat FEM and contact-cooling models" }
];
var VARIANTS = [SHARED_VARIANTS[0], ...METHOD_MODULES[0].variants, ...METHOD_MODULES[4].variants, ORIGINAL_PRESSURE_PULSE, ...METHOD_MODULES[1].variants, ...METHOD_MODULES[2].variants, ...METHOD_MODULES[3].variants];
function variant(id) {
  return VARIANTS.find((v) => v.id === id) ?? VARIANTS[0];
}
function compatible(id, engine, medium) {
  const v = variant(id);
  if (!v.engines.length) return v.limitation;
  if (!v.engines.includes(engine)) return `${v.number} has no supported ${engine} adapter. Use conceptual stages${v.engines.includes("contact") ? " or the limited contact proxy" : ""}.`;
  if (!v.media.includes(medium)) return `${MEDIA.find((m) => m.id === medium)?.label} is incompatible with ${v.label}.`;
  if (engine === "contact" && medium === "unspecified") return "Unspecified source has no thermodynamic properties. Select conceptual stages or a known medium.";
  if (engine === "peat-fem" && medium !== "none") return "Peat FEM suppression source terms are disabled.";
  return null;
}
var PARAMETERS = [
  { key: "initialK", label: "Initial specimen temperature", unit: "K", min: 300, max: 1e3, step: 10, default: 823.15 },
  { key: "waterKg", label: "Finite liquid inventory", unit: "kg", min: 0, max: 5, step: 0.1, default: 0.5 },
  { key: "flowKgS", label: "Prescribed contact delivery", unit: "kg/s", min: 0, max: 0.2, step: 5e-3, default: 0.025 },
  { key: "inletK", label: "Assumed liquid inlet temperature", unit: "K", min: 273.15, max: 350, step: 1, default: 293.15 },
  { key: "contactStartS", label: "Prescribed liquid arrival", unit: "s", min: 0, max: 50, step: 1, default: 8 },
  { key: "conductanceWK", label: "Assumed thermal contact UA", unit: "W/K", min: 0, max: 100, step: 1, default: 24 },
  { key: "dryIceKg", label: "Finite CO\u2082 contact-proxy inventory", unit: "kg", min: 0, max: 1, step: 0.01, default: 0.05 },
  { key: "endS", label: "Observation window", unit: "s", min: 10, max: 120, step: 10, default: 60 }
];
function defaultThermal(id) {
  return { ...Object.fromEntries(PARAMETERS.map((p) => [p.key, p.default])), enabled: true, seed: 21, ...findMethodModule(id)?.defaultSettings(id) };
}

// source/src/peatfem/model.ts
var MATERIAL = Object.freeze({
  rho: 123,
  cp: 1840,
  phi: 1 - 123 / 1500,
  conductivity: 123 / 1500,
  diffusivity: 2e-5,
  gasReferenceDensity: 1.2,
  log10A: 16.8,
  activationJMol: 195e3,
  fuelOrder: 2.33,
  oxygenOrder: 0.24,
  oxygenPerFuel: 0.89,
  charYield: 0.61,
  heatJPerKg: 116e5
});
var DEFAULT_SETTINGS = {
  n: 4,
  lengthM: 0.1,
  ambientK: 300,
  oxygenKgM3: 0.233 * MATERIAL.gasReferenceDensity,
  ignitionW: 8,
  ignitionS: 180,
  ignitionWidthM: 0.025,
  heatTransfer: 10,
  massTransferMS: 2e-3,
  maxStepS: 2,
  endS: 600,
  chemistry: true
};
var SIGNS = Array.from({ length: 8 }, (_, a) => [a & 1 ? 1 : -1, a & 2 ? 1 : -1, a & 4 ? 1 : -1]);
function basis(x, y, z) {
  const shape = new Float64Array(8), gradients = new Float64Array(24);
  SIGNS.forEach(([s, t, u], a) => {
    shape[a] = (1 + s * x) * (1 + t * y) * (1 + u * z) / 8;
    gradients[3 * a] = s * (1 + t * y) * (1 + u * z) / 8;
    gradients[3 * a + 1] = t * (1 + s * x) * (1 + u * z) / 8;
    gradients[3 * a + 2] = u * (1 + s * x) * (1 + t * y) / 8;
  });
  return { shape, gradients };
}
function elementOperators(h) {
  const mass = new Float64Array(64), stiffness = new Float64Array(64), q = 1 / Math.sqrt(3);
  for (const x of [-q, q]) for (const y of [-q, q]) for (const z of [-q, q]) {
    const { shape, gradients } = basis(x, y, z), jacobian = h ** 3 / 8;
    for (let a = 0; a < 8; a++) for (let b = 0; b < 8; b++) {
      mass[8 * a + b] += shape[a] * shape[b] * jacobian;
      for (let d = 0; d < 3; d++) stiffness[8 * a + b] += gradients[3 * a + d] * gradients[3 * b + d] * 4 / h ** 2 * jacobian;
    }
  }
  return { mass, stiffness };
}
function createMesh(n, lengthM, ignitionWidthM = 0.025) {
  if (!Number.isInteger(n) || n < 1 || n > 32 || !(lengthM > 0) || !(ignitionWidthM > 0)) throw new Error("Invalid cubic FE mesh");
  const h = lengthM / n, count = (n + 1) ** 3, coordinates = new Float64Array(count * 3), connectivity = new Int32Array(n ** 3 * 8);
  const weights = new Float64Array(count), topArea = new Float64Array(count), ignitionShape = new Float64Array(count);
  const rows = Array.from({ length: count }, () => /* @__PURE__ */ new Map()), operators = elementOperators(h);
  const node = (i, j, k) => i + (n + 1) * (j + (n + 1) * k), q = 1 / Math.sqrt(3);
  for (let k = 0; k <= n; k++) for (let j = 0; j <= n; j++) for (let i = 0; i <= n; i++) coordinates.set([i * h, j * h, k * h], 3 * node(i, j, k));
  let e = 0;
  for (let k = 0; k < n; k++) for (let j = 0; j < n; j++) for (let i = 0; i < n; i++, e++) {
    const nodes = SIGNS.map(([s, t, u]) => node(i + (s + 1) / 2, j + (t + 1) / 2, k + (u + 1) / 2));
    connectivity.set(nodes, 8 * e);
    for (let a = 0; a < 8; a++) for (let b = 0; b < 8; b++) {
      weights[nodes[a]] += operators.mass[8 * a + b];
      rows[nodes[a]].set(nodes[b], (rows[nodes[a]].get(nodes[b]) ?? 0) + operators.stiffness[8 * a + b]);
    }
    if (k === n - 1) for (const xi of [-q, q]) for (const eta of [-q, q]) {
      const { shape } = basis(xi, eta, 1), x = (i + (xi + 1) / 2) * h, y = (j + (eta + 1) / 2) * h;
      const profile = Math.exp(-((x - lengthM / 2) ** 2 + (y - lengthM / 2) ** 2) / ignitionWidthM ** 2);
      for (let a = 0; a < 8; a++) {
        topArea[nodes[a]] += shape[a] * h * h / 4;
        ignitionShape[nodes[a]] += shape[a] * h * h / 4 * profile;
      }
    }
  }
  const norm2 = ignitionShape.reduce((a, b) => a + b, 0);
  for (let i = 0; i < count; i++) ignitionShape[i] /= norm2;
  const offsets = new Int32Array(count + 1), columns = [], values = [];
  rows.forEach((row, i) => {
    offsets[i] = columns.length;
    [...row].sort(([a], [b]) => a - b).forEach(([column, value]) => {
      columns.push(column);
      values.push(value);
    });
  });
  offsets[count] = columns.length;
  return {
    n,
    lengthM,
    h,
    coordinates,
    connectivity,
    weights,
    topArea,
    ignitionShape,
    stiffness: { offsets, columns: Int32Array.from(columns), values: Float64Array.from(values) },
    elementMass: operators.mass,
    elementStiffness: operators.stiffness
  };
}
function sparseAction(matrix, x) {
  const out = new Float64Array(x.length);
  for (let i = 0; i < x.length; i++) for (let p = matrix.offsets[i]; p < matrix.offsets[i + 1]; p++) out[i] += matrix.values[p] * x[matrix.columns[p]];
  return out;
}
var EMPTY_INTERVENTIONS = Object.freeze([]);

// source/src/peatfem/chemistry.ts
var R = 8.31446261815324;
var T_REF = 300;
var SIGMA = 5670374419e-17;
var CONSTITUENTS = Object.freeze({
  density: [1e3, 1500, 1300, 1300, 2500],
  // intrinsic kg/m³, C4 Table 2
  cp: [4186, 1840, 1260, 1260, 880],
  // J/(kg K), C4 Table 2
  conductivity: [0.6, 1, 0.26, 0.26, 1.2],
  // W/(m K), C4 Table 2
  molecularKgMol: [0.031998, 0.028014, 0.01801528, 0.02897],
  gasCp: 1e3
  // common-gas-cp approximation: explicit illustrative value, not measured
});
var REACTIONS = [
  { id: "dr", reactant: 0, product: -1, log10A: 27, E: 2e5, n: 0.5, nO: 0, yield: 0, oxygen: 0, enthalpy: 226e4 },
  { id: "pp", reactant: 1, product: 2, log10A: 8.18, E: 112e3, n: 5.31, nO: 0, yield: 0.28, oxygen: 0, enthalpy: 5e5 },
  { id: "po", reactant: 1, product: 3, log10A: 16.8, E: 195e3, n: 2.33, nO: 0.24, yield: 0.61, oxygen: 0.89, enthalpy: -116e5 },
  { id: "bo", reactant: 3, product: 4, log10A: 8.38, E: 117e3, n: 1.32, nO: 0.52, yield: 0.04, oxygen: 2.21, enthalpy: -289e5 },
  { id: "ao", reactant: 2, product: 4, log10A: 13.3, E: 172e3, n: 2.58, nO: 0.86, yield: 0.07, oxygen: 2.12, enthalpy: -278e5 }
];
var DEFAULT_MATERIAL_OPTIONS = { poreRadiationM: 5e-4, permeabilityM2: 1e-12 };
function properties(state, options = DEFAULT_MATERIAL_OPTIONS) {
  let occupied = 0, liquid = 0, heatCapacity = 0, conduction = 0;
  for (let j = 0; j < 5; j++) {
    const volume = state.solid[j] / CONSTITUENTS.density[j];
    occupied += volume;
    if (j === 0) liquid = volume;
    heatCapacity += state.solid[j] * CONSTITUENTS.cp[j];
    conduction += volume * CONSTITUENTS.conductivity[j];
  }
  const theta = 1 - occupied, porosity = theta + liquid;
  if (!(theta > 0) || !(state.temperature > 0) || [...state.solid, ...state.gas].some((v) => v < 0 || !Number.isFinite(v))) throw new Error("Invalid fixed-volume material state");
  const gasMass = state.gas.reduce((a, b) => a + b, 0);
  let gasMoles = 0;
  for (let j = 0; j < 4; j++) {
    gasMoles += state.gas[j] / CONSTITUENTS.molecularKgMol[j];
    heatCapacity += state.gas[j] * (CONSTITUENTS.gasCp - R / CONSTITUENTS.molecularKgMol[j]);
  }
  if (!(gasMass > 0) || !(heatCapacity > 0)) throw new Error("Empty gas/thermal storage");
  const gasR2 = R * gasMoles / gasMass, pressure = R * state.temperature * gasMoles / theta;
  const permeability = options.permeabilityM2 * (theta / porosity) ** 3;
  const conductivity = conduction + theta * 0.026 + options.poreRadiationM * theta * SIGMA * state.temperature ** 3;
  return { theta, porosity, heatCapacity, conductivity, permeability, gasMass, gasR: gasR2, pressure, gasDensity: gasMass / theta };
}
function energy(state) {
  return properties(state).heatCapacity * (state.temperature - T_REF);
}
function localInitial(peat, moistureRatio, temperature2 = 300, pressure = 101325, oxygenMassFraction = 0.233) {
  if (!(peat > 0) || moistureRatio < 0 || !(pressure > 0) || oxygenMassFraction < 0 || oxygenMassFraction > 1) throw new Error("Invalid initial inventories");
  const solid2 = Float64Array.from([peat * moistureRatio, peat, 0, 0, 0]), theta = 1 - solid2[0] / 1e3 - peat / 1500;
  const gasR2 = R * (oxygenMassFraction / 0.031998 + (1 - oxygenMassFraction) / 0.028014);
  const mass = pressure * theta / (gasR2 * temperature2);
  const out = { temperature: temperature2, solid: solid2, gas: Float64Array.from([mass * oxygenMassFraction, mass * (1 - oxygenMassFraction), 0, 0]) };
  properties(out);
  return out;
}
function reactionRates(state, reference2) {
  const mass = state.gas.reduce((a, b) => a + b, 0), Y = state.gas[0] / mass;
  return Float64Array.from(REACTIONS, (r) => {
    const normalization = r.reactant === 0 ? reference2.water : reference2.peat;
    if (normalization === 0 || state.solid[r.reactant] === 0 || r.oxygen > 0 && Y === 0) return 0;
    const oxygen = r.oxygen > 0 ? Math.expm1(r.nO * Math.log1p(Y)) : 1;
    return normalization * Math.exp(r.log10A * Math.LN10 - r.E / (R * state.temperature)) * (state.solid[r.reactant] / normalization) ** r.n * oxygen;
  });
}
function reactLocal(start, dt, reference2, enabled = true) {
  const state = { temperature: start.temperature, solid: start.solid.slice(), gas: start.gas.slice() };
  const extents = new Float64Array(5);
  let heatJ = 0, elapsed = 0, substeps = 0;
  if (!Number.isFinite(dt) || dt < 0) throw new Error("Invalid chemistry interval");
  if (!enabled) return { state, extents, heatJ, substeps };
  while (elapsed < dt) {
    if (++substeps > 1e4) throw new Error("Chemistry substep limit: refine outer step");
    const rates = reactionRates(state, reference2), C = properties(state).heatCapacity;
    const oxygenRate = REACTIONS.reduce((sum, r, k) => sum + r.oxygen * rates[k], 0);
    const heatRate = REACTIONS.reduce((sum, r, k) => sum - r.enthalpy * rates[k], 0);
    let h = dt - elapsed;
    const limits = [[state.solid[1], rates[1] + rates[2]], [state.solid[2], rates[4]], [state.solid[3], rates[3]]];
    for (const [inventory, rate] of limits) if (rate > 0) h = Math.min(h, 0.2 * inventory / rate);
    if (Math.abs(heatRate) > 0) h = Math.min(h, 3 * C / Math.abs(heatRate));
    if (!(h > 0) || !Number.isFinite(h) || elapsed + h === elapsed) throw new Error("Chemistry failed to progress");
    const extent = Float64Array.from(rates, (v) => v * h);
    if (oxygenRate > 0) {
      const ratio = oxygenRate * h / state.gas[0], factor = -Math.expm1(-ratio) / ratio;
      for (let k = 2; k < 5; k++) extent[k] *= factor;
    }
    if (rates[0] > 0) {
      const root = Math.sqrt(state.solid[0]), next = root - rates[0] / root * h / 2;
      extent[0] = next <= 0 ? state.solid[0] : state.solid[0] - next * next;
    }
    let fraction = 1;
    if (extent[1] + extent[2] > state.solid[1]) fraction = Math.min(fraction, state.solid[1] / (extent[1] + extent[2]));
    const usedO = REACTIONS.reduce((sum, r, k) => sum + r.oxygen * extent[k], 0);
    if (usedO > state.gas[0]) fraction = Math.min(fraction, state.gas[0] / usedO);
    const U = energy(state);
    let Q = 0;
    for (let k = 0; k < 5; k++) {
      const r = REACTIONS[k], e = extent[k] * fraction;
      extents[k] += e;
      state.solid[r.reactant] -= e;
      if (r.product >= 0) state.solid[r.product] += r.yield * e;
      state.gas[0] -= r.oxygen * e;
      state.gas[k === 0 ? 2 : 3] += (1 + r.oxygen - r.yield) * e;
      Q -= r.enthalpy * e;
    }
    state.temperature = T_REF + (U + Q) / properties(state).heatCapacity;
    properties(state);
    heatJ += Q;
    elapsed += h;
  }
  return { state, extents, heatJ, substeps };
}

// source/src/peatfem/operators.ts
var mappings = /* @__PURE__ */ new WeakMap();
function elementMap(mesh) {
  let map = mappings.get(mesh);
  if (map) return map;
  map = new Int32Array(mesh.connectivity.length * 8);
  const lookup = Array.from({ length: mesh.weights.length }, (_, i) => {
    const row = /* @__PURE__ */ new Map();
    for (let p = mesh.stiffness.offsets[i]; p < mesh.stiffness.offsets[i + 1]; p++) row.set(mesh.stiffness.columns[p], p);
    return row;
  });
  for (let e = 0; e < mesh.n ** 3; e++) for (let a = 0; a < 8; a++) for (let b = 0; b < 8; b++) map[64 * e + 8 * a + b] = lookup[mesh.connectivity[8 * e + a]].get(mesh.connectivity[8 * e + b]);
  mappings.set(mesh, map);
  return map;
}
function diffusionMatrix(mesh, coefficient) {
  const values = new Float64Array(mesh.stiffness.values.length), map = elementMap(mesh);
  for (let e = 0; e < mesh.n ** 3; e++) {
    let mean = 0;
    for (let a = 0; a < 8; a++) mean += coefficient[mesh.connectivity[8 * e + a]] / 8;
    if (mean < 0 || !Number.isFinite(mean)) throw new Error("Invalid FE diffusion coefficient");
    for (let k = 0; k < 64; k++) values[map[64 * e + k]] += mean * mesh.elementStiffness[k];
  }
  return { ...mesh.stiffness, values };
}
var dot = (a, b) => {
  let sum = 0;
  for (let i = 0; i < a.length; i++) sum += a[i] * b[i];
  return sum;
};
function norm(a) {
  return Math.sqrt(dot(a, a));
}
function solveSPD(matrix, rhs, initial, dirichlet = /* @__PURE__ */ new Map(), maxIterations = 1e3, relativeTolerance = 1e-10) {
  const values = matrix.values.slice(), b = rhs.slice(), n = rhs.length, diagonal = new Float64Array(n);
  const boundaryScale = new Float64Array(n);
  for (let i = 0; i < n; i++) for (let p2 = matrix.offsets[i]; p2 < matrix.offsets[i + 1]; p2++) if (matrix.columns[p2] === i) boundaryScale[i] = matrix.values[p2];
  for (let i = 0; i < n; i++) for (let p2 = matrix.offsets[i]; p2 < matrix.offsets[i + 1]; p2++) {
    const j = matrix.columns[p2];
    if (dirichlet.has(i)) {
      values[p2] = j === i ? boundaryScale[i] : 0;
      b[i] = dirichlet.get(i) * boundaryScale[i];
    } else if (dirichlet.has(j)) {
      b[i] -= values[p2] * dirichlet.get(j);
      values[p2] = 0;
    }
    if (j === i) diagonal[i] = values[p2];
  }
  const A = { ...matrix, values }, x = initial.slice();
  dirichlet.forEach((v, i) => {
    x[i] = v;
  });
  const ax = sparseAction(A, x), r = Float64Array.from(b, (v, i) => v - ax[i]), z = Float64Array.from(r, (v, i) => v / diagonal[i]), p = z.slice();
  const rhsNorm = norm(b), tolerance = 1e-14 + relativeTolerance * rhsNorm;
  let rz = dot(r, z), iterations = 0;
  while (norm(r) > tolerance && iterations < maxIterations) {
    const ap = sparseAction(A, p), denominator = dot(p, ap);
    if (!(denominator > 0) || !Number.isFinite(denominator)) throw new Error("Pressure/heat CG lost positive definiteness");
    const alpha = rz / denominator;
    for (let i = 0; i < n; i++) {
      x[i] += alpha * p[i];
      r[i] -= alpha * ap[i];
      z[i] = r[i] / diagonal[i];
    }
    const next = dot(r, z), beta = next / rz;
    for (let i = 0; i < n; i++) p[i] = z[i] + beta * p[i];
    rz = next;
    iterations++;
  }
  const action = sparseAction(A, x), residual = Float64Array.from(b, (v, i) => v - action[i]), absoluteResidual = norm(residual);
  if (!Number.isFinite(absoluteResidual) || absoluteResidual > tolerance * 1.2) throw new Error(`CG residual failed after ${iterations} iterations: ${absoluteResidual}`);
  return { field: x, evidence: { iterations, absoluteResidual, relativeResidual: absoluteResidual / Math.max(rhsNorm, 1e-30) } };
}
function solveMonotone(matrix, rhs, initial, maxIterations = 2e3, tolerance = 1e-10) {
  const n = rhs[0].length, diagonal = new Float64Array(n), fields = initial.map((x) => x.slice());
  for (let i = 0; i < n; i++) for (let p = matrix.offsets[i]; p < matrix.offsets[i + 1]; p++) {
    if (matrix.columns[p] === i) diagonal[i] = matrix.values[p];
    else if (matrix.values[p] > 1e-18) throw new Error("Transport operator is not monotone");
  }
  if ([...diagonal].some((v) => v <= 0 || !Number.isFinite(v))) throw new Error("Nonpositive transport diagonal");
  const scale = rhs.map((x) => Math.max(norm(x), 1e-30));
  let iterations = 0, relativeResidual = Infinity, absoluteResidual = Infinity;
  while (iterations < maxIterations) {
    for (let i = 0; i < n; i++) for (let k = 0; k < fields.length; k++) {
      let value = rhs[k][i];
      for (let p = matrix.offsets[i]; p < matrix.offsets[i + 1]; p++) if (matrix.columns[p] !== i) value -= matrix.values[p] * fields[k][matrix.columns[p]];
      fields[k][i] = value / diagonal[i];
    }
    iterations++;
    relativeResidual = 0;
    absoluteResidual = 0;
    for (let k = 0; k < fields.length; k++) {
      const ax = sparseAction(matrix, fields[k]), res = Float64Array.from(rhs[k], (v, i) => v - ax[i]), absolute = norm(res);
      relativeResidual = Math.max(relativeResidual, absolute / scale[k]);
      absoluteResidual = Math.max(absoluteResidual, absolute);
    }
    if (relativeResidual < tolerance || absoluteResidual < 1e-14) break;
  }
  if (!Number.isFinite(relativeResidual) || relativeResidual > tolerance && absoluteResidual > 1e-14) throw new Error(`Monotone solve did not converge: ${iterations}, residual ${relativeResidual}`);
  return { fields, evidence: { iterations, relativeResidual, absoluteResidual } };
}
function edges(matrix) {
  const list = [];
  for (let i = 0; i < matrix.offsets.length - 1; i++) for (let p = matrix.offsets[i]; p < matrix.offsets[i + 1]; p++) {
    const j = matrix.columns[p];
    if (j <= i) continue;
    let reverse = matrix.offsets[j];
    while (matrix.columns[reverse] !== i && reverse < matrix.offsets[j + 1]) reverse++;
    const value = -matrix.values[p];
    if (value < -1e-16) throw new Error("Q1 cubic stiffness has positive off-diagonal");
    if (value > 0) list.push({ i, j, ij: p, ji: reverse, conductance: value });
  }
  return list;
}
function addDiagonal(matrix, diagonal) {
  const values = matrix.values.slice();
  for (let i = 0; i < diagonal.length; i++) for (let p = matrix.offsets[i]; p < matrix.offsets[i + 1]; p++) if (matrix.columns[p] === i) values[p] += diagonal[i];
  return { ...matrix, values };
}
function upwindOperator(diffusion, edgeList, flux, boundary, storage, dt, scale = 1) {
  const values = Float64Array.from(diffusion.values, (v) => dt * v), diagonal = storage.slice();
  edgeList.forEach((e, k) => {
    const f = dt * flux[k] * scale;
    if (f >= 0) {
      diagonal[e.i] += f;
      values[e.ji] -= f;
    } else {
      diagonal[e.j] -= f;
      values[e.ij] += f;
    }
  });
  for (let i = 0; i < storage.length; i++) if (boundary[i] > 0) diagonal[i] += dt * boundary[i] * scale;
  return addDiagonal({ ...diffusion, values }, diagonal);
}
function gasR(gas, i) {
  let mass = 0, moles = 0;
  for (let j = 0; j < 4; j++) {
    mass += gas[j][i];
    moles += gas[j][i] / CONSTITUENTS.molecularKgMol[j];
  }
  if (!(mass > 0)) throw new Error("Gas inventory vanished");
  return R * moles / mass;
}
var logMean = (a, b) => Math.abs(a - b) < 1e-8 * Math.max(a, b) ? (a + b) / 2 : (a - b) / Math.log(a / b);
function gasStep(mesh, old, temperature2, theta, permeability, dt, options) {
  const n = theta.length, mass = Float64Array.from(theta, (_, i) => old.reduce((sum, g) => sum + g[i], 0));
  let gas = old.map((g) => g.slice()), pressure = Float64Array.from(theta, (v, i) => mass[i] / v * gasR(old, i) * temperature2[i]);
  const stiffness = diffusionMatrix(mesh, permeability), edgeList = edges(stiffness), rho = new Float64Array(n);
  const dirichlet = new Map(options.pressureBoundary);
  if (!options.closed && !options.pressureBoundary) mesh.topArea.forEach((v, i) => {
    if (v > 0) dirichlet.set(i, options.ambientPressure);
  });
  const diffusion = diffusionMatrix(mesh, Float64Array.from(mass, (v) => v * options.diffusivity));
  let pressureSolve = { iterations: 0, relativeResidual: 0, absoluteResidual: 0 }, speciesSolve = { ...pressureSolve };
  let massFlux = new Float64Array(edgeList.length), boundaryMassFlux = new Float64Array(n), picardError = Infinity;
  for (let iteration = 0; iteration < 50; iteration++) {
    const chi = Float64Array.from(theta, (v, i) => v / (gasR(gas, i) * temperature2[i]));
    for (let i = 0; i < n; i++) rho[i] = chi[i] * pressure[i] / theta[i];
    const values = new Float64Array(stiffness.values.length), rhs = Float64Array.from(mass, (v, i) => v * mesh.weights[i]), diagonal = Float64Array.from(chi, (v, i) => v * mesh.weights[i]);
    const conductance = new Float64Array(edgeList.length), gravity = new Float64Array(edgeList.length);
    edgeList.forEach((e, k) => {
      const density = (rho[e.i] + rho[e.j]) / 2, G = e.conductance * density / options.viscosity;
      conductance[k] = G;
      gravity[k] = -logMean(rho[e.i], rho[e.j]) * options.gravity * (mesh.coordinates[3 * e.j + 2] - mesh.coordinates[3 * e.i + 2]);
      values[e.ij] -= dt * G;
      values[e.ji] -= dt * G;
      diagonal[e.i] += dt * G;
      diagonal[e.j] += dt * G;
      rhs[e.i] -= dt * G * gravity[k];
      rhs[e.j] += dt * G * gravity[k];
    });
    const solved = solveSPD(addDiagonal({ ...stiffness, values }, diagonal), rhs, pressure, dirichlet, options.maxIterations ?? 1e3, options.solveTolerance ?? 1e-10);
    pressureSolve = solved.evidence;
    const newMass = Float64Array.from(chi, (v, i) => v * solved.field[i]), outgoing = new Float64Array(n);
    massFlux = Float64Array.from(edgeList, (e, k) => conductance[k] * (solved.field[e.i] - solved.field[e.j] + gravity[k]));
    edgeList.forEach((e, k) => {
      outgoing[e.i] += massFlux[k];
      outgoing[e.j] -= massFlux[k];
    });
    boundaryMassFlux = new Float64Array(n);
    dirichlet.forEach((_, i) => {
      boundaryMassFlux[i] = (mass[i] - newMass[i]) * mesh.weights[i] / dt - outgoing[i];
    });
    const storage = Float64Array.from(newMass, (v, i) => v * mesh.weights[i]), robin = Float64Array.from(mesh.topArea, (v) => options.closed ? 0 : dt * v * options.transferKgM2S);
    const matrix = addDiagonal(upwindOperator(diffusion, edgeList, massFlux, boundaryMassFlux, storage, dt), robin);
    const speciesRhs = old.map((field, j) => Float64Array.from(field, (v, i) => v * mesh.weights[i] + (dt * Math.max(0, -boundaryMassFlux[i]) + robin[i]) * options.ambientY[j]));
    const initial = gas.map((g) => Float64Array.from(g, (v, i) => v / gas.reduce((sum, f) => sum + f[i], 0)));
    const transported = solveMonotone(matrix, speciesRhs, initial, options.maxIterations ?? 2e3, options.solveTolerance ?? 1e-10);
    speciesSolve = transported.evidence;
    const next = transported.fields.map((Y) => Float64Array.from(Y, (v, i) => v * newMass[i]));
    picardError = 0;
    for (let i = 0; i < n; i++) {
      if (!(solved.field[i] > 0) || next.some((g) => g[i] < 0 || !Number.isFinite(g[i]))) throw new Error("Invalid gas-flow candidate");
      const actual = next.reduce((sum, g) => sum + g[i], 0) / theta[i] * gasR(next, i) * temperature2[i];
      picardError = Math.max(picardError, Math.abs(actual - solved.field[i]) / actual, Math.abs(solved.field[i] - pressure[i]) / solved.field[i]);
    }
    if (picardError >= 1e-8) {
      gas = next.map((g, j) => Float64Array.from(g, (v, i) => (v + gas[j][i]) / 2));
      pressure = Float64Array.from(solved.field, (v, i) => (v + pressure[i]) / 2);
    } else {
      gas = next;
      pressure = solved.field;
    }
    if (picardError < 1e-8) return { gas, pressure, massFlux, boundaryMassFlux, edgeList, pressureSolve, speciesSolve, picardIterations: iteration + 1, picardError };
  }
  throw new Error(`Gas EOS/continuity Picard did not converge: ${picardError}`);
}

// source/src/peatfem/coupled.ts
var DEFAULT_SETTINGS2 = {
  n: 4,
  lengthM: 0.1,
  ambientK: 300,
  oxygenMassFraction: 0.233,
  moistureRatio: 0.1,
  dryDensityKgM3: 123,
  ambientPressurePa: 101325,
  ignitionW: 8,
  ignitionS: 180,
  ignitionWidthM: 0.025,
  heatTransfer: 10,
  transferKgM2S: 0.01,
  permeabilityM2: 1e-12,
  poreRadiationM: 5e-4,
  gasDiffusivityM2S: 2e-5,
  gasViscosityPaS: 18e-6,
  emissivity: 0.95,
  gravityMS2: 0,
  maxStepS: 1,
  endS: 600,
  chemistry: true,
  closed: false
};
var zero = () => ({ iterations: 0, relativeResidual: 0, absoluteResidual: 0 });
function copy(f) {
  const out = { ...f, gas: f.gas.map((g) => g.slice()), ledger: { ...f.ledger, gasBoundaryKg: f.ledger.gasBoundaryKg.slice(), reactionExtentsKg: f.ledger.reactionExtentsKg.slice() }, peak: { ...f.peak } };
  for (const key of ["temperature", "oxygen", "fuel", "char", "water", "alphaChar", "ash", "pressure", "porosity", "darcySpeed", "darcyFlux", "peclet"]) out[key] = f[key].slice();
  return out;
}
var solids = (f) => [f.water, f.fuel, f.alphaChar, f.char, f.ash];
function local(f, i) {
  return { temperature: f.temperature[i], solid: Float64Array.from(solids(f), (a) => a[i]), gas: Float64Array.from(f.gas, (a) => a[i]) };
}
var opts = (s) => ({ poreRadiationM: s.poreRadiationM, permeabilityM2: s.permeabilityM2 });
function totals(mesh, f) {
  let energyJ = 0, gasKg = 0, maximumK = -Infinity, maximumNode = 0, oxygenKg = 0, peatKg = 0, charKg = 0, waterKg = 0, ashKg = 0;
  for (let i = 0; i < mesh.weights.length; i++) {
    const w = mesh.weights[i];
    energyJ += energy(local(f, i)) * w;
    gasKg += f.gas.reduce((sum, g) => sum + g[i], 0) * w;
    oxygenKg += f.gas[0][i] * w;
    peatKg += f.fuel[i] * w;
    charKg += (f.char[i] + f.alphaChar[i]) * w;
    waterKg += f.water[i] * w;
    ashKg += f.ash[i] * w;
    if (f.temperature[i] > maximumK) {
      maximumK = f.temperature[i];
      maximumNode = i;
    }
  }
  return { energyJ, gasKg, oxygenKg, peatKg, charKg, waterKg, ashKg, maximumK, maximumNode, componentsKg: gasKg + peatKg + charKg + waterKg + ashKg };
}
var PeatSolver = class {
  mesh;
  settings;
  frame;
  nextStepS;
  status = "paused";
  error = "";
  constructor(settings) {
    if (Object.values(settings).some((v) => typeof v === "number" && !Number.isFinite(v))) throw new Error("Nonfinite settings");
    if (settings.ambientK <= 0 || settings.oxygenMassFraction < 0 || settings.oxygenMassFraction > 1 || settings.moistureRatio < 0 || settings.dryDensityKgM3 <= 0 || settings.ambientPressurePa <= 0 || settings.ignitionW < 0 || settings.ignitionS < 0 || settings.heatTransfer < 0 || settings.transferKgM2S < 0 || settings.permeabilityM2 <= 0 || settings.poreRadiationM < 0 || settings.gasDiffusivityM2S < 0 || settings.gasViscosityPaS <= 0 || settings.emissivity < 0 || settings.emissivity > 1 || settings.maxStepS <= 0 || settings.endS <= 0 || (settings.initialK ?? 300) <= 0 || (settings.initialPressurePa ?? 101325) <= 0 || (settings.toleranceScale ?? 1) <= 0 || (settings.solveTolerance ?? 1e-10) <= 0) throw new Error("Invalid physical/numerical settings");
    this.settings = { ...settings };
    this.mesh = createMesh(settings.n, settings.lengthM, settings.ignitionWidthM);
    this.nextStepS = settings.maxStepS;
    const state = localInitial(settings.dryDensityKgM3, settings.moistureRatio, settings.initialK ?? settings.ambientK, settings.initialPressurePa ?? settings.ambientPressurePa, settings.oxygenMassFraction), n = this.mesh.weights.length;
    const array = (v = 0) => new Float64Array(n).fill(v);
    this.frame = {
      timeS: 0,
      temperature: array(state.temperature),
      water: array(state.solid[0]),
      fuel: array(state.solid[1]),
      alphaChar: array(),
      char: array(),
      ash: array(),
      gas: Array.from(state.gas, (v) => array(v)),
      oxygen: array(),
      pressure: array(),
      porosity: array(),
      darcySpeed: array(),
      darcyFlux: new Float64Array(3 * n),
      peclet: array(),
      ledger: { ignitionJ: 0, reactionJ: 0, heatOutJ: 0, gasEnthalpyOutJ: 0, oxygenInKg: 0, oxygenUsedKg: 0, reactedPeatKg: 0, productGasKg: 0, inventoryLimited: 0, gasBoundaryKg: new Float64Array(4), reactionExtentsKg: new Float64Array(5) },
      stepS: 0,
      splittingError: 0,
      rejectedSteps: 0,
      heatSolve: zero(),
      oxygenSolve: zero(),
      pressureSolve: zero(),
      nonlinearIterations: 0,
      nonlinearError: 0,
      chemistrySubsteps: 0,
      peak: { temperatureK: state.temperature, node: 0, timeS: 0 }
    };
    this.derive(this.frame);
  }
  derive(f) {
    const m = this.mesh, s = this.settings, n = m.weights.length, weight = new Float64Array(n), rho = new Float64Array(n), K = new Float64Array(n);
    f.darcyFlux.fill(0);
    for (let i = 0; i < n; i++) {
      const p = properties(local(f, i), opts(s));
      f.pressure[i] = p.pressure;
      f.porosity[i] = p.porosity;
      f.oxygen[i] = f.gas[0][i] / p.gasMass;
      rho[i] = p.gasDensity;
      K[i] = p.permeability;
    }
    const gradients = basis(0, 0, 0).gradients;
    for (let e = 0; e < m.n ** 3; e++) {
      const gradient = [0, 0, 0];
      let permeability = 0, density = 0;
      for (let a = 0; a < 8; a++) {
        const i = m.connectivity[8 * e + a];
        permeability += K[i] / 8;
        density += rho[i] / 8;
        for (let d = 0; d < 3; d++) gradient[d] += gradients[3 * a + d] * 2 / m.h * f.pressure[i];
      }
      for (let a = 0; a < 8; a++) {
        const i = m.connectivity[8 * e + a];
        weight[i]++;
        for (let d = 0; d < 3; d++) f.darcyFlux[3 * i + d] += -permeability / s.gasViscosityPaS * (gradient[d] + (d === 2 ? density * s.gravityMS2 : 0));
      }
    }
    for (let i = 0; i < n; i++) {
      for (let d = 0; d < 3; d++) f.darcyFlux[3 * i + d] /= weight[i];
      f.darcySpeed[i] = Math.hypot(...f.darcyFlux.subarray(3 * i, 3 * i + 3));
      const theta = properties(local(f, i), opts(s)).theta;
      f.peclet[i] = s.gasDiffusivityM2S > 0 ? f.darcySpeed[i] * m.h / (theta * s.gasDiffusivityM2S) : 0;
    }
  }
  split(start, dt) {
    const f = copy(start), s = this.settings, m = this.mesh, n = m.weights.length, Cbefore = new Float64Array(n), theta = new Float64Array(n), K = new Float64Array(n);
    const reference2 = { peat: s.dryDensityKgM3, water: s.dryDensityKgM3 * s.moistureRatio };
    for (let i = 0; i < n; i++) {
      const next = reactLocal(local(f, i), dt, reference2, s.chemistry), w = m.weights[i];
      f.temperature[i] = next.state.temperature;
      solids(f).forEach((a, j) => {
        a[i] = next.state.solid[j];
      });
      f.gas.forEach((a, j) => {
        a[i] = next.state.gas[j];
      });
      f.ledger.reactionJ += next.heatJ * w;
      f.chemistrySubsteps += next.substeps;
      next.extents.forEach((e, k) => {
        f.ledger.reactionExtentsKg[k] += e * w;
        f.ledger.oxygenUsedKg += e * w * REACTIONS[k].oxygen;
        if (k === 1 || k === 2) f.ledger.reactedPeatKg += e * w;
        if (k > 0) f.ledger.productGasKg += e * w * (1 + REACTIONS[k].oxygen - REACTIONS[k].yield);
      });
      const p = properties(next.state, opts(s));
      Cbefore[i] = p.heatCapacity;
      theta[i] = p.theta;
      K[i] = p.permeability;
    }
    const flowOptions = { viscosity: s.gasViscosityPaS, diffusivity: s.gasDiffusivityM2S, ambientPressure: s.ambientPressurePa, ambientY: Float64Array.from([s.oxygenMassFraction, 1 - s.oxygenMassFraction, 0, 0]), transferKgM2S: s.transferKgM2S, gravity: s.gravityMS2, closed: s.closed, maxIterations: s.maxIterations, solveTolerance: s.solveTolerance };
    const initialTemperature = f.temperature.slice(), initialGas = f.gas.map((g) => g.slice());
    const Cafter = new Float64Array(n), conductivity = new Float64Array(n), robin = new Float64Array(n), rhs = new Float64Array(n);
    const ignitionDt = Math.max(0, Math.min(start.timeS + dt, s.ignitionS) - Math.min(start.timeS, s.ignitionS));
    const heatCp = CONSTITUENTS.gasCp;
    let flow, thermalError = Infinity, thermalIterations = 0;
    for (; thermalIterations < 40; thermalIterations++) {
      const guess = f.temperature.slice();
      flow = gasStep(m, initialGas, guess, theta, K, dt, flowOptions);
      f.gas = flow.gas;
      for (let i = 0; i < n; i++) {
        const p = properties(local(f, i), opts(s));
        Cafter[i] = p.heatCapacity;
        conductivity[i] = p.conductivity;
        const radiation = s.closed ? 0 : s.emissivity * 5670374419e-17 * (guess[i] + s.ambientK) * (guess[i] ** 2 + s.ambientK ** 2);
        robin[i] = s.closed ? 0 : m.topArea[i] * (s.heatTransfer + radiation);
        rhs[i] = Cbefore[i] * (initialTemperature[i] - T_REF) * m.weights[i] + dt * robin[i] * (s.ambientK - T_REF) + s.ignitionW * ignitionDt * m.ignitionShape[i];
        if (flow.boundaryMassFlux[i] < 0) rhs[i] -= dt * flow.boundaryMassFlux[i] * heatCp * (s.ambientK - T_REF);
      }
      const storage = Float64Array.from(Cafter, (v, i) => v * m.weights[i]), diffusion = diffusionMatrix(m, conductivity);
      const heatMatrix = addDiagonal(upwindOperator(diffusion, flow.edgeList, flow.massFlux, flow.boundaryMassFlux, storage, dt, heatCp), Float64Array.from(robin, (v) => dt * v));
      const solved = solveMonotone(heatMatrix, [rhs], [Float64Array.from(guess, (T) => T - T_REF)], s.maxIterations ?? 2e3, s.solveTolerance ?? 1e-10);
      f.temperature = Float64Array.from(solved.fields[0], (v) => v + T_REF);
      f.heatSolve = solved.evidence;
      thermalError = 0;
      for (let i = 0; i < n; i++) thermalError = Math.max(thermalError, Math.abs(f.temperature[i] - guess[i]) / Math.max(1, f.temperature[i]));
      if (thermalError < 1e-8) break;
    }
    if (!flow || thermalError >= 1e-8) throw new Error(`Thermal/pressure Picard failed: ${thermalError}`);
    f.pressureSolve = flow.pressureSolve;
    f.oxygenSolve = flow.speciesSolve;
    f.nonlinearIterations = flow.picardIterations + thermalIterations + 1;
    f.nonlinearError = Math.max(flow.picardError, thermalError);
    f.ledger.ignitionJ += s.ignitionW * ignitionDt;
    for (let i = 0; i < n; i++) {
      f.ledger.heatOutJ += dt * robin[i] * (f.temperature[i] - s.ambientK);
      f.ledger.gasEnthalpyOutJ += dt * flow.boundaryMassFlux[i] * heatCp * ((flow.boundaryMassFlux[i] > 0 ? f.temperature[i] : s.ambientK) - T_REF);
      const total = f.gas.reduce((a, g) => a + g[i], 0);
      for (let j = 0; j < 4; j++) {
        const Y = f.gas[j][i] / total, out = flow.boundaryMassFlux[i] * (flow.boundaryMassFlux[i] > 0 ? Y : flowOptions.ambientY[j]) + (s.closed ? 0 : m.topArea[i] * s.transferKgM2S * (Y - flowOptions.ambientY[j]));
        f.ledger.gasBoundaryKg[j] += dt * out;
      }
    }
    f.ledger.oxygenInKg = -f.ledger.gasBoundaryKg[0];
    f.timeS += dt;
    f.stepS = dt;
    this.derive(f);
    const t = totals(m, f);
    if (t.maximumK > f.peak.temperatureK) f.peak = { temperatureK: t.maximumK, node: t.maximumNode, timeS: f.timeS };
    return f;
  }
  advance(maxDt = this.settings.maxStepS, interventions = EMPTY_INTERVENTIONS) {
    if (interventions.length) throw new Error("Suppression interventions remain disabled");
    if (this.status === "failed") throw new Error(this.error);
    const remaining = this.settings.endS - this.frame.timeS;
    if (remaining < 1e-9) return this.snapshot();
    let dt = Math.min(maxDt, this.nextStepS, remaining), rejected = 0, last = "";
    if (!(dt > 0)) throw new Error("Invalid step");
    for (let attempt = 0; attempt < 24 && dt >= 1e-7; attempt++) try {
      const full = this.split(this.frame, dt), half1 = this.split(this.frame, dt / 2), half = this.split(half1, dt / 2);
      let error = 0;
      const scale = this.settings.toleranceScale ?? 1;
      for (let i = 0; i < this.mesh.weights.length; i++) {
        error = Math.max(error, Math.abs(half.temperature[i] - full.temperature[i]) / (scale * (0.1 + 1e-3 * half.temperature[i])), Math.abs(half.pressure[i] - full.pressure[i]) / (scale * (1 + 5e-4 * half.pressure[i])));
        for (const key of ["water", "fuel", "alphaChar", "char", "ash"]) error = Math.max(error, Math.abs(half[key][i] - full[key][i]) / (scale * (1e-5 + 2e-3 * this.settings.dryDensityKgM3)));
        for (let j = 0; j < 4; j++) error = Math.max(error, Math.abs(half.gas[j][i] - full.gas[j][i]) / (scale * (1e-7 + 1e-3 * half.gas.reduce((sum, g) => sum + g[i], 0))));
      }
      if (error > 1) {
        last = `split error ${error}`;
        rejected++;
        dt *= Math.max(0.2, 0.8 / Math.sqrt(error));
        continue;
      }
      half.splittingError = error;
      half.stepS = dt;
      half.rejectedSteps = this.frame.rejectedSteps + rejected;
      for (const key of ["heatSolve", "oxygenSolve", "pressureSolve"]) half[key] = { iterations: half1[key].iterations + half[key].iterations, relativeResidual: Math.max(half1[key].relativeResidual, half[key].relativeResidual), absoluteResidual: Math.max(half1[key].absoluteResidual, half[key].absoluteResidual) };
      this.frame = half;
      this.nextStepS = Math.min(this.settings.maxStepS, dt * Math.min(2, Math.max(0.5, 0.8 / Math.sqrt(Math.max(error, 1e-10)))));
      return this.snapshot();
    } catch (e) {
      last = String(e);
      rejected++;
      dt *= 0.5;
    }
    this.status = "failed";
    this.error = `Solver stopped at ${this.frame.timeS.toFixed(6)} physical s: ${last}`;
    throw new Error(this.error);
  }
  snapshot() {
    return copy(this.frame);
  }
  restore(f) {
    if (!Number.isFinite(f.timeS) || f.timeS < 0 || f.timeS > this.settings.endS || !Number.isFinite(f.splittingError) || f.splittingError < 0 || !Number.isFinite(f.stepS) || f.stepS < 0 || f.peak.node < 0 || f.peak.node >= this.mesh.weights.length || f.peak.timeS > f.timeS) throw new Error("Invalid checkpoint metadata");
    const n = this.mesh.weights.length;
    for (const a of [...solids(f), ...f.gas, f.temperature]) if (a.length !== n || [...a].some((v) => v < 0 || !Number.isFinite(v))) throw new Error("Invalid checkpoint field");
    for (let i = 0; i < n; i++) properties(local(f, i), opts(this.settings));
    this.frame = copy(f);
    this.derive(this.frame);
    this.nextStepS = f.stepS > 0 ? Math.min(this.settings.maxStepS, f.stepS * Math.min(2, Math.max(0.5, 0.8 / Math.sqrt(Math.max(f.splittingError, 1e-10))))) : this.settings.maxStepS;
    this.status = "paused";
    this.error = "";
  }
};

// source/src/alternatives/model.ts
function buildContact(config) {
  const { thermal: s } = config, active = s.enabled && config.variantId !== "baseline";
  const water = active && (config.medium === "water" || config.medium === "co2-water");
  const dry = active && config.medium === "co2-water";
  const count = 3;
  const patches = Array.from({ length: count }, (_, i) => ({
    id: `specimen-${i}`,
    xM: 0,
    yM: -(i + 1) * 0.1,
    radiusM: 0.04,
    peatMassKg: 0.5,
    dryIceConductanceWK: dry && i === 0 ? 8 : 0,
    waterConductanceWK: water ? s.conductanceWK : 0,
    waterArrivalTimeS: s.contactStartS,
    waterShare: 1 / count
  }));
  return createContactCoolingSession({
    startTimeS: 0,
    endTimeS: s.endS,
    rapidRemovalTimeS: s.endS,
    waterStartTimeS: s.contactStartS,
    stepS: ALTERNATIVE_CONTACT_STEP_S,
    initialTemperatureK: s.initialK,
    waterInletK: s.inletK,
    dryIceInitialKg: dry ? s.dryIceKg : 0,
    waterInitialKg: water ? s.waterKg : 0,
    waterFlowKgS: water ? s.flowKgS : 0
  }, patches);
}
function createSupportedRun(config) {
  const reason = compatible(config.variantId, config.engine, config.medium);
  if (reason) throw new Error(reason);
  const windowS = config.engine === "peat-fem" ? config.fem.endS : config.thermal.endS;
  if (!Number.isFinite(windowS) || windowS <= 0) throw new Error("Observation window must be finite and positive.");
  const contact = config.engine === "contact" ? buildContact(config) : void 0;
  const fem = config.engine === "peat-fem" ? new PeatSolver(config.fem) : void 0;
  const base2 = fem ? totals(fem.mesh, fem.frame) : void 0;
  let timeS = 0, contactState = contact?.snapshot();
  const endS = fem ? config.fem.endS : config.thermal.endS;
  function snapshot() {
    if (contactState) {
      const l = contactState.ledger;
      return { timeS, contact: structuredClone(contactState), metrics: {
        maximumK: Math.max(...contactState.patches.map((p) => p.temperatureK)),
        waterUsedKg: l.waterSuppliedKg,
        dryIceUsedKg: l.dryIceSublimatedKg,
        energyJ: l.heatToWaterJ + l.heatToDryIceJ,
        energyResidualJ: l.energyResidualJ,
        massResidualKg: Math.max(Math.abs(l.waterMassResidualKg), Math.abs(l.dryIceMassResidualKg)),
        oxygenKg: null,
        fuelKg: null,
        reactionW: null
      } };
    }
    if (fem && base2) {
      const f = structuredClone(fem.snapshot()), t = totals(fem.mesh, f);
      const lastReactionJ = reactionPreviousJ, lastTimeS = reactionPreviousTimeS;
      return { timeS: f.timeS, fem: f, metrics: {
        maximumK: t.maximumK,
        waterUsedKg: 0,
        dryIceUsedKg: 0,
        energyJ: t.energyJ,
        energyResidualJ: t.energyJ - base2.energyJ - f.ledger.ignitionJ - f.ledger.reactionJ + f.ledger.heatOutJ + f.ledger.gasEnthalpyOutJ,
        massResidualKg: t.componentsKg - base2.componentsKg + f.ledger.gasBoundaryKg.reduce((a, b) => a + b, 0),
        oxygenKg: t.oxygenKg,
        fuelKg: t.peatKg,
        reactionW: f.timeS > lastTimeS ? (f.ledger.reactionJ - lastReactionJ) / (f.timeS - lastTimeS) : 0
      } };
    }
    return { timeS, metrics: null };
  }
  let reactionPreviousJ = 0, reactionPreviousTimeS = 0;
  return {
    endS,
    snapshot,
    advanceTo(targetS) {
      if (!Number.isFinite(targetS) || targetS < timeS - 1e-8 || targetS > endS + 1e-8) throw new Error("Invalid physical target");
      if (fem) {
        reactionPreviousJ = fem.frame.ledger.reactionJ;
        reactionPreviousTimeS = fem.frame.timeS;
        while (fem.frame.timeS < targetS - 1e-8) fem.advance(Math.min(fem.settings.maxStepS, targetS - fem.frame.timeS));
        timeS = fem.frame.timeS;
      } else {
        if (contact) contactState = contact.advanceTo(targetS);
        timeS = targetS;
      }
      return snapshot();
    }
  };
}
function createRun(config) {
  const module = findMethodModule(config.variantId);
  return module ? module.createRun(config, { supportedRun: createSupportedRun }) : createSupportedRun(config);
}
function freshPanel(id, variantId) {
  const v = variant(variantId);
  return {
    id,
    variantId,
    engine: v.defaultEngine,
    medium: v.defaultMedium,
    sourceStatus: "unspecified",
    thermal: defaultThermal(variantId),
    fem: { ...DEFAULT_SETTINGS2 },
    ...variantId === "nanoparticles" ? { particleInjection: defaultParticleInjectionSettings() } : {}
  };
}
function duplicatePanel(panel, id) {
  return { ...structuredClone(panel), id };
}
function observationWindowS(config) {
  return config.variantId === "nanoparticles" ? particleObservationWindowS(config) : config.engine === "peat-fem" ? config.fem.endS : config.thermal.endS;
}
function linkedCompatibility(configs) {
  if (configs.length < 2) return "Select at least two panels.";
  if (configs.some((c) => compatible(c.variantId, c.engine, c.medium))) return "Resolve incompatible selections first.";
  if (configs.some((c) => c.engine === "concept")) return "Concept stage time is presentation time, not physical time.";
  if (configs.some((c) => c.engine !== configs[0].engine)) return "Contact and FEM do not represent the same physical system.";
  if (configs.some((c) => observationWindowS(c) !== observationWindowS(configs[0]))) return "Match observation windows first.";
  const first = configs[0];
  if (first.engine === "particle") return particleLinkedCompatibility(configs);
  if (configs.some((c) => c.thermal.seed !== first.thermal.seed)) return "Match seeds before linking physical time.";
  if (first.engine === "contact" && configs.some((c) => c.thermal.initialK !== first.thermal.initialK || c.thermal.inletK !== first.thermal.inletK)) return "Match initial and inlet temperatures before linking physical time.";
  if (first.engine === "peat-fem") {
    const keys = [...new Set(configs.flatMap((c) => Object.keys(c.fem)))];
    if (configs.some((c) => keys.some((key) => c.fem[key] !== first.fem[key]))) return "Match FEM geometry, initial/boundary conditions and numerical settings before linking physical time.";
  }
  return null;
}

// source/src/alternatives/fine-dry-ice-injection/scenarios.ts
function particleScenario(input, scenario) {
  const config = structuredClone(input), p = config.particleInjection;
  if (scenario === "film-sensitivity") {
    p.effectiveConductivityWmK = 6e-3;
    p.hoseResidenceS = 0.01;
    p.probeResidenceS = 0.01;
    config.thermal.contactStartS = 0;
  }
  if (scenario === "water-only") {
    config.medium = "water";
    config.thermal.dryIceKg = 0;
  }
  if (scenario === "pre-sublimated") p.initialPhase = "pre-sublimated";
  if (scenario === "off") config.thermal.enabled = false;
  if (scenario === "freezing-stop") {
    config.thermal.inletK = 274;
    config.thermal.dryIceKg = 0.1;
  }
  return config;
}
function matchedWaterOnly(input, id) {
  const next = particleScenario(input, "water-only");
  next.id = id;
  return next;
}

// source/src/alternatives/persistence.ts
var SESSION_SCHEMA = 2;
function readComparison(raw) {
  const fallback = () => [freshPanel("panel-a", "baseline"), freshPanel("panel-b", "sublimation-injection")];
  if (!raw) return fallback();
  try {
    const saved = JSON.parse(raw);
    if (![1, 2].includes(saved.schema) || !Array.isArray(saved.panels) || !saved.panels.length) return fallback();
    const ids = /* @__PURE__ */ new Set();
    return saved.panels.slice(0, 4).map((p, i) => {
      const known = VARIANTS.find((v) => v.id === p.variantId);
      if (!known) throw new Error("Unknown alternative");
      let id = typeof p.id === "string" && p.id.length > 0 && p.id.length < 100 && !ids.has(p.id) ? p.id : `migrated-${i}`;
      for (let suffix = 1; ids.has(id); suffix++) id = `migrated-${i}-${suffix}`;
      const next = freshPanel(id, known.id);
      ids.add(next.id);
      next.engine = ["contact", "peat-fem", "concept", "particle"].includes(p.engine ?? "") ? p.engine : variant(known.id).defaultEngine;
      next.medium = ["none", "water", "co2-water", "unspecified"].includes(p.medium ?? "") ? p.medium : next.medium;
      if (known.id === "nanoparticles") next.particleInjection = restoreParticleInjectionSettings(p.particleInjection);
      for (const spec of PARAMETERS) {
        const value = p.thermal?.[spec.key];
        if (typeof value === "number" && Number.isFinite(value) && value >= spec.min && value <= spec.max) next.thermal[spec.key] = value;
      }
      next.thermal.enabled = typeof p.thermal?.enabled === "boolean" ? p.thermal.enabled : true;
      if (typeof p.thermal?.seed === "number" && Number.isInteger(p.thermal.seed)) next.thermal.seed = p.thermal.seed;
      if (p.fem) {
        const candidate = { ...next.fem };
        for (const key of Object.keys(candidate)) {
          const value = p.fem[key];
          if (typeof value === typeof candidate[key]) Object.assign(candidate, { [key]: value });
        }
        if ([2, 4, 8].includes(candidate.n) && candidate.endS <= 600 && candidate.maxStepS <= 5 && candidate.ignitionW <= 30) {
          try {
            new PeatSolver(candidate);
            next.fem = candidate;
          } catch {
          }
        }
      }
      return next;
    });
  } catch {
    return fallback();
  }
}
function serializeComparison(panels) {
  return JSON.stringify({ schema: SESSION_SCHEMA, panels });
}

// source/src/alternatives/records.ts
function currentRecord(config, result) {
  return result?.configurationKey?.startsWith(JSON.stringify(config) + ":") ? result : null;
}

// independent-checks.mts
var results = [];
var output = { runId: "D-retry2-independent-fd8e7a0-2026-10-12", executor: "/root/d_realism_reviewer", commit: "fd8e7a0c3b3596c2ee439d7aec52c2bc71f92440", criteriaSHA256: "e9f4409dd874714ae06d12834f48c54c4bdf67c0e1c412866d37236fdf99f31d", checks: results };
var assert = (x, message) => {
  if (!x) throw Error(message);
};
var close = (a, b, tol, message) => assert(Number.isFinite(a) && Math.abs(a - b) <= tol, message + `: ${a} versus ${b}, tol ${tol}`);
var eq = (a, b) => JSON.stringify(a) === JSON.stringify(b);
function check(name, fn) {
  try {
    const evidence = fn();
    results.push({ name, status: "pass", evidence });
  } catch (error) {
    results.push({ name, status: "fail", error: String(error) });
  }
}
var base = () => freshPanel("D-independent", "nanoparticles");
var L2 = 25200 / 0.0440095;
var CW2 = 4186;
var CG2 = 850;
var TS2 = 195;
function reference(end, step = 1e-5) {
  const m0 = 0.01, mw = 1, r0 = 5e-5, rho = 1560, k = 6e-3, H = mw * CW2 * (293.15 - TS2);
  let u = 1, I = 0, time = 0;
  const f = (v) => {
    if (v <= 0) return [0, 0];
    const g = m0 * (1 - Math.pow(Math.max(0, v), 1.5));
    const gap = (H - g * L2) / (mw * CW2 + g * CG2);
    return [-2 * k * gap / (rho * r0 * r0 * (L2 + CG2 * gap)), Math.pow(Math.max(0, v), 1.5)];
  };
  while (time < end - 1e-13) {
    const h = Math.min(step, end - time), a = f(u), b = f(u + h * a[0] / 2), c = f(u + h * b[0] / 2), d = f(u + h * c[0]);
    u = Math.max(0, u + h * (a[0] + 2 * b[0] + 2 * c[0] + d[0]) / 6);
    I += h * (a[1] + 2 * b[1] + 2 * c[1] + d[1]) / 6;
    time += h;
  }
  const gas = m0 * (1 - Math.pow(u, 1.5));
  return { timeS: end, u, solidKg: m0 * Math.pow(u, 1.5), gasKg: gas, temperatureK: TS2 + (H - gas * L2) / (mw * CW2 + gas * CG2), integratedFractionS: I };
}
check("SI properties and independently derived fixed-bath sphere", () => {
  close(PROPERTIES.latentJkg, L2, 0, "latent conversion");
  const cases = [];
  for (const r of [5e-6, 5e-5, 25e-5]) for (const k of [6e-4, 6e-3, 0.6]) {
    const life = 1560 * L2 * r * r / (2 * k * (293.15 - TS2));
    for (const fraction of [0, 0.1, 0.5, 0.999, 1, 1.2]) {
      const expected = Math.max(0, r * r * (1 - fraction));
      const actual = sphereRadiusSquared(r, k, 293.15, 1560, L2, life * fraction);
      close(actual, expected, Math.max(r * r, 1e-30) * 1e-10, "sphere r\xB2");
    }
    cases.push({ radiusM: r, kWmK: k, lifeS: life });
  }
  return { cases, dimensions: "k*r*deltaT -> W; rho*L*r\xB2/(k*deltaT) -> s; H/C -> K" };
});
check("two-capacity analytical reference, signed exchange and long-time equilibrium", () => {
  const values = [];
  for (const [Ta, Tb, Ca, Cb, ua, dt] of [[333, 291, 959.3, 4194.5, 2, 30], [280, 340, 500, 1e3, 10, 2], [330, 290, 1e3, 4e3, 2, 1e10], [330, 290, 1e3, 4e3, 0, 1]]) {
    const equilibrium = (Ca * Ta + Cb * Tb) / (Ca + Cb);
    const expected = Ca * (Ta - equilibrium) * (1 - Math.exp(-ua * (1 / Ca + 1 / Cb) * dt));
    const got = twoCapacityHeatJ(Ta, Tb, Ca, Cb, ua, dt);
    close(got, expected, 1e-9, "pair q");
    close(Ca * (Ta - got / Ca) + Cb * (Tb + got / Cb), Ca * Ta + Cb * Tb, 1e-8, "pair H");
    values.push({ Ta, Tb, Ca, Cb, ua, dt, qJ: got });
  }
  return values;
});
check("independent finite-bath ODE and production time convergence", () => {
  const rows = [];
  for (const target of [0.3, 0.9, 1.5]) {
    const ref = reference(target);
    const c = particleScenario(base(), "film-sensitivity");
    c.thermal.flowKgS = 0;
    const errors = [];
    for (const step of [0.02, 0.01, 5e-3, 25e-4, 125e-5, 625e-6, 3125e-7]) {
      c.particleInjection.stepS = step;
      const s = simulateParticle(c, target), got = s.locations.source;
      errors.push({ stepS: step, solidKg: got.solidKg, solidErrorKg: Math.abs(got.solidKg - ref.solidKg), temperatureErrorK: Math.abs(got.temperatureK - ref.temperatureK) });
    }
    for (let i = 1; i < errors.length; i++) assert(errors[i].solidErrorKg < errors[i - 1].solidErrorKg, "finite-bath error decreases");
    assert(errors.at(-1).solidErrorKg / Math.max(1e-30, ref.solidKg) < 0.02, "finite-bath asymptotic <2%");
    rows.push({ target, reference: ref, errors });
  }
  return { referenceNumerics: "RK4 step1e-5s; different nonlinear ODE integrator, energy identity independently derived", rows };
});
check("continuous entrainment reference versus separate time and parcel refinement", () => {
  const r0 = reference(0.02), rEnd = reference(12);
  const integral = rEnd.integratedFractionS - r0.integratedFractionS, exact = 0.1 * 0.01 * integral;
  const rows = [];
  for (const parcel of [0.025, 0.0125, 625e-5]) {
    const c = particleScenario(base(), "film-sensitivity");
    c.particleInjection.stepS = 3125e-7;
    c.particleInjection.parcelStepS = parcel;
    const s = simulateParticle(c, 12);
    rows.push({ parcelStepS: parcel, solidEntryKg: s.solidEnteringGroundKg, errorKg: Math.abs(s.solidEnteringGroundKg - exact), peatK: s.peatTemperatureK });
  }
  for (let i = 1; i < rows.length; i++) assert(rows[i].errorKg < rows[i - 1].errorKg, "continuous-reference parcel error decreases");
  assert(rows.at(-1).errorKg / exact < 0.02, "finest <2% vs independent continuous reference");
  const time = [];
  for (const dt of [0.02, 0.01, 5e-3, 25e-4, 125e-5, 625e-6, 3125e-7]) {
    const c = particleScenario(base(), "film-sensitivity");
    c.particleInjection.stepS = dt;
    const s = simulateParticle(c, 30);
    time.push({ stepS: dt, entryKg: s.solidEnteringGroundKg, peatK: s.peatTemperatureK });
  }
  for (let i = 2; i < time.length; i++) {
    assert(Math.abs(time[i].entryKg - time[i - 1].entryKg) < Math.abs(time[i - 1].entryKg - time[i - 2].entryKg), "time entry differences shrink");
    assert(Math.abs(time[i].peatK - time[i - 1].peatK) < Math.abs(time[i - 1].peatK - time[i - 2].peatK), "time peat differences shrink");
  }
  return { referenceEntryKg: exact, derivation: "All adiabatic monodisperse parcels have common age-dependent radius because proportional homogeneous withdrawal preserves H/w and initialCO2/w; ground solid integral is flow*m0/w0 integral f_s(t+residence)dt. Prescribed entrainment only.", rows, time };
});
check("independent inventory, species and total enthalpy audit across scenarios and times", () => {
  let maxMass = 0, maxEnergy = 0, maxEnergyRelative = 0, maxFormula = 0;
  const rows = [];
  for (const name of ["conduction-reference", "film-sensitivity", "water-only", "pre-sublimated", "off"]) {
    const c = particleScenario(base(), name), p = c.particleInjection, initialCO2 = c.medium === "co2-water" ? c.thermal.dryIceKg : 0, Cp = p.dryPeatMassKg * (p.dryPeatCpJkgK + p.initialMoistureDryBasis * CW2), H0 = c.thermal.waterKg * CW2 * (c.thermal.inletK - TS2) + Cp * (c.thermal.initialK - TS2);
    for (const time of [0, 3e-3, 0.02, 0.044, 0.045, 0.13, 1, 1.3, 3, 10, 12, 30]) {
      const s = simulateParticle(c, time);
      let mw = 0, mc = 0, H = 0;
      for (const [loc, a] of Object.entries(s.locations)) {
        for (const key of ["waterKg", "solidKg", "gasKg", "enthalpyJ"]) assert(Number.isFinite(a[key]) && a[key] >= -1e-12, `${name} ${loc} ${key} nonnegative finite`);
        mw += a.waterKg;
        mc += a.solidKg + a.gasKg;
        H += a.enthalpyJ;
        const independentlyReconstructed = a.temperatureK === null ? 0 : a.waterKg * CW2 * (a.temperatureK - TS2) + a.gasKg * (L2 + CG2 * (a.temperatureK - TS2));
        maxFormula = Math.max(maxFormula, Math.abs(independentlyReconstructed - a.enthalpyJ));
        close(independentlyReconstructed, a.enthalpyJ, 1e-7, "location H equation");
        if (a.temperatureK !== null) assert(a.temperatureK >= 273.15 - 1e-8 && a.temperatureK <= 350 + 1e-8, "liquid admissibility");
      }
      const massError = Math.max(Math.abs(mw - c.thermal.waterKg), Math.abs(mc - initialCO2)), energyError = Math.abs(H + Cp * (s.peatTemperatureK - TS2) - H0);
      maxMass = Math.max(maxMass, massError);
      maxEnergy = Math.max(maxEnergy, energyError);
      maxEnergyRelative = Math.max(maxEnergyRelative, energyError / Math.max(1, Math.abs(H0)));
      assert(massError < 1e-10, "independent mass tolerance");
      assert(energyError / Math.max(1, Math.abs(H0)) < 1e-9, "independent energy tolerance");
      close(s.releases.reduce((a, x) => a + x.massKg, 0), s.upstreamSublimatedKg + s.undergroundSublimatedKg, 1e-10, "release/submass identity");
      for (const release of s.releases) {
        close(release.latentJ, release.massKg * L2, 1e-7, "release latent once");
        assert(release.fromS >= 0 && release.toS >= release.fromS && release.toS <= time + 1e-9, "release interval bounds");
      }
      close(s.undergroundSublimatedKg + s.locations.soil.solidKg, s.solidEnteringGroundKg, 1e-10, "entry size not reset / ground solid balance");
      assert(s.oxygenMoleFraction === null && s.pressurePa === null && s.extinction === null && s.penetrationM === null, "unsupported quantities null");
      if (time === 30) rows.push({ name, time, solidEntryKg: s.solidEnteringGroundKg, upstreamKg: s.upstreamSublimatedKg, undergroundKg: s.undergroundSublimatedKg, peatK: s.peatTemperatureK, heatPeatJ: s.heatFromPeatJ, source: s.locations.source, soil: s.locations.soil, waterEntryKg: s.waterEnteringGroundKg });
    }
  }
  return { maxMassResidualKg: maxMass, maxAbsoluteEnergyResidualJ: maxEnergy, maxRelativeEnergyResidual: maxEnergyRelative, maxHReconstructionErrorJ: maxFormula, rows, gasOxygenScope: "CO2-only closed inventory accounted; spatial air/O2 mixture unavailable, no oxygen deletion claim" };
});
check("source depletion, zero residence, nondivisible final parcel and withdrawal schedule", () => {
  const rows = [];
  for (const [water, flow, start, parcel, hose, probe] of [[1, 0.1, 1, 0.025, 1, 0.1], [0.333, 0.2, 0.37, 0.05, 0, 0], [7e-3, 0.2, 0, 0.05, 0, 0], [1, 0, 0, 0.025, 1, 0.1]]) {
    const c = matchedWaterOnly(base(), "withdraw");
    Object.assign(c.thermal, { waterKg: water, flowKgS: flow, contactStartS: start });
    Object.assign(c.particleInjection, { parcelStepS: parcel, hoseResidenceS: hose, probeResidenceS: probe });
    for (const time of [0, 0.1, 0.71, 2, 12, 30]) {
      const s = simulateParticle(c, time), withdrawn = water - s.locations.source.waterKg, continuous = Math.min(water, flow * Math.max(0, time - start));
      assert(withdrawn <= continuous + 1e-10 && continuous - withdrawn <= flow * parcel + 1e-10, "right endpoint withdrawal bounded by one parcel");
      if (time >= start + (flow > 0 ? water / flow : Infinity) + hose + probe) close(s.waterEnteringGroundKg, water, 1e-10, "finite depletion flush");
      rows.push({ water, flow, start, parcel, hose, probe, time, withdrawn, continuous, groundWater: s.waterEnteringGroundKg });
    }
  }
  return rows;
});
check("off identity, no-source, zero particles and pre-sublimated counterfactual", () => {
  const c = base(), z = structuredClone(c);
  z.thermal.dryIceKg = 0;
  const water = matchedWaterOnly(c, "water");
  for (const time of [0, 0.04, 1, 12, 30]) {
    const a = simulateParticle(z, time), b = simulateParticle(water, time);
    assert(eq(a.locations, b.locations) && a.peatTemperatureK === b.peatTemperatureK, "zero/matched water identity");
    const off = simulateParticle(particleScenario(c, "off"), time);
    close(off.peatTemperatureK, c.thermal.initialK, 0, "off peat");
    close(off.locations.source.waterKg, 1, 0, "off water");
    close(off.locations.source.solidKg, 0.01, 1e-15, "off solids");
    assert(off.waterEnteringGroundKg === 0 && off.releases.length === 0, "off source retains");
  }
  const pre = simulateParticle(particleScenario(c, "pre-sublimated"), 0);
  const expected = TS2 + (CW2 * (293.15 - TS2) - 0.01 * L2) / (CW2 + 0.01 * CG2);
  close(pre.locations.source.temperatureK, expected, 1e-12, "pre-sub cold source");
  close(pre.upstreamSublimatedKg, 0.01, 0, "pre-sub charge once");
  const depleted = structuredClone(c);
  depleted.thermal.waterKg = 0;
  depleted.thermal.dryIceKg = 0;
  const empty2 = simulateParticle(depleted, 30);
  assert(Object.values(empty2.locations).every((x) => x.waterKg === 0 && x.gasKg === 0 && x.solidKg === 0), "empty finite inventories");
  return { preSublimatedK: pre.locations.source.temperatureK, additionalColdResourceJ: pre.additionalColdResourceJ };
});
check("complete upstream loss and source aging prevent forced underground solids", () => {
  const c = base(), s = simulateParticle(c, 30);
  assert(s.solidEnteringGroundKg === 0 && s.undergroundSublimatedKg === 0, "default upstream failure valid");
  close(s.upstreamSublimatedKg, 0.01, 1e-10, "all lost source");
  close(s.locations.soil.gasKg, 0.01, 1e-10, "gas carried downstream");
  const film = particleScenario(c, "film-sensitivity"), a = simulateParticle(film, 3), b = simulateParticle(film, 12);
  close(a.solidEnteringGroundKg, b.solidEnteringGroundKg, 1e-12, "no late restarted solids");
  assert(b.waterEnteringGroundKg > a.waterEnteringGroundKg && b.locations.source.solidKg === 0, "late water carries no solids");
  const delay = structuredClone(film);
  delay.thermal.contactStartS = 4;
  const no = simulateParticle(delay, 30);
  assert(no.solidEnteringGroundKg === 0, "long source delay fails survival");
  return { default: s.solidEnteringGroundKg, film: a.solidEnteringGroundKg, delayed: no.solidEnteringGroundKg };
});
check("bulk freezing and above-domain inputs reject without damaging accepted run", () => {
  const c = particleScenario(base(), "freezing-stop"), r = createRun(c), before = r.snapshot();
  let message = "";
  try {
    r.advanceTo(1);
  } catch (e) {
    message = String(e);
  }
  assert(message.includes("freezing"), "runtime freezing reject");
  assert(eq(before, r.snapshot()), "failed trial preserves snapshot");
  const bad = [];
  for (const [key, value] of [["inletK", 350.00001], ["initialK", 823.15], ["waterKg", NaN]]) {
    const c2 = base();
    c2.thermal[key] = value;
    let threw2 = false;
    try {
      simulateParticle(c2, 0);
    } catch {
      threw2 = true;
    }
    assert(threw2, "unsupported thermal reject");
    bad.push(key);
  }
  const presub = particleScenario(base(), "pre-sublimated");
  presub.thermal.inletK = 274;
  presub.thermal.dryIceKg = 0.1;
  let threw = false;
  try {
    simulateParticle(presub, 0);
  } catch {
    threw = true;
  }
  assert(threw, "impossible presub liquid reject");
  return { message, rejected: bad, boilingScope: "Above350K excluded, no implemented boiling or local ice-shell/blockage model" };
});
check("deterministic replay and independent cloned configurations/snapshots", () => {
  const c = particleScenario(base(), "film-sensitivity"), q = duplicatePanel(c, "D-independent-2"), a = createRun(c), b = createRun(q);
  const original = structuredClone(c), secondBefore = b.snapshot();
  c.thermal.waterKg = 5;
  c.particleInjection.particleDiameterM = 5e-4;
  const out = a.advanceTo(1.37);
  out.particleInjection.locations.source.waterKg = 999;
  out.particleInjection.releases.push({ location: "soil", fromS: 0, toS: 0, massKg: 999, latentJ: 0 });
  assert(eq(b.snapshot(), secondBefore), "other run untouched");
  assert(a.snapshot().particleInjection.locations.source.waterKg !== 999, "caller snapshot isolated");
  const direct = createRun(original).advanceTo(12);
  a.advanceTo(3.1);
  assert(eq(a.advanceTo(12), direct), "sampling cadence independent");
  for (const t of [11, NaN, 31]) {
    const before = a.snapshot();
    let threw = false;
    try {
      a.advanceTo(t);
    } catch {
      threw = true;
    }
    assert(threw && eq(a.snapshot(), before), "bad advance atomic");
  }
  const restored = readComparison(serializeComparison([original]))[0];
  assert(eq(restored.particleInjection, original.particleInjection), "config restoration private inputs");
  return { directVsChunked: true, callerSnapshotIsolated: true, configCloned: true, otherRunIsolated: true };
});
check("comparison fairness links and stale record rejection", () => {
  const c = base(), water = matchedWaterOnly(c, "control");
  assert(linkedCompatibility([c, water]) === null, "matched water links");
  water.particleInjection.probeResidenceS = 0.2;
  assert(!!linkedCompatibility([c, water]), "mismatched residence refuses link");
  const record = { configurationKey: JSON.stringify(c) + ":1", state: createRun(c).advanceTo(1) };
  assert(currentRecord(c, record) === record, "accepted config record");
  const edited = structuredClone(c);
  edited.thermal.waterKg = 2;
  assert(currentRecord(edited, record) === null, "stale export rejected");
  return { matched: true, residenceMismatchBlocked: true, staleExportBlocked: true };
});
check("visual/source correspondence read-only; actual UI gate explicitly unverified", () => {
  const s = fs.readFileSync(new URL("./source/src/alternatives/fine-dry-ice-injection/comparison.tsx", import.meta.url), "utf8");
  assert(s.includes("24*Math.sqrt(value.solidKg/Math.max(state.initialCO2Kg,1e-30))"), "symbol area proportional to accepted solid mass");
  assert(s.includes("not to scale") && s.includes("inventory compartments"), "glyph and compartment disclosure");
  assert(s.includes("state.releases.map") && s.includes("state.meanSolidDiameterM"), "accepted release and size displays");
  return { sourceFormulaVerified: true, actualUIInspected: false, restriction: "Coordinator reported administrative browser policy denial; no browser/Electron/CDP or indirect bypass attempted." };
});
fs.writeFileSync(new URL("./independent-results.json", import.meta.url), JSON.stringify(output, null, 2));
console.log(JSON.stringify({ runId: output.runId, passed: results.filter((r) => r.status === "pass").length, failed: results.filter((r) => r.status === "fail").length, failures: results.filter((r) => r.status === "fail") }));
